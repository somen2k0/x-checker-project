import { useState, useRef } from "react";
import { useCheckAccounts } from "@workspace/api-client-react";
import { AccountCheckResult } from "@workspace/api-client-react/src/generated/api.schemas";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Loader2, Copy, Trash2, CheckCircle2, XCircle, HelpCircle,
  UserX, AlertCircle, BadgeCheck, ExternalLink, Users, Calendar, Link2,
  Sparkles, RefreshCw, Plus, KeyRound, Eye, EyeOff, ShieldCheck,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const STORAGE_KEY = "groq_api_keys";
const MAX_KEYS = 5;

function loadKeys(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveKeys(keys: string[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(keys));
}

function maskKey(key: string): string {
  if (key.length <= 12) return "••••••••••••";
  return key.slice(0, 8) + "••••••••" + key.slice(-4);
}

function formatCount(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  return n.toString();
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", { year: "numeric", month: "short" });
}

export default function Home() {
  const [input, setInput] = useState("");
  const [results, setResults] = useState<AccountCheckResult[]>([]);
  const { toast } = useToast();
  const checkAccountsMutation = useCheckAccounts();

  // Profile Link tab state
  const [profileInput, setProfileInput] = useState("");

  // Bio Generator tab state
  const [bioTopic, setBioTopic] = useState("");
  const [bioTone, setBioTone] = useState("");
  const [bios, setBios] = useState<string[]>([]);
  const [bioLoading, setBioLoading] = useState(false);

  // API Keys (Settings tab)
  const [groqKeys, setGroqKeys] = useState<string[]>(loadKeys);
  const [newKey, setNewKey] = useState("");
  const [showNewKey, setShowNewKey] = useState(false);
  const [visibleKeys, setVisibleKeys] = useState<Set<number>>(new Set());
  const keyIndexRef = useRef(0);

  const addKey = () => {
    const trimmed = newKey.trim();
    if (!trimmed) return;
    if (groqKeys.length >= MAX_KEYS) {
      toast({ title: "Max keys reached", description: `You can store up to ${MAX_KEYS} API keys.`, variant: "destructive" });
      return;
    }
    if (groqKeys.includes(trimmed)) {
      toast({ title: "Duplicate key", description: "This key is already saved.", variant: "destructive" });
      return;
    }
    const updated = [...groqKeys, trimmed];
    setGroqKeys(updated);
    saveKeys(updated);
    setNewKey("");
    setShowNewKey(false);
    toast({ title: "Key saved", description: "Groq API key added successfully." });
  };

  const removeKey = (index: number) => {
    const updated = groqKeys.filter((_, i) => i !== index);
    setGroqKeys(updated);
    saveKeys(updated);
    keyIndexRef.current = 0;
    setVisibleKeys((prev) => {
      const next = new Set<number>();
      prev.forEach((i) => { if (i !== index) next.add(i > index ? i - 1 : i); });
      return next;
    });
    toast({ title: "Key removed" });
  };

  const toggleKeyVisibility = (index: number) => {
    setVisibleKeys((prev) => {
      const next = new Set(prev);
      if (next.has(index)) next.delete(index);
      else next.add(index);
      return next;
    });
  };

  const pickNextKey = (): string | null => {
    if (groqKeys.length === 0) return null;
    const key = groqKeys[keyIndexRef.current % groqKeys.length];
    keyIndexRef.current = (keyIndexRef.current + 1) % groqKeys.length;
    return key;
  };

  const handleGenerateBio = async () => {
    if (!bioTopic.trim()) {
      toast({ title: "Enter a topic", description: "Tell us what your bio should be about.", variant: "destructive" });
      return;
    }
    const apiKey = pickNextKey();
    if (!apiKey) {
      toast({
        title: "No API key",
        description: "Add a Groq API key in the Settings tab first.",
        variant: "destructive",
      });
      return;
    }

    setBioLoading(true);
    setBios([]);
    try {
      const res = await fetch("/api/generate-bio", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic: bioTopic, tone: bioTone, apiKey }),
      });
      const data = await res.json();

      if (res.status === 401 || data.error === "invalid_api_key") {
        toast({ title: "Invalid API key", description: "One of your keys is invalid. Check your Settings.", variant: "destructive" });
        return;
      }
      if (res.status === 429 || data.error === "rate_limited") {
        toast({ title: "Rate limited", description: "This key hit its limit. Trying next key on the next attempt.", variant: "destructive" });
        return;
      }
      if (data.error === "no_api_key") {
        toast({ title: "No API key sent", description: "Add a Groq API key in Settings.", variant: "destructive" });
        return;
      }
      if (!res.ok) throw new Error(data.error ?? "Failed to generate bio");

      setBios(data.bios ?? []);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : "Something went wrong";
      toast({ title: "Error", description: message, variant: "destructive" });
    } finally {
      setBioLoading(false);
    }
  };

  const profileUsernames = profileInput
    .split(/[\s,\n]+/)
    .map((u) => u.trim().replace(/^@/, ""))
    .filter((u) => u.length > 0);

  const profileLinks = profileUsernames.map((u) => ({
    username: u,
    url: `https://x.com/${u}`,
  }));

  const handleCopyLink = (url: string) => {
    navigator.clipboard.writeText(url);
    toast({ title: "Copied!", description: url });
  };

  const handleCopyAllLinks = () => {
    if (!profileLinks.length) return;
    navigator.clipboard.writeText(profileLinks.map((l) => l.url).join("\n"));
    toast({ title: "Copied all links!", description: `${profileLinks.length} links copied.` });
  };

  const handleCheck = () => {
    const usernames = input
      .split(/[\s,]+/)
      .map((u) => u.trim().replace(/^@/, ""))
      .filter((u) => u.length > 0);

    if (usernames.length === 0) {
      toast({ title: "No usernames provided", description: "Please enter at least one username.", variant: "destructive" });
      return;
    }
    if (usernames.length > 100) {
      toast({ title: "Too many usernames", description: "Max 100 at a time.", variant: "destructive" });
      return;
    }

    checkAccountsMutation.mutate(
      { data: { usernames } },
      {
        onSuccess: (data) => {
          setResults(data.results);
          toast({ title: "Check complete", description: `Checked ${data.results.length} accounts.` });
        },
        onError: (error) => {
          toast({ title: "Error", description: error.error?.error ?? "An unexpected error occurred.", variant: "destructive" });
        },
      }
    );
  };

  const handleClear = () => { setInput(""); setResults([]); };

  const handleCopyResults = () => {
    if (!results.length) return;
    const text = results.map((r) =>
      `${r.username}\t${r.status.toUpperCase()}${r.displayName ? `\t${r.displayName}` : ""}${r.followerCount != null ? `\t${r.followerCount} followers` : ""}`
    ).join("\n");
    navigator.clipboard.writeText(text);
    toast({ title: "Copied to clipboard", description: "Results copied as TSV." });
  };

  const getStatusIcon = (status: AccountCheckResult["status"]) => {
    switch (status) {
      case "active": return <CheckCircle2 className="h-4 w-4 text-success" />;
      case "suspended": return <XCircle className="h-4 w-4 text-destructive" />;
      case "not_found": return <UserX className="h-4 w-4 text-muted-foreground" />;
      default: return <HelpCircle className="h-4 w-4 text-warning" />;
    }
  };

  const getStatusBadge = (status: AccountCheckResult["status"]) => {
    switch (status) {
      case "active": return <Badge variant="outline" className="bg-success/10 text-success border-success/20">Active</Badge>;
      case "suspended": return <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">Suspended</Badge>;
      case "not_found": return <Badge variant="outline" className="bg-muted/50 text-muted-foreground border-muted-foreground/20">Not Found</Badge>;
      default: return <Badge variant="outline" className="bg-warning/10 text-warning border-warning/20">Unknown</Badge>;
    }
  };

  return (
    <div className="min-h-[100dvh] bg-background text-foreground font-sans selection:bg-primary/30">
      <div className="max-w-5xl mx-auto p-4 md:p-8 space-y-8">
        <header className="space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">X Toolkit</h1>
          <p className="text-muted-foreground font-mono text-sm">Account checker + profile link generator.</p>
        </header>

        <Tabs defaultValue="checker" className="w-full">
          <TabsList className="grid w-full max-w-xl grid-cols-4 bg-muted/50 border border-border/50">
            <TabsTrigger value="checker">Account Checker</TabsTrigger>
            <TabsTrigger value="links">Profile Links</TabsTrigger>
            <TabsTrigger value="bio">Bio Generator</TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-1.5">
              <KeyRound className="h-3.5 w-3.5" />
              Settings
              {groqKeys.length > 0 && (
                <span className="ml-1 rounded-full bg-primary/20 text-primary text-[10px] font-mono px-1.5 py-0.5 leading-none">
                  {groqKeys.length}
                </span>
              )}
            </TabsTrigger>
          </TabsList>

          {/* ── Account Checker ── */}
          <TabsContent value="checker" className="space-y-8 mt-6">
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-lg">Input</CardTitle>
                <CardDescription>Paste usernames separated by newlines, spaces, or commas. @ is optional.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="elonmusk&#10;@jack&#10;sama"
                  className="min-h-[150px] font-mono text-sm bg-background resize-y"
                  data-testid="textarea-usernames"
                />
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground font-mono">
                    {input.split(/[\s,]+/).filter(Boolean).length} / 100
                  </span>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={handleClear} disabled={!input && !results.length} className="font-mono text-xs uppercase" data-testid="button-clear">
                      <Trash2 className="h-4 w-4 mr-2" /> Clear
                    </Button>
                    <Button onClick={handleCheck} disabled={checkAccountsMutation.isPending || !input.trim()} className="font-mono text-xs uppercase min-w-[120px]" data-testid="button-check">
                      {checkAccountsMutation.isPending ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Checking</> : "Check Status"}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {results.length > 0 && (
              <Card className="border-border/50 bg-card/50 backdrop-blur animate-in fade-in slide-in-from-bottom-4 duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <div className="space-y-1">
                    <CardTitle className="text-lg">Results</CardTitle>
                    <CardDescription>
                      {results.filter(r => r.status === "active").length} active,{" "}
                      {results.filter(r => r.status === "suspended").length} suspended,{" "}
                      {results.filter(r => r.status === "not_found").length} not found
                    </CardDescription>
                  </div>
                  <Button variant="secondary" size="sm" onClick={handleCopyResults} className="font-mono text-xs uppercase" data-testid="button-copy-results">
                    <Copy className="h-4 w-4 mr-2" /> Copy
                  </Button>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border border-border/50 overflow-hidden bg-background/50">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead className="text-xs text-muted-foreground uppercase bg-muted/20 border-b border-border/50 font-mono">
                          <tr>
                            <th className="px-4 py-3 font-medium">Account</th>
                            <th className="px-4 py-3 font-medium w-[120px]">Status</th>
                            <th className="px-4 py-3 font-medium">Followers</th>
                            <th className="px-4 py-3 font-medium">Following</th>
                            <th className="px-4 py-3 font-medium">Joined</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-border/30">
                          {results.map((result, i) => (
                            <tr key={`${result.username}-${i}`} className="hover:bg-muted/10 transition-colors group">
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-3">
                                  <Avatar className="h-9 w-9 border border-border/50 rounded-full bg-muted/50 shrink-0">
                                    {result.profileImageUrl && <AvatarImage src={result.profileImageUrl} alt={result.username} />}
                                    <AvatarFallback className="rounded-full bg-transparent text-muted-foreground font-mono text-xs">
                                      {result.username.substring(0, 2).toUpperCase()}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div className="flex flex-col min-w-0">
                                    <div className="flex items-center gap-1.5">
                                      {result.status === "active" ? (
                                        <a href={`https://x.com/${result.username}`} target="_blank" rel="noopener noreferrer"
                                          className="font-medium text-foreground group-hover:text-primary transition-colors flex items-center gap-1 hover:underline">
                                          @{result.username}
                                          <ExternalLink className="h-3 w-3 opacity-50" />
                                        </a>
                                      ) : (
                                        <span className="font-medium text-muted-foreground">@{result.username}</span>
                                      )}
                                      {result.isVerified && <BadgeCheck className="h-4 w-4 text-blue-500 shrink-0" title="Verified" />}
                                    </div>
                                    {result.displayName && <span className="text-xs text-muted-foreground truncate max-w-[180px]">{result.displayName}</span>}
                                    {result.error && (
                                      <span className="text-destructive/80 text-xs flex items-center gap-1 font-mono">
                                        <AlertCircle className="h-3 w-3" />{result.error}
                                      </span>
                                    )}
                                  </div>
                                </div>
                              </td>
                              <td className="px-4 py-3">
                                <div className="flex items-center gap-2">{getStatusIcon(result.status)}{getStatusBadge(result.status)}</div>
                              </td>
                              <td className="px-4 py-3">
                                {result.followerCount != null ? (
                                  <div className="flex items-center gap-1.5 text-sm">
                                    <Users className="h-3.5 w-3.5 text-muted-foreground" />
                                    <span className="font-mono font-medium">{formatCount(result.followerCount)}</span>
                                  </div>
                                ) : <span className="text-muted-foreground/40 font-mono text-xs">--</span>}
                              </td>
                              <td className="px-4 py-3">
                                {result.followingCount != null
                                  ? <span className="font-mono text-sm font-medium">{formatCount(result.followingCount)}</span>
                                  : <span className="text-muted-foreground/40 font-mono text-xs">--</span>}
                              </td>
                              <td className="px-4 py-3">
                                {result.createdAt ? (
                                  <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                                    <Calendar className="h-3.5 w-3.5" />
                                    <span className="font-mono">{formatDate(result.createdAt)}</span>
                                  </div>
                                ) : <span className="text-muted-foreground/40 font-mono text-xs">--</span>}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* ── Profile Links ── */}
          <TabsContent value="links" className="space-y-6 mt-6">
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-lg">Profile Link Generator</CardTitle>
                <CardDescription>Enter one or more usernames and get their direct X profile links instantly.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Textarea
                  value={profileInput}
                  onChange={(e) => setProfileInput(e.target.value)}
                  placeholder="@KGeN_Community&#10;elonmusk&#10;jack"
                  className="min-h-[120px] font-mono text-sm bg-background resize-y"
                />
                <div className="flex items-center justify-between">
                  <span className="text-xs text-muted-foreground font-mono">
                    {profileUsernames.length} username{profileUsernames.length !== 1 ? "s" : ""}
                  </span>
                  {profileLinks.length > 1 && (
                    <Button variant="outline" size="sm" onClick={handleCopyAllLinks} className="font-mono text-xs uppercase">
                      <Copy className="h-4 w-4 mr-2" /> Copy All
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            {profileLinks.length > 0 && (
              <Card className="border-border/50 bg-card/50 backdrop-blur animate-in fade-in slide-in-from-bottom-4 duration-300">
                <CardContent className="pt-4">
                  <div className="space-y-2">
                    {profileLinks.map(({ username, url }) => (
                      <div key={username} className="flex items-center justify-between gap-3 rounded-md border border-border/40 bg-background/60 px-4 py-3 group hover:border-primary/30 transition-colors">
                        <div className="flex items-center gap-2 min-w-0">
                          <Link2 className="h-4 w-4 text-muted-foreground shrink-0" />
                          <div className="flex flex-col min-w-0">
                            <span className="text-sm font-medium text-foreground font-mono">@{username}</span>
                            <a
                              href={url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-xs text-primary hover:underline flex items-center gap-1 truncate"
                            >
                              {url}
                              <ExternalLink className="h-3 w-3 opacity-60 shrink-0" />
                            </a>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopyLink(url)}
                          className="font-mono text-xs uppercase shrink-0 opacity-60 group-hover:opacity-100 transition-opacity"
                        >
                          <Copy className="h-3.5 w-3.5 mr-1" /> Copy
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* ── Bio Generator ── */}
          <TabsContent value="bio" className="space-y-6 mt-6">
            {groqKeys.length === 0 && (
              <div className="rounded-lg border border-warning/30 bg-warning/5 px-4 py-3 flex items-start gap-3 text-sm text-warning">
                <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
                <span>No Groq API key found. Go to the <strong>Settings</strong> tab to add one before generating bios.</span>
              </div>
            )}
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="text-lg">X Bio Generator</CardTitle>
                <CardDescription>
                  Describe yourself or your niche and get 3 ready-to-use X bios instantly.
                  {groqKeys.length > 1 && (
                    <span className="ml-1 text-primary/80">
                      Keys rotate automatically ({groqKeys.length} active).
                    </span>
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Topic / Niche</label>
                  <Input
                    value={bioTopic}
                    onChange={(e) => setBioTopic(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleGenerateBio()}
                    placeholder="e.g. web3 gaming, crypto trader, fitness coach..."
                    className="font-mono text-sm bg-background"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-foreground">Tone <span className="text-muted-foreground font-normal">(optional)</span></label>
                  <Input
                    value={bioTone}
                    onChange={(e) => setBioTone(e.target.value)}
                    placeholder="e.g. professional, funny, bold, mysterious..."
                    className="font-mono text-sm bg-background"
                  />
                </div>
                <div className="flex justify-end">
                  <Button
                    onClick={handleGenerateBio}
                    disabled={bioLoading || !bioTopic.trim() || groqKeys.length === 0}
                    className="font-mono text-xs uppercase min-w-[150px]"
                  >
                    {bioLoading
                      ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Generating...</>
                      : <><Sparkles className="h-4 w-4 mr-2" />Generate Bios</>}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {bios.length > 0 && (
              <Card className="border-border/50 bg-card/50 backdrop-blur animate-in fade-in slide-in-from-bottom-4 duration-300">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-lg">Generated Bios</CardTitle>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleGenerateBio}
                    disabled={bioLoading}
                    className="font-mono text-xs uppercase opacity-70 hover:opacity-100"
                  >
                    <RefreshCw className="h-3.5 w-3.5 mr-1.5" /> Regenerate
                  </Button>
                </CardHeader>
                <CardContent className="space-y-3">
                  {bios.map((bio, i) => (
                    <div
                      key={i}
                      className="flex items-start justify-between gap-3 rounded-md border border-border/40 bg-background/60 px-4 py-3 group hover:border-primary/30 transition-colors"
                    >
                      <div className="flex flex-col gap-1 min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-mono text-muted-foreground uppercase">Option {i + 1}</span>
                          <span className="text-xs font-mono text-muted-foreground/50">{bio.length}/160 chars</span>
                        </div>
                        <p className="text-sm text-foreground leading-relaxed">{bio}</p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          navigator.clipboard.writeText(bio);
                          toast({ title: "Copied!", description: "Bio copied to clipboard." });
                        }}
                        className="font-mono text-xs uppercase shrink-0 opacity-60 group-hover:opacity-100 transition-opacity mt-1"
                      >
                        <Copy className="h-3.5 w-3.5 mr-1" /> Copy
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* ── Settings ── */}
          <TabsContent value="settings" className="space-y-6 mt-6">
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <div className="flex items-center gap-2">
                  <KeyRound className="h-5 w-5 text-primary" />
                  <CardTitle className="text-lg">Groq API Keys</CardTitle>
                </div>
                <CardDescription>
                  Add up to {MAX_KEYS} Groq API keys. Keys rotate automatically on each bio generation request to avoid rate limits.
                  Get your free API key at{" "}
                  <a href="https://console.groq.com/keys" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline inline-flex items-center gap-1">
                    console.groq.com <ExternalLink className="h-3 w-3" />
                  </a>
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-5">
                {/* Add new key */}
                {groqKeys.length < MAX_KEYS && (
                  <div className="flex gap-2">
                    <div className="relative flex-1">
                      <Input
                        type={showNewKey ? "text" : "password"}
                        value={newKey}
                        onChange={(e) => setNewKey(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && addKey()}
                        placeholder="gsk_••••••••••••••••••••••••••••••••••••••••••••••••••••••"
                        className="font-mono text-sm bg-background pr-10"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewKey((v) => !v)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                        tabIndex={-1}
                      >
                        {showNewKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                      </button>
                    </div>
                    <Button
                      onClick={addKey}
                      disabled={!newKey.trim()}
                      className="font-mono text-xs uppercase shrink-0"
                    >
                      <Plus className="h-4 w-4 mr-1.5" /> Add Key
                    </Button>
                  </div>
                )}

                {groqKeys.length >= MAX_KEYS && (
                  <div className="rounded-md border border-primary/20 bg-primary/5 px-4 py-2.5 text-sm text-primary/80 flex items-center gap-2">
                    <ShieldCheck className="h-4 w-4 shrink-0" />
                    Maximum of {MAX_KEYS} keys reached. Remove one to add another.
                  </div>
                )}

                {/* Saved keys list */}
                {groqKeys.length > 0 ? (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-mono text-muted-foreground uppercase tracking-wide">
                        Saved Keys ({groqKeys.length}/{MAX_KEYS})
                      </span>
                      {groqKeys.length > 1 && (
                        <span className="text-xs text-muted-foreground font-mono flex items-center gap-1">
                          <RefreshCw className="h-3 w-3" /> Round-robin rotation active
                        </span>
                      )}
                    </div>
                    {groqKeys.map((key, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-3 rounded-md border border-border/40 bg-background/60 px-4 py-3 group hover:border-border/70 transition-colors"
                      >
                        <KeyRound className="h-4 w-4 text-muted-foreground shrink-0" />
                        <span className="flex-1 font-mono text-sm text-foreground truncate">
                          {visibleKeys.has(i) ? key : maskKey(key)}
                        </span>
                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => toggleKeyVisibility(i)}
                            className="p-1.5 rounded text-muted-foreground hover:text-foreground hover:bg-muted/50 transition-colors"
                            title={visibleKeys.has(i) ? "Hide key" : "Show key"}
                          >
                            {visibleKeys.has(i) ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                          </button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeKey(i)}
                            className="h-7 px-2 font-mono text-xs uppercase text-destructive hover:text-destructive hover:bg-destructive/10"
                          >
                            <Trash2 className="h-3.5 w-3.5 mr-1" /> Remove
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="rounded-lg border border-dashed border-border/50 bg-muted/10 px-6 py-8 text-center space-y-2">
                    <KeyRound className="h-8 w-8 text-muted-foreground/40 mx-auto" />
                    <p className="text-sm text-muted-foreground">No API keys saved yet.</p>
                    <p className="text-xs text-muted-foreground/60">Add a key above to start generating bios.</p>
                  </div>
                )}

                <div className="rounded-md border border-border/30 bg-muted/10 px-4 py-3 text-xs text-muted-foreground space-y-1">
                  <p className="font-medium text-foreground/70">How key rotation works</p>
                  <p>Each time you generate a bio, the next key in the list is used (round-robin). If one key hits its rate limit, just click Generate again — the next key will be tried automatically.</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

        </Tabs>
      </div>
    </div>
  );
}
