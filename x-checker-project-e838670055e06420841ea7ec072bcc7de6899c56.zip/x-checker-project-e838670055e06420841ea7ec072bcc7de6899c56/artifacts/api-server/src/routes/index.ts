import { Router, type IRouter } from "express";
import healthRouter from "./health";
import accountsRouter from "./accounts";
import bioRouter from "./bio";
import tempMailRouter from "./temp-mail";
import contactRouter from "./contact";
import gmailnatorRouter from "./gmailnator";

const router: IRouter = Router();

router.use(healthRouter);
router.use(accountsRouter);
router.use(bioRouter);
router.use(tempMailRouter);
router.use(contactRouter);
router.use(gmailnatorRouter);

export default router;
