import { Router } from "express";
import { logger } from "../lib/logger";

const router = Router();

const GUERRILLA_API = "https://api.guerrillamail.com/ajax.php";

const GUERRILLA_DOMAINS = [
  "guerrillamail.com",
  "guerrillamail.net",
  "guerrillamail.org",
  "guerrillamail.biz",
  "guerrillamail.de",
  "grr.la",
  "spam4.me",
];

const FIRST_NAMES = [
  "adam","alex","alice","amber","amy","anna","ben","blake","brad","brian",
  "chloe","chris","claire","cole","dana","david","diana","drew","dylan","elena",
  "eli","emily","emma","eric","evan","fiona","frank","grace","grant","hannah",
  "henry","holly","ian","jack","jake","james","jane","jason","jessica","joel",
  "john","julia","karen","kate","kevin","kyle","laura","leo","lily","lisa",
  "luke","mark","mary","matt","maya","megan","michael","mike","molly","morgan",
  "nate","nick","nina","noah","olivia","owen","paul","peter","rachel","ryan",
  "sara","sarah","scott","sean","seth","sophie","steve","taylor","thomas","tim",
  "tom","tyler","victor","will","zoe",
];

const LAST_NAMES = [
  "adams","allen","anderson","baker","bell","bennett","brooks","brown","campbell",
  "carter","clark","cole","collins","cook","cooper","cox","davis","edwards","evans",
  "fisher","flores","ford","foster","garcia","gray","green","hall","harris","hayes",
  "hill","howard","hughes","jackson","james","johnson","jones","kelly","king","lane",
  "lee","lewis","long","lopez","martin","martinez","miller","mitchell","moore",
  "morgan","morris","murphy","nelson","parker","perry","peterson","phillips","price",
  "reed","reynolds","richardson","roberts","robinson","rogers","ross","russell","ryan",
  "sanchez","scott","shaw","smith","stewart","stone","taylor","thomas","thompson",
  "turner","walker","ward","watson","white","williams","wilson","wood","wright","young",
];

function generateUsername(): string {
  const first = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
  const last  = LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)];
  const num   = Math.floor(Math.random() * 90) + 10;
  return `${first}.${last}${num}`;
}

interface GuerrillaAddressResponse {
  email_addr: string;
  sid_token: string;
  email_timestamp: number;
  alias: string;
  site_id: string;
  site: string;
}

interface GuerrillaMessage {
  mail_id: string;
  mail_from: string;
  mail_subject: string;
  mail_excerpt: string;
  mail_timestamp: string;
  mail_date: string;
  mail_read: string;
  att: string;
}

interface GuerrillaCheckResponse {
  list: GuerrillaMessage[];
  count: string;
  email: string;
  alias: string;
  sid_token: string;
}

interface GuerrillaFetchResponse {
  mail_id: string;
  mail_from: string;
  mail_subject: string;
  mail_body: string;
  mail_excerpt: string;
  mail_timestamp: string;
  mail_date: string;
  mail_read: string;
  att_count: string;
  ref_mid: string;
}

function normalizeMessage(m: GuerrillaMessage) {
  return {
    id: m.mail_id,
    from: { address: m.mail_from, name: m.mail_from },
    subject: m.mail_subject || "(no subject)",
    intro: m.mail_excerpt || "",
    createdAt: new Date(parseInt(m.mail_timestamp, 10) * 1000).toISOString(),
    seen: m.mail_read === "1",
    hasAttachments: m.att !== "0",
  };
}

router.get("/temp-mail/domains", (_req, res): void => {
  res.json({ domains: GUERRILLA_DOMAINS });
});

async function safeJson<T>(r: Response): Promise<T | null> {
  try {
    const text = await r.text();
    if (!text.trim()) return null;
    return JSON.parse(text) as T;
  } catch {
    return null;
  }
}

router.post("/temp-mail/create", async (req, res): Promise<void> => {
  try {
    const { username: rawUsername } = req.body as { username?: string };

    const initRes = await fetch(
      `${GUERRILLA_API}?f=get_email_address&lang=en&site=guerrillamail.com`,
      { signal: AbortSignal.timeout(10000) },
    );
    const initData = await safeJson<GuerrillaAddressResponse>(initRes);
    if (!initData?.sid_token) {
      res.status(502).json({ error: "Temp mail service unavailable — please try again" });
      return;
    }
    const sidToken = initData.sid_token;

    const isCustom = !!(rawUsername && /^[a-z0-9._-]{3,30}$/.test(rawUsername.toLowerCase().trim()));
    const desiredUser = isCustom ? rawUsername!.toLowerCase().trim() : generateUsername();

    const setRes = await fetch(
      `${GUERRILLA_API}?f=set_email_user&email_user=${encodeURIComponent(desiredUser)}&lang=en&sid_token=${encodeURIComponent(sidToken)}`,
      { signal: AbortSignal.timeout(10000) },
    );
    const setData = await safeJson<Partial<GuerrillaAddressResponse>>(setRes);

    const finalAddress = setData?.email_addr ?? initData.email_addr;
    if (!finalAddress) {
      res.status(502).json({ error: "Could not assign email address — please try again" });
      return;
    }

    logger.info({ address: finalAddress }, "Created guerrilla mail session");
    res.json({ id: sidToken, address: finalAddress, token: sidToken });
  } catch (err) {
    logger.error({ err }, "Temp mail create error");
    res.status(502).json({ error: "Temp mail service unavailable. Please try again." });
  }
});

router.get("/temp-mail/messages", async (req, res): Promise<void> => {
  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Missing token" });
    return;
  }
  const sidToken = auth.slice(7);
  const seq = typeof req.query.seq === "string" ? req.query.seq : "0";

  try {
    const r = await fetch(
      `${GUERRILLA_API}?f=check_email&seq=${encodeURIComponent(seq)}&sid_token=${encodeURIComponent(sidToken)}`,
      { signal: AbortSignal.timeout(10000) },
    );
    if (!r.ok) {
      res.status(r.status).json({ error: "Failed to fetch messages" });
      return;
    }
    const data = await r.json() as GuerrillaCheckResponse;
    const messages = (data.list ?? []).map(normalizeMessage);
    res.json({ messages });
  } catch (err) {
    logger.error({ err }, "Temp mail fetch messages error");
    res.status(502).json({ error: "Failed to fetch messages" });
  }
});

router.get("/temp-mail/messages/:id", async (req, res): Promise<void> => {
  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Missing token" });
    return;
  }
  const sidToken = auth.slice(7);
  const { id } = req.params;

  if (!id || !/^[a-zA-Z0-9_-]+$/.test(id)) {
    res.status(400).json({ error: "Invalid message ID" });
    return;
  }

  try {
    const r = await fetch(
      `${GUERRILLA_API}?f=fetch_email&email_id=${encodeURIComponent(id)}&sid_token=${encodeURIComponent(sidToken)}`,
      { signal: AbortSignal.timeout(10000) },
    );
    if (!r.ok) {
      res.status(r.status).json({ error: "Message not found" });
      return;
    }
    const data = await r.json() as GuerrillaFetchResponse;
    res.json({
      id: data.mail_id,
      from: { address: data.mail_from, name: data.mail_from },
      subject: data.mail_subject || "(no subject)",
      intro: data.mail_excerpt || "",
      createdAt: new Date(parseInt(data.mail_timestamp, 10) * 1000).toISOString(),
      seen: true,
      hasAttachments: data.att_count !== "0",
      html: data.mail_body ? [data.mail_body] : undefined,
      text: data.mail_excerpt,
    });
  } catch (err) {
    logger.error({ err }, "Temp mail fetch message body error");
    res.status(502).json({ error: "Failed to fetch message" });
  }
});

export default router;
