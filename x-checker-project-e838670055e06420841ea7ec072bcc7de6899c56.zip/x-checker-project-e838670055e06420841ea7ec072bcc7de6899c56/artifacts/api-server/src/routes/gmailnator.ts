import { Router } from "express";
import { logger } from "../lib/logger";

const router = Router();

// ── Paste your RapidAPI keys here (one per line) ──────────────────────────
// Get keys from https://rapidapi.com/Glavier/api/gmailnator
// Each free key gives 50 generations/day — keys rotate automatically.
const HARDCODED_KEYS: string[] = [
  "e9b0fdba6bmsh970f41e51594567p178216jsn8158f0ea5df7",
  "894c8f0b44msh483bb59b42c084ap15db0bjsne64fe8ccbbd4",
];
// ─────────────────────────────────────────────────────────────────────────

const RAPID_HOST = "gmailnator.p.rapidapi.com";
const RAPID_BASE = `https://${RAPID_HOST}`;

function getActiveKeys(): string[] {
  const envKey = process.env.RAPIDAPI_KEY;
  const envKeys = process.env.RAPIDAPI_KEYS
    ? process.env.RAPIDAPI_KEYS.split(",").map((k) => k.trim()).filter(Boolean)
    : [];
  const hardcoded = HARDCODED_KEYS.filter(Boolean);
  const combined = [...new Set([...hardcoded, ...envKeys, ...(envKey ? [envKey] : [])])];
  return combined;
}

let keyIndex = 0;

function nextKey(): string | null {
  const keys = getActiveKeys();
  if (keys.length === 0) return null;
  const key = keys[keyIndex % keys.length];
  keyIndex = (keyIndex + 1) % keys.length;
  return key;
}

function rapidHeaders(key: string) {
  return {
    "Content-Type": "application/json",
    "X-RapidAPI-Key": key,
    "X-RapidAPI-Host": RAPID_HOST,
  };
}

interface GmailnatorGenerateResponse {
  status: string;
  email: string;
  type: string;
}

interface GmailnatorMessage {
  id?: string;
  message_id?: string;
  from?: string;
  subject?: string;
  date?: string;
  body?: string;
  content?: string;
  text?: string;
  html?: string;
  [key: string]: unknown;
}

interface GmailnatorInboxResponse {
  status: string;
  messages: GmailnatorMessage[];
  message_count: number;
}

router.post("/gmailnator/generate", async (req, res): Promise<void> => {
  const key = nextKey();

  if (!key) {
    res.status(503).json({ error: "No API keys configured. Please add a RapidAPI key." });
    return;
  }

  const { type } = req.body as { type?: string };
  const payload = type && type !== "any" ? { type } : {};

  try {
    const r = await fetch(`${RAPID_BASE}/api/emails/generate`, {
      method: "POST",
      headers: rapidHeaders(key),
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(10000),
    });
    const data = await r.json() as GmailnatorGenerateResponse;
    if (data.status !== "success" || !data.email) {
      res.status(502).json({ error: "Failed to generate Gmail address. The API key may have hit its daily limit." });
      return;
    }
    const totalKeys = getActiveKeys().length;
    logger.info({ keyIndex: ((keyIndex - 1 + totalKeys) % totalKeys) + 1, totalKeys }, "Gmailnator key used");
    res.json({ email: data.email, type: data.type, source: "gmailnator" });
  } catch (err) {
    logger.error({ err }, "Gmailnator generate error");
    res.status(502).json({ error: "Could not reach the Gmail API. Please try again." });
  }
});

router.post("/gmailnator/inbox", async (req, res): Promise<void> => {
  const key = nextKey();

  if (!key) {
    res.status(503).json({ error: "No API keys configured. Please add a RapidAPI key." });
    return;
  }

  const { email } = req.body as { email?: string };
  if (!email || typeof email !== "string") {
    res.status(400).json({ error: "email is required." });
    return;
  }

  try {
    const r = await fetch(`${RAPID_BASE}/api/inbox`, {
      method: "POST",
      headers: rapidHeaders(key),
      body: JSON.stringify({ email }),
      signal: AbortSignal.timeout(10000),
    });
    const data = await r.json() as GmailnatorInboxResponse;
    res.json({
      messages: data.messages ?? [],
      message_count: data.message_count ?? 0,
      source: "gmailnator",
    });
  } catch (err) {
    logger.error({ err }, "Gmailnator inbox error");
    res.status(502).json({ error: "Could not fetch inbox. Please try again." });
  }
});

export default router;
