import { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { SeoHead } from "@/components/SeoHead";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import {
  ChevronRight, Clock, Calendar, ArrowRight, ArrowLeft,
  Wrench, Info, Lightbulb, AlertTriangle, BookOpen, List,
} from "lucide-react";
import {
  BLOG_POSTS, BLOG_CATEGORIES, getBlogPostBySlug, getRelatedPosts,
  type BlogSection, type BlogPost,
} from "@/lib/blog-data";
import NotFound from "@/pages/not-found";

const SITE_URL = "https://xtoolkit.live";

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
}

function ReadingProgress() {
  const [progress, setProgress] = useState(0);
  useEffect(() => {
    const update = () => {
      const el = document.documentElement;
      const scrolled = el.scrollTop || document.body.scrollTop;
      const height = el.scrollHeight - el.clientHeight;
      setProgress(height > 0 ? Math.min(100, (scrolled / height) * 100) : 0);
    };
    window.addEventListener("scroll", update, { passive: true });
    update();
    return () => window.removeEventListener("scroll", update);
  }, []);
  return (
    <div className="fixed top-0 left-0 right-0 z-[60] h-[2px] bg-transparent pointer-events-none">
      <div
        className="h-full bg-primary transition-none"
        style={{ width: `${progress}%` }}
      />
    </div>
  );
}

function TableOfContents({ post }: { post: BlogPost }) {
  const headings = post.content.filter((s) => s.type === "h2" && s.heading);
  if (headings.length < 3) return null;
  return (
    <div className="rounded-xl border border-border/60 bg-card/40 p-4 space-y-2 mb-8">
      <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
        <List className="h-3.5 w-3.5" /> Contents
      </div>
      <ol className="space-y-1.5">
        {headings.map((s, i) => (
          <li key={i}>
            <a
              href={`#h2-${i}`}
              className="text-sm text-muted-foreground hover:text-primary transition-colors hover:underline flex items-center gap-2"
            >
              <span className="text-[10px] font-bold text-primary/50 w-4">{i + 1}.</span>
              {s.heading}
            </a>
          </li>
        ))}
      </ol>
    </div>
  );
}

function SectionRenderer({ section, h2Index }: { section: BlogSection; h2Index?: number }) {
  switch (section.type) {
    case "intro":
      return (
        <p className="text-base text-muted-foreground leading-relaxed border-l-2 border-primary/30 pl-4 italic">
          {section.text}
        </p>
      );

    case "h2":
      return (
        <div className="space-y-3" id={h2Index !== undefined ? `h2-${h2Index}` : undefined}>
          <h2 className="text-xl font-bold tracking-tight scroll-mt-20">{section.heading}</h2>
          {section.text && <p className="text-sm text-muted-foreground leading-relaxed">{section.text}</p>}
        </div>
      );

    case "h3":
      return (
        <div className="space-y-2">
          <h3 className="text-base font-semibold">{section.heading}</h3>
          {section.text && <p className="text-sm text-muted-foreground leading-relaxed">{section.text}</p>}
        </div>
      );

    case "p":
      return <p className="text-sm text-muted-foreground leading-relaxed">{section.text}</p>;

    case "ul":
      return (
        <ul className="space-y-2">
          {section.items?.map((item, i) => (
            <li key={i} className="flex items-start gap-2.5 text-sm text-muted-foreground">
              <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-primary/60 shrink-0" />
              <span className="leading-relaxed">{item}</span>
            </li>
          ))}
        </ul>
      );

    case "ol":
      return (
        <ol className="space-y-2.5">
          {section.items?.map((item, i) => (
            <li key={i} className="flex items-start gap-3 text-sm text-muted-foreground">
              <span className="shrink-0 h-5 w-5 rounded-full bg-primary/10 border border-primary/20 text-[10px] font-bold text-primary flex items-center justify-center mt-0.5">
                {i + 1}
              </span>
              <span className="leading-relaxed">{item}</span>
            </li>
          ))}
        </ol>
      );

    case "code":
      return (
        <pre className="rounded-xl border border-border/60 bg-muted/40 px-4 py-3.5 text-xs font-mono text-foreground/80 overflow-x-auto whitespace-pre-wrap leading-relaxed">
          <code>{section.code}</code>
        </pre>
      );

    case "callout": {
      const icons = { info: Info, tip: Lightbulb, warning: AlertTriangle };
      const colors = {
        info: "bg-blue-500/8 border-blue-500/20 text-blue-400",
        tip: "bg-emerald-500/8 border-emerald-500/20 text-emerald-400",
        warning: "bg-amber-500/8 border-amber-500/20 text-amber-400",
      };
      const type = section.calloutType ?? "info";
      const Icon = icons[type];
      return (
        <div className={`flex gap-3 rounded-xl border px-4 py-3.5 ${colors[type]}`}>
          <Icon className="h-4 w-4 shrink-0 mt-0.5" />
          <p className="text-sm leading-relaxed">{section.text}</p>
        </div>
      );
    }

    case "faq":
      return (
        <div className="space-y-3">
          <h2 className="text-lg font-bold tracking-tight">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible className="space-y-2">
            {section.faqs?.map(({ q, a }, i) => (
              <AccordionItem
                key={i}
                value={`faq-${i}`}
                className="rounded-xl border border-border/60 bg-card/40 px-5 data-[state=open]:bg-card/70 transition-colors"
              >
                <AccordionTrigger className="text-sm font-medium text-left hover:no-underline py-4 hover:text-primary transition-colors">
                  {q}
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground pb-4 leading-relaxed">
                  {a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      );

    default:
      return null;
  }
}

export default function BlogArticle({ slug }: { slug: string }) {
  const post = getBlogPostBySlug(slug);
  const [, navigate] = useLocation();

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  if (!post) return <NotFound />;

  const cat = BLOG_CATEGORIES[post.category];
  const related = getRelatedPosts(post, 3);
  const canonicalUrl = `${SITE_URL}/blog/${post.slug}`;

  const allFaqSections = post.content.filter((s) => s.type === "faq").flatMap((s) => s.faqs ?? []);

  const articleSchema = {
    "@context": "https://schema.org",
    "@type": "Article",
    "@id": canonicalUrl,
    headline: post.title,
    description: post.description,
    url: canonicalUrl,
    datePublished: post.publishedAt,
    dateModified: post.publishedAt,
    keywords: post.tags.join(", "),
    inLanguage: "en-US",
    author: { "@type": "Organization", name: "X Toolkit", url: SITE_URL },
    publisher: { "@type": "Organization", name: "X Toolkit", url: SITE_URL },
    isPartOf: { "@type": "Blog", "@id": `${SITE_URL}/blog`, url: `${SITE_URL}/blog` },
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
      { "@type": "ListItem", position: 2, name: "Blog", item: `${SITE_URL}/blog` },
      { "@type": "ListItem", position: 3, name: post.title, item: canonicalUrl },
    ],
  };

  const allPosts = BLOG_POSTS;
  const currentIdx = allPosts.findIndex((p) => p.slug === slug);
  const prevPost = currentIdx > 0 ? allPosts[currentIdx - 1] : null;
  const nextPost = currentIdx < allPosts.length - 1 ? allPosts[currentIdx + 1] : null;

  // Track h2 index for TOC anchors
  let h2Count = 0;

  return (
    <Layout>
      <ReadingProgress />
      <SeoHead
        title={`${post.title} | X Toolkit Blog`}
        description={post.description}
        path={`/blog/${post.slug}`}
        faqs={allFaqSections}
        extraSchemas={[articleSchema, breadcrumbSchema]}
      />

      <div className="max-w-3xl mx-auto px-4 md:px-8 py-10 md:py-14">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-1.5 text-xs text-muted-foreground mb-8">
          <Link href="/"><span className="hover:text-foreground transition-colors cursor-pointer">Home</span></Link>
          <ChevronRight className="h-3 w-3" />
          <Link href="/blog"><span className="hover:text-foreground transition-colors cursor-pointer">Blog</span></Link>
          <ChevronRight className="h-3 w-3" />
          <span className={`font-medium ${cat.color} line-clamp-1`}>{cat.label}</span>
        </nav>

        {/* Header */}
        <header className="mb-8 space-y-4">
          <div className="flex flex-wrap items-center gap-2">
            <span className={`text-[10px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-lg border ${cat.bg} ${cat.color}`}>
              {cat.label}
            </span>
            <span className="text-xs text-muted-foreground flex items-center gap-1.5">
              <Clock className="h-3.5 w-3.5" /> {post.readingTime} min read
            </span>
            <span className="text-xs text-muted-foreground flex items-center gap-1.5">
              <Calendar className="h-3.5 w-3.5" /> {formatDate(post.publishedAt)}
            </span>
          </div>

          <h1 className="text-2xl md:text-3xl font-bold tracking-tight leading-snug">{post.title}</h1>
          <p className="text-muted-foreground leading-relaxed">{post.description}</p>

          <div className="flex flex-wrap gap-1.5">
            {post.tags.map((tag) => (
              <Badge key={tag} variant="outline" className="text-[10px] border-border/50 text-muted-foreground">
                {tag}
              </Badge>
            ))}
          </div>
        </header>

        {/* Table of Contents */}
        <TableOfContents post={post} />

        {/* Article body */}
        <article className="space-y-8 mb-12">
          {post.content.map((section, i) => {
            const isH2 = section.type === "h2";
            const idx = isH2 ? h2Count++ : undefined;
            return <SectionRenderer key={i} section={section} h2Index={idx} />;
          })}
        </article>

        {/* Related tools */}
        {post.relatedTools.length > 0 && (
          <section className="mb-12 rounded-2xl border border-primary/20 bg-primary/5 p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Wrench className="h-4 w-4 text-primary" />
              <h2 className="text-sm font-semibold">Free tools mentioned in this article</h2>
            </div>
            <div className="grid sm:grid-cols-2 gap-2">
              {post.relatedTools.map(({ label, href }) => (
                <Link key={href} href={href}>
                  <div className="flex items-center gap-2 rounded-xl border border-border/60 bg-background/60 px-3 py-2.5 hover:border-primary/30 hover:bg-card transition-all cursor-pointer group">
                    <div className="h-6 w-6 rounded-md bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                      <Wrench className="h-3 w-3 text-primary" />
                    </div>
                    <span className="text-xs font-medium group-hover:text-primary transition-colors flex-1">{label}</span>
                    <ArrowRight className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity text-primary" />
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Prev/Next nav */}
        <nav className="grid sm:grid-cols-2 gap-3 mb-12">
          {prevPost ? (
            <Link href={`/blog/${prevPost.slug}`}>
              <div className="rounded-xl border border-border/60 bg-card/40 p-4 hover:border-primary/30 hover:bg-card transition-all cursor-pointer group">
                <div className="flex items-center gap-1 text-[10px] text-muted-foreground mb-2">
                  <ArrowLeft className="h-3 w-3" /> Previous
                </div>
                <p className="text-xs font-medium group-hover:text-primary transition-colors line-clamp-2">{prevPost.title}</p>
              </div>
            </Link>
          ) : <div />}
          {nextPost ? (
            <Link href={`/blog/${nextPost.slug}`}>
              <div className="rounded-xl border border-border/60 bg-card/40 p-4 hover:border-primary/30 hover:bg-card transition-all cursor-pointer group text-right">
                <div className="flex items-center justify-end gap-1 text-[10px] text-muted-foreground mb-2">
                  Next <ArrowRight className="h-3 w-3" />
                </div>
                <p className="text-xs font-medium group-hover:text-primary transition-colors line-clamp-2">{nextPost.title}</p>
              </div>
            </Link>
          ) : <div />}
        </nav>

        {/* Related articles */}
        {related.length > 0 && (
          <section className="mb-12 space-y-4">
            <div className="flex items-center gap-2">
              <BookOpen className="h-4 w-4 text-primary" />
              <h2 className="text-lg font-bold tracking-tight">Related Articles</h2>
            </div>
            <div className="space-y-3">
              {related.map((rp) => {
                const rcat = BLOG_CATEGORIES[rp.category];
                return (
                  <Link key={rp.slug} href={`/blog/${rp.slug}`}>
                    <div className="flex items-start gap-3 rounded-xl border border-border/60 bg-card/40 p-4 hover:border-primary/30 hover:bg-card transition-all cursor-pointer group">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`text-[10px] font-semibold uppercase tracking-wider ${rcat.color}`}>{rcat.label}</span>
                          <span className="text-[10px] text-muted-foreground">{rp.readingTime} min</span>
                        </div>
                        <h3 className="text-sm font-medium group-hover:text-primary transition-colors line-clamp-1">{rp.title}</h3>
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{rp.description}</p>
                      </div>
                      <ArrowRight className="h-4 w-4 text-muted-foreground/40 group-hover:text-primary transition-colors shrink-0 mt-1" />
                    </div>
                  </Link>
                );
              })}
            </div>
          </section>
        )}

        {/* Back to blog */}
        <div className="flex items-center justify-between pt-6 border-t border-border/40">
          <Link href="/blog">
            <button className="flex items-center gap-2 text-xs text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="h-3.5 w-3.5" /> All articles
            </button>
          </Link>
          <Link href="/tools">
            <button className="flex items-center gap-2 text-xs text-primary hover:text-primary/80 transition-colors">
              Browse free tools <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </Link>
        </div>
      </div>
    </Layout>
  );
}
