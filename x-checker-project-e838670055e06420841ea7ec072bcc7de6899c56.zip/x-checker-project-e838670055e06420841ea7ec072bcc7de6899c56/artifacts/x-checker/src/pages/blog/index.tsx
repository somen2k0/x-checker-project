import { useState, useMemo } from "react";
import { Link } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { SeoHead } from "@/components/SeoHead";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, Clock, BookOpen, Search, ArrowRight } from "lucide-react";
import { BLOG_POSTS, BLOG_CATEGORIES, type BlogCategory } from "@/lib/blog-data";

const POSTS_PER_PAGE = 6;
const SITE_URL = "https://xtoolkit.live";

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
}

export default function BlogIndex() {
  const [activeCategory, setActiveCategory] = useState<BlogCategory | "all">("all");
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    let posts = BLOG_POSTS;
    if (activeCategory !== "all") posts = posts.filter((p) => p.category === activeCategory);
    if (search.trim()) {
      const q = search.toLowerCase();
      posts = posts.filter(
        (p) => p.title.toLowerCase().includes(q) || p.description.toLowerCase().includes(q) || p.tags.some((t) => t.includes(q)),
      );
    }
    return posts;
  }, [activeCategory, search]);

  const totalPages = Math.ceil(filtered.length / POSTS_PER_PAGE);
  const paginated = filtered.slice((page - 1) * POSTS_PER_PAGE, page * POSTS_PER_PAGE);

  const blogListSchema = {
    "@context": "https://schema.org",
    "@type": "Blog",
    "@id": `${SITE_URL}/blog`,
    url: `${SITE_URL}/blog`,
    name: "X Toolkit Blog",
    description: "Practical guides on SEO, developer tools, email tools, and X/Twitter growth.",
    blogPost: BLOG_POSTS.map((p) => ({
      "@type": "BlogPosting",
      headline: p.title,
      description: p.description,
      url: `${SITE_URL}/blog/${p.slug}`,
      datePublished: p.publishedAt,
      keywords: p.tags.join(", "),
    })),
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
      { "@type": "ListItem", position: 2, name: "Blog", item: `${SITE_URL}/blog` },
    ],
  };

  return (
    <Layout>
      <SeoHead
        title="Blog — SEO, Developer Tools & Email Guides | X Toolkit"
        description="Practical guides on JSON validation, Base64 encoding, meta tag best practices, keyword density, Twitter bio writing, and disposable email. Free resources for developers and marketers."
        path="/blog"
        extraSchemas={[blogListSchema, breadcrumbSchema]}
      />

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border/50 bg-gradient-to-br from-primary/6 via-primary/2 to-transparent">
        <div className="max-w-5xl mx-auto px-4 md:px-8 pt-10 pb-12 md:pt-14 md:pb-16">
          <nav className="flex items-center gap-1.5 text-xs text-muted-foreground mb-6">
            <Link href="/"><span className="hover:text-foreground transition-colors cursor-pointer">Home</span></Link>
            <ChevronRight className="h-3 w-3" />
            <span className="font-medium text-foreground">Blog</span>
          </nav>

          <div className="flex items-center gap-3 mb-4">
            <div className="h-12 w-12 rounded-xl border border-primary/20 bg-primary/10 flex items-center justify-center">
              <BookOpen className="h-6 w-6 text-primary" />
            </div>
            <Badge variant="outline" className="border-primary/30 text-primary bg-primary/8 text-xs font-medium">
              {BLOG_POSTS.length} Articles
            </Badge>
          </div>

          <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-3">X Toolkit Blog</h1>
          <p className="text-muted-foreground max-w-xl text-sm md:text-base mb-8">
            Practical guides on SEO, developer tools, email tools, and X/Twitter growth. Written for developers, marketers, and creators.
          </p>

          {/* Search */}
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/50" />
            <input
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder="Search articles…"
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-border/60 bg-background/60 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground/40"
            />
          </div>
        </div>
      </section>

      <div className="max-w-5xl mx-auto px-4 md:px-8 py-10">
        {/* Category filters */}
        <div className="flex flex-wrap gap-2 mb-8">
          <button
            onClick={() => { setActiveCategory("all"); setPage(1); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${activeCategory === "all" ? "bg-primary/10 border-primary/30 text-primary" : "bg-muted/30 border-border/50 text-muted-foreground hover:border-border"}`}
          >
            All ({BLOG_POSTS.length})
          </button>
          {(Object.entries(BLOG_CATEGORIES) as [BlogCategory, typeof BLOG_CATEGORIES[BlogCategory]][]).map(([key, cat]) => {
            const count = BLOG_POSTS.filter((p) => p.category === key).length;
            if (count === 0) return null;
            return (
              <button
                key={key}
                onClick={() => { setActiveCategory(key); setPage(1); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all ${activeCategory === key ? `${cat.bg} ${cat.color}` : "bg-muted/30 border-border/50 text-muted-foreground hover:border-border"}`}
              >
                {cat.label} ({count})
              </button>
            );
          })}
        </div>

        {/* Grid */}
        {paginated.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <Search className="h-8 w-8 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No articles found for "{search}"</p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5 mb-10">
            {paginated.map((post) => {
              const cat = BLOG_CATEGORIES[post.category];
              return (
                <Link key={post.slug} href={`/blog/${post.slug}`}>
                  <article className="group h-full flex flex-col rounded-2xl border border-border/60 bg-card/40 hover:border-primary/30 hover:bg-card hover:shadow-sm transition-all cursor-pointer overflow-hidden">
                    {/* Category bar */}
                    <div className={`h-1 w-full ${post.category === "developer" ? "bg-orange-400/60" : post.category === "seo" ? "bg-pink-400/60" : post.category === "email" ? "bg-cyan-400/60" : post.category === "social-media" ? "bg-blue-400/60" : "bg-purple-400/60"}`} />
                    <div className="p-5 flex flex-col gap-3 flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md border ${cat.bg} ${cat.color}`}>
                          {cat.label}
                        </span>
                        <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                          <Clock className="h-3 w-3" /> {post.readingTime} min read
                        </span>
                      </div>

                      <h2 className="text-sm font-semibold leading-snug group-hover:text-primary transition-colors line-clamp-2">
                        {post.title}
                      </h2>

                      <p className="text-xs text-muted-foreground leading-relaxed line-clamp-3 flex-1">
                        {post.description}
                      </p>

                      <div className="flex items-center justify-between pt-2 border-t border-border/40">
                        <time className="text-[10px] text-muted-foreground/60">{formatDate(post.publishedAt)}</time>
                        <span className="text-[10px] text-primary flex items-center gap-1 group-hover:gap-2 transition-all">
                          Read <ArrowRight className="h-3 w-3" />
                        </span>
                      </div>
                    </div>
                  </article>
                </Link>
              );
            })}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="px-3 py-1.5 text-xs rounded-lg border border-border/60 text-muted-foreground hover:text-foreground hover:border-border disabled:opacity-40 disabled:cursor-not-allowed transition-all"
            >
              ← Previous
            </button>
            {Array.from({ length: totalPages }, (_, i) => (
              <button
                key={i}
                onClick={() => setPage(i + 1)}
                className={`w-8 h-8 text-xs rounded-lg border transition-all ${page === i + 1 ? "bg-primary/10 border-primary/30 text-primary font-medium" : "border-border/60 text-muted-foreground hover:border-border"}`}
              >
                {i + 1}
              </button>
            ))}
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="px-3 py-1.5 text-xs rounded-lg border border-border/60 text-muted-foreground hover:text-foreground hover:border-border disabled:opacity-40 disabled:cursor-not-allowed transition-all"
            >
              Next →
            </button>
          </div>
        )}

        {/* Bottom CTA */}
        <div className="mt-14 rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-primary/4 to-transparent p-8 text-center">
          <h2 className="text-xl font-bold tracking-tight mb-2">Try the free tools</h2>
          <p className="text-muted-foreground text-sm max-w-md mx-auto mb-6">
            Every article links to a free tool you can use instantly — no signup, no install.
          </p>
          <Link href="/tools">
            <button className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2.5 rounded-xl text-sm font-medium shadow-sm shadow-primary/20 hover:bg-primary/90 transition-colors">
              Browse All Tools <ArrowRight className="h-4 w-4" />
            </button>
          </Link>
        </div>
      </div>
    </Layout>
  );
}
