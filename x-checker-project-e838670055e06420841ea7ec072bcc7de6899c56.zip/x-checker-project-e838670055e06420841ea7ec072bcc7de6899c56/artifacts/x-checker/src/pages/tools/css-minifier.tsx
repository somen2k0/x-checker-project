import { useState, useCallback } from "react";
import { MiniToolLayout } from "@/components/layout/MiniToolLayout";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Paintbrush, Copy, Trash2, Download, Minimize2, BarChart2 } from "lucide-react";

const faqs = [
  { q: "What is CSS minification?", a: "CSS minification removes unnecessary characters from CSS code without changing its functionality. This includes whitespace, line breaks, comments, and redundant semicolons. The result is a smaller file that loads faster in browsers." },
  { q: "How much does minification reduce CSS file size?", a: "Typically 20–40% for hand-written CSS and up to 60% for verbose or commented CSS. The exact savings depend on how much whitespace and comments are in the original file." },
  { q: "Will minified CSS look different in the browser?", a: "No — the rendered styles are identical. Minification only removes characters that browsers ignore anyway. The visual output of the page is unchanged." },
  { q: "Should I serve minified CSS in production?", a: "Yes — always serve minified CSS in production. Smaller files mean faster downloads, lower bandwidth costs, and better Core Web Vitals scores (specifically LCP and FID)." },
  { q: "Does this tool remove CSS comments?", a: "Yes — all standard CSS comments (/* ... */) are removed during minification. If you need to preserve a comment (such as a license header), use a build tool like PostCSS with a comment-preserving plugin instead." },
  { q: "Is it safe to paste my CSS here?", a: "Yes — all processing runs entirely in your browser using JavaScript. Your CSS is never sent to any server." },
];

const relatedTools = [
  { title: "HTML Formatter", href: "/tools/html-formatter", description: "Format and beautify HTML markup with proper indentation." },
  { title: "JSON Formatter", href: "/tools/json-formatter", description: "Format and validate JSON with real-time error detection." },
  { title: "SQL Formatter", href: "/tools/sql-formatter", description: "Format SQL queries with keyword capitalization." },
  { title: "URL Encoder / Decoder", href: "/tools/url-encoder", description: "Encode and decode URLs and query strings." },
];

const EXAMPLE_CSS = `/* Main stylesheet for X Toolkit */

/* Reset */
*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

/* Typography */
body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  font-size: 16px;
  line-height: 1.6;
  color: #1a1a1a;
  background-color: #ffffff;
}

h1, h2, h3, h4, h5, h6 {
  font-weight: 700;
  line-height: 1.2;
  margin-bottom: 0.75rem;
}

/* Links */
a {
  color: #3b82f6;
  text-decoration: underline;
  transition: color 0.2s ease;
}

a:hover {
  color: #1d4ed8;
}

/* Buttons */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 0.5rem 1rem;
  border-radius: 0.5rem;
  border: 1px solid transparent;
  font-size: 0.875rem;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-primary {
  background-color: #3b82f6;
  color: #ffffff;
  border-color: #3b82f6;
}

.btn-primary:hover {
  background-color: #2563eb;
  border-color: #2563eb;
}`;

function minifyCSS(css: string): string {
  return css
    .replace(/\/\*[\s\S]*?\*\//g, "")
    .replace(/\s+/g, " ")
    .replace(/\s*{\s*/g, "{")
    .replace(/\s*}\s*/g, "}")
    .replace(/\s*:\s*/g, ":")
    .replace(/\s*;\s*/g, ";")
    .replace(/\s*,\s*/g, ",")
    .replace(/;}/g, "}")
    .replace(/\s*>\s*/g, ">")
    .replace(/\s*~\s*/g, "~")
    .replace(/\s*\+\s*/g, "+")
    .trim();
}

export default function CssMinifier() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const { toast } = useToast();

  const handleMinify = useCallback(() => {
    if (!input.trim()) return;
    setOutput(minifyCSS(input));
  }, [input]);

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    toast({ title: "Copied!", description: "Minified CSS copied to clipboard." });
  };

  const handleDownload = () => {
    if (!output) return;
    const blob = new Blob([output], { type: "text/css" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "styles.min.css";
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Downloaded!", description: "styles.min.css saved." });
  };

  const originalSize = new Blob([input]).size;
  const minifiedSize = new Blob([output]).size;
  const savings = originalSize > 0 && minifiedSize > 0
    ? Math.round((1 - minifiedSize / originalSize) * 100)
    : 0;

  return (
    <MiniToolLayout
      seoTitle="CSS Minifier Online Free — Compress & Minify CSS Instantly"
      seoDescription="Minify and compress CSS files online for free. Removes whitespace, comments, and redundant characters. 100% client-side — instant and safe."
      icon={Paintbrush}
      badge="Developer Tool"
      title="CSS Minifier"
      description="Paste your CSS to remove whitespace, comments, and redundant characters instantly. See the size savings before downloading or copying the minified output."
      faqs={faqs}
      relatedTools={relatedTools}
    >
      <div className="space-y-4">
        <div className="grid md:grid-cols-2 gap-3">
          {/* Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">Original CSS</span>
              <div className="flex gap-2">
                <button onClick={() => { setInput(EXAMPLE_CSS); setOutput(""); }} className="text-[11px] text-primary/70 hover:text-primary underline underline-offset-2 transition-colors">Load example</button>
                {input && <span className="text-[10px] font-mono text-muted-foreground/60 bg-muted/50 px-1.5 py-0.5 rounded">{(originalSize / 1024).toFixed(1)} KB</span>}
              </div>
            </div>
            <textarea
              value={input}
              onChange={(e) => { setInput(e.target.value); setOutput(""); }}
              placeholder="Paste your CSS here…"
              spellCheck={false}
              className="w-full min-h-[340px] md:min-h-[420px] resize-y rounded-xl border border-border/60 bg-background/60 px-4 py-3 font-mono text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground/35"
            />
          </div>

          {/* Output */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">Minified CSS</span>
              {output && (
                <span className="text-[10px] font-mono text-muted-foreground/60 bg-muted/50 px-1.5 py-0.5 rounded">
                  {(minifiedSize / 1024).toFixed(1)} KB
                </span>
              )}
            </div>
            <div className={`relative w-full min-h-[340px] md:min-h-[420px] rounded-xl border bg-muted/20 overflow-auto ${output ? "border-border/60" : "border-border/40 border-dashed"}`}>
              {output ? (
                <pre className="px-4 py-3 font-mono text-xs leading-relaxed text-foreground/90 whitespace-pre-wrap break-all">{output}</pre>
              ) : (
                <div className="absolute inset-0 flex items-center justify-center text-sm text-muted-foreground/40">
                  Minified output appears here
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Size savings badge */}
        {output && savings > 0 && (
          <div className="flex items-center gap-2 text-sm bg-green-500/10 border border-green-500/25 text-green-500 rounded-xl px-4 py-2.5">
            <BarChart2 className="h-4 w-4 shrink-0" />
            Saved {savings}% — {(originalSize / 1024).toFixed(1)} KB → {(minifiedSize / 1024).toFixed(1)} KB
          </div>
        )}

        {/* Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={handleMinify} disabled={!input.trim()} className="text-xs gap-1.5 shadow-sm shadow-primary/20">
            <Minimize2 className="h-3.5 w-3.5" /> Minify CSS
          </Button>
          <div className="flex-1" />
          <Button variant="outline" size="sm" onClick={handleCopy} disabled={!output} className="text-xs gap-1.5 border-border/60">
            <Copy className="h-3.5 w-3.5" /> Copy
          </Button>
          <Button variant="outline" size="sm" onClick={handleDownload} disabled={!output} className="text-xs gap-1.5 border-border/60">
            <Download className="h-3.5 w-3.5" /> Download .min.css
          </Button>
          <Button variant="ghost" size="sm" onClick={() => { setInput(""); setOutput(""); }} disabled={!input && !output} className="text-xs gap-1.5 text-muted-foreground">
            <Trash2 className="h-3.5 w-3.5" /> Clear
          </Button>
        </div>
      </div>
    </MiniToolLayout>
  );
}
