import { useState, useMemo } from "react";
import { MiniToolLayout } from "@/components/layout/MiniToolLayout";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { KeyRound, Copy, Trash2, CheckCircle2, XCircle, Clock, AlertTriangle } from "lucide-react";

const faqs = [
  { q: "What is a JWT?", a: "A JSON Web Token (JWT) is a compact, URL-safe token format used to securely transmit information between parties. It consists of three Base64-encoded parts separated by dots: the header (algorithm), the payload (claims/data), and the signature for verification." },
  { q: "Is it safe to paste my JWT here?", a: "Yes — all decoding happens entirely in your browser using JavaScript. No token is ever sent to a server. That said, JWTs may contain sensitive data, so avoid sharing them publicly." },
  { q: "Can this tool verify JWT signatures?", a: "No — signature verification requires the secret key or public certificate, which this browser-side tool cannot access. This tool decodes and inspects the header and payload only. For signature verification, use a trusted server-side library." },
  { q: "What is the 'exp' claim in a JWT?", a: "The 'exp' (expiration time) claim is a Unix timestamp that indicates when the token expires. This tool automatically detects it and shows whether your token is expired or still valid." },
  { q: "What does the 'alg' field in the JWT header mean?", a: "The 'alg' field specifies the cryptographic algorithm used to sign the token, such as HS256 (HMAC-SHA256), RS256 (RSA-SHA256), or ES256 (ECDSA-SHA256)." },
  { q: "Why does my JWT have three parts?", a: "Every JWT has exactly three Base64URL-encoded parts: [header].[payload].[signature]. The header describes the token type and algorithm, the payload contains the claims (user ID, permissions, expiry), and the signature proves the token hasn't been tampered with." },
];

const relatedTools = [
  { title: "Base64 Encoder / Decoder", href: "/tools/base64", description: "Encode and decode Base64 strings with Unicode support." },
  { title: "JSON Formatter", href: "/tools/json-formatter", description: "Format and validate JSON with real-time error detection." },
  { title: "Regex Tester", href: "/tools/regex-tester", description: "Test regular expressions with live match highlighting." },
  { title: "URL Encoder / Decoder", href: "/tools/url-encoder", description: "Encode and decode URLs and query strings." },
];

const EXAMPLE_JWT = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkFsZXggSm9obnNvbiIsImVtYWlsIjoiYWxleEBleGFtcGxlLmNvbSIsInJvbGUiOiJhZG1pbiIsImlhdCI6MTcwMDAwMDAwMCwiZXhwIjoxNzAwMDg2NDAwfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";

function b64Decode(str: string): string {
  const base64 = str.replace(/-/g, "+").replace(/_/g, "/");
  const padded = base64.padEnd(base64.length + (4 - (base64.length % 4)) % 4, "=");
  try {
    return decodeURIComponent(
      atob(padded)
        .split("")
        .map((c) => "%" + c.charCodeAt(0).toString(16).padStart(2, "0"))
        .join("")
    );
  } catch {
    return atob(padded);
  }
}

function parseJwt(token: string) {
  const parts = token.trim().split(".");
  if (parts.length !== 3) throw new Error("Invalid JWT: must have exactly 3 parts separated by dots.");
  const header = JSON.parse(b64Decode(parts[0]));
  const payload = JSON.parse(b64Decode(parts[1]));
  return { header, payload, signature: parts[2] };
}

function formatTs(ts: number): string {
  return new Date(ts * 1000).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

function JsonBlock({ data }: { data: object }) {
  return (
    <pre className="text-xs font-mono bg-muted/30 border border-border/50 rounded-xl px-4 py-3 overflow-x-auto whitespace-pre-wrap break-all text-foreground/85 leading-relaxed">
      {JSON.stringify(data, null, 2)}
    </pre>
  );
}

export default function JwtDecoder() {
  const [input, setInput] = useState("");
  const { toast } = useToast();

  const result = useMemo(() => {
    const token = input.trim();
    if (!token) return null;
    try {
      return { ok: true as const, ...parseJwt(token) };
    } catch (e) {
      return { ok: false as const, error: e instanceof Error ? e.message : String(e) };
    }
  }, [input]);

  const now = Math.floor(Date.now() / 1000);
  const exp = result?.ok ? (result.payload as Record<string, unknown>).exp as number | undefined : undefined;
  const iat = result?.ok ? (result.payload as Record<string, unknown>).iat as number | undefined : undefined;
  const isExpired = exp !== undefined && exp < now;

  const copy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({ title: "Copied!", description: `${label} copied to clipboard.` });
  };

  return (
    <MiniToolLayout
      seoTitle="JWT Decoder Online — Decode & Inspect JSON Web Tokens Free"
      seoDescription="Decode and inspect JWT tokens instantly in your browser. View header, payload, claims, expiry, and signature. 100% client-side — your token never leaves your device."
      icon={KeyRound}
      badge="Developer Tool"
      title="JWT Decoder"
      description="Paste any JSON Web Token to instantly decode the header, payload, and claims. Checks expiry, highlights claims, and shows the raw signature — all in your browser."
      faqs={faqs}
      relatedTools={relatedTools}
      educationalSections={[
        {
          heading: "What's Inside a JWT?",
          body: "A JWT has three parts separated by dots: header.payload.signature. The header identifies the token type and signing algorithm (e.g. HS256, RS256). The payload contains claims — sub (subject/user ID), exp (expiry timestamp), iat (issued at), and any custom claims your application adds. The signature proves the token hasn't been tampered with.",
        },
        {
          heading: "Reading the Claims",
          items: [
            "exp — expiry timestamp as Unix time. Compare to Date.now()/1000 to check if the token is expired.",
            "iat — issued-at timestamp. The difference between exp and iat tells you the token lifetime.",
            "sub — the subject: typically a user ID that identifies who the token belongs to.",
            "aud — audience: the intended recipient(s) of the token. Your server should reject tokens with the wrong aud.",
            "iss — issuer: identifies who issued the token. Useful in multi-provider auth setups.",
          ],
        },
        {
          heading: "Security Red Flags to Look For",
          items: [
            "alg: none — a token with no algorithm is unsigned. Any server that accepts this is critically vulnerable.",
            "Expired tokens — exp in the past means the token should be rejected.",
            "Sensitive data in payload — the payload is Base64URL-encoded, not encrypted. Anyone who intercepts the token can read it.",
            "Very long expiry — tokens that live for days or weeks can't be revoked if compromised.",
          ],
          callout: { type: "warning", text: "Decoding a JWT here (or anywhere client-side) does NOT verify its signature. Signature verification must happen server-side using your secret or public key. Never trust decoded claims without server-side verification." },
        },
      ]}
      relatedArticles={[
        { title: "What Is a JWT Token? A Clear Explanation with Real Examples", href: "/blog/jwt-complete-guide", readingTime: 7 },
        { title: "What Is Base64 Encoding? A Plain-English Explanation", href: "/blog/what-is-base64-encoding", readingTime: 6 },
      ]}
    >
      <div className="space-y-4">
        {/* Input */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">JWT Token</span>
            <div className="flex gap-2">
              <button onClick={() => setInput(EXAMPLE_JWT)} className="text-[11px] text-primary/70 hover:text-primary underline underline-offset-2 transition-colors">Load example</button>
              <button onClick={() => setInput("")} className="text-[11px] text-muted-foreground hover:text-foreground transition-colors">Clear</button>
            </div>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Paste your JWT here… eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.…"
            spellCheck={false}
            className="w-full min-h-[100px] resize-y rounded-xl border border-border/60 bg-background/60 px-4 py-3 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground/35"
          />
        </div>

        {/* Error */}
        {result?.ok === false && (
          <div className="flex items-center gap-2 text-sm text-destructive bg-destructive/10 border border-destructive/25 rounded-xl px-4 py-2.5">
            <XCircle className="h-4 w-4 shrink-0" /> {result.error}
          </div>
        )}

        {/* Success */}
        {result?.ok && (
          <div className="space-y-4">
            {/* Status bar */}
            <div className="flex flex-wrap gap-2">
              <div className="flex items-center gap-2 text-xs bg-green-500/10 border border-green-500/25 text-green-500 rounded-lg px-3 py-1.5">
                <CheckCircle2 className="h-3.5 w-3.5" /> Valid JWT structure
              </div>
              {exp !== undefined && (
                <div className={`flex items-center gap-2 text-xs rounded-lg px-3 py-1.5 border ${isExpired ? "bg-destructive/10 border-destructive/25 text-destructive" : "bg-green-500/10 border-green-500/25 text-green-500"}`}>
                  {isExpired ? <><AlertTriangle className="h-3.5 w-3.5" /> Expired {formatTs(exp)}</> : <><Clock className="h-3.5 w-3.5" /> Expires {formatTs(exp)}</>}
                </div>
              )}
              {iat !== undefined && (
                <div className="flex items-center gap-2 text-xs bg-muted/40 border border-border/50 text-muted-foreground rounded-lg px-3 py-1.5">
                  Issued {formatTs(iat)}
                </div>
              )}
            </div>

            {/* Header */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-red-400">Header</h3>
                <Button variant="ghost" size="sm" onClick={() => copy(JSON.stringify(result.header, null, 2), "Header")} className="text-xs gap-1 h-7"><Copy className="h-3 w-3" /> Copy</Button>
              </div>
              <JsonBlock data={result.header} />
            </div>

            {/* Payload */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-purple-400">Payload</h3>
                <Button variant="ghost" size="sm" onClick={() => copy(JSON.stringify(result.payload, null, 2), "Payload")} className="text-xs gap-1 h-7"><Copy className="h-3 w-3" /> Copy</Button>
              </div>
              <JsonBlock data={result.payload} />
            </div>

            {/* Signature */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-semibold text-blue-400">Signature</h3>
                <Button variant="ghost" size="sm" onClick={() => copy(result.signature, "Signature")} className="text-xs gap-1 h-7"><Copy className="h-3 w-3" /> Copy</Button>
              </div>
              <div className="rounded-xl border border-border/50 bg-muted/30 px-4 py-3">
                <code className="text-xs font-mono text-foreground/70 break-all">{result.signature}</code>
              </div>
              <p className="text-[11px] text-muted-foreground">Signature verification requires the secret key and must be done server-side.</p>
            </div>
          </div>
        )}

        {!input && (
          <div className="flex flex-wrap gap-2 pt-1">
            {[{ label: "100% client-side" }, { label: "Expiry detection" }, { label: "Capture group view" }, { label: "No data sent" }].map(({ label }) => (
              <div key={label} className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground bg-muted/40 border border-border/50 rounded-full px-3 py-1">
                <KeyRound className="h-3 w-3" /> {label}
              </div>
            ))}
          </div>
        )}
      </div>
    </MiniToolLayout>
  );
}
