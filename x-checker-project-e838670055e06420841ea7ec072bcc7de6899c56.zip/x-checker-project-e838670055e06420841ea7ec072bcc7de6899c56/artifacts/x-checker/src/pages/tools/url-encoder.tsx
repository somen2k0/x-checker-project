import { useState } from "react";
import { MiniToolLayout } from "@/components/layout/MiniToolLayout";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Link2, Copy, Trash2, ArrowDownUp } from "lucide-react";

const faqs = [
  { q: "What is URL encoding?", a: "URL encoding (also called percent-encoding) converts characters that are not allowed in URLs into a format that can be transmitted safely. Reserved and special characters are replaced with a percent sign followed by their two-digit hexadecimal ASCII code. For example, a space becomes %20 or +." },
  { q: "What is the difference between encodeURI and encodeURIComponent?", a: "encodeURI encodes a complete URL and leaves characters like /, :, and ? intact. encodeURIComponent encodes a URL component (like a query parameter value) and also encodes those reserved characters. Use encodeURIComponent for individual parameter values and encodeURI for full URLs." },
  { q: "Why do I see + instead of %20 for spaces?", a: "The + sign for spaces is used in application/x-www-form-urlencoded encoding (HTML forms). The RFC 3986 standard uses %20. Our tool uses percent-encoding (%20) by default, which is the correct format for URL path segments and query strings." },
  { q: "When should I decode a URL?", a: "URL decoding is useful when reading query parameters from a URL, processing webhook payloads, debugging API requests, or displaying user-friendly versions of encoded strings in logs or UIs." },
  { q: "What characters need to be encoded in a URL?", a: "Characters that must be encoded include: spaces, <, >, #, %, {, }, |, \\, ^, ~, [, ], `, and all non-ASCII characters. Reserved characters like /, ?, &, =, and # only need encoding when they appear in a component value rather than as structural delimiters." },
  { q: "Is this tool safe for encoding sensitive data?", a: "Yes — all encoding and decoding is done entirely in your browser using JavaScript's built-in encodeURIComponent and decodeURIComponent functions. Nothing is sent to a server." },
];

const relatedTools = [
  { title: "URL Slug Generator", href: "/tools/url-slug-generator", description: "Convert titles into clean, SEO-friendly URL slugs." },
  { title: "Base64 Encoder / Decoder", href: "/tools/base64", description: "Encode and decode Base64 strings with Unicode support." },
  { title: "JSON Formatter", href: "/tools/json-formatter", description: "Format and validate JSON with real-time error detection." },
  { title: "Regex Tester", href: "/tools/regex-tester", description: "Test regular expressions with live match highlighting." },
];

const EXAMPLES = [
  { label: "Query string", value: "name=Alex Johnson&city=New York&role=developer" },
  { label: "URL with params", value: "https://example.com/search?q=hello world&lang=en&page=1" },
  { label: "Special chars", value: "price=€100&note=10% off & free shipping!" },
];

type Mode = "encode" | "decode";

export default function UrlEncoder() {
  const [mode, setMode] = useState<Mode>("encode");
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [error, setError] = useState("");
  const { toast } = useToast();

  const process = (val: string, m: Mode) => {
    setInput(val);
    setError("");
    if (!val.trim()) { setOutput(""); return; }
    try {
      if (m === "encode") {
        setOutput(encodeURIComponent(val));
      } else {
        setOutput(decodeURIComponent(val.replace(/\+/g, " ")));
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Invalid input");
      setOutput("");
    }
  };

  const swap = () => {
    const newMode: Mode = mode === "encode" ? "decode" : "encode";
    setMode(newMode);
    const newInput = output;
    setOutput("");
    process(newInput, newMode);
  };

  const copy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    toast({ title: "Copied!", description: "Output copied to clipboard." });
  };

  return (
    <MiniToolLayout
      seoTitle="URL Encoder / Decoder Online — Percent-Encode & Decode URLs Free"
      seoDescription="Encode and decode URLs and query strings using percent-encoding. Instant, free, and 100% client-side. Supports full Unicode and special characters."
      icon={Link2}
      badge="Developer Tool"
      title="URL Encoder / Decoder"
      description="Encode URLs and query string values using percent-encoding, or decode encoded strings back to readable text. Instant, client-side, full Unicode support."
      faqs={faqs}
      relatedTools={relatedTools}
      educationalSections={[
        {
          heading: "When Does URL Encoding Apply?",
          items: [
            "Query string values — spaces, ampersands, equals signs, and hash characters in values must be encoded.",
            "Path segments — spaces and special characters in URL paths must be percent-encoded.",
            "Form submissions — browsers automatically encode form data as application/x-www-form-urlencoded.",
            "API parameters — any user-controlled input embedded in a URL should be encoded to prevent injection.",
            "Link building — URLs shared in emails or documents may need encoding to survive plaintext processing.",
          ],
        },
        {
          heading: "encodeURIComponent vs encodeURI",
          body: "JavaScript offers two encoding functions. encodeURI() encodes a full URL and preserves structural characters like :, /, ?, #, and &. encodeURIComponent() encodes everything except unreserved characters — use it when encoding individual query parameter values or path segments that might contain structural characters.",
          code: `encodeURIComponent("hello world & more") // → "hello%20world%20%26%20more"
encodeURI("https://example.com/my path") // → "https://example.com/my%20path"`,
          callout: { type: "tip", text: "Always use encodeURIComponent() when building URLs dynamically from user input. Raw user input concatenated into a URL can break the URL structure or enable open redirect attacks." },
        },
      ]}
      relatedArticles={[
        { title: "URL Encoding Explained: Percent-Encoding and When You Need It", href: "/blog/url-encoding-explained", readingTime: 6 },
        { title: "SEO-Friendly URL Slugs: The Complete Optimization Guide", href: "/blog/seo-url-slug-guide", readingTime: 6 },
        { title: "Regex Cheat Sheet: The Most Useful Patterns for Developers", href: "/blog/regex-cheat-sheet", readingTime: 8 },
      ]}
    >
      <div className="space-y-4">
        {/* Mode toggle */}
        <div className="flex items-center gap-2">
          <div className="flex rounded-xl border border-border/60 bg-muted/30 p-1 gap-1">
            {(["encode", "decode"] as Mode[]).map((m) => (
              <button
                key={m}
                onClick={() => { setMode(m); process(input, m); }}
                className={`px-4 py-1.5 text-sm rounded-lg transition-all capitalize ${mode === m ? "bg-background border border-border/60 shadow-sm font-medium" : "text-muted-foreground hover:text-foreground"}`}
              >
                {m}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            {EXAMPLES.map((ex) => (
              <button key={ex.label} onClick={() => { setMode("encode"); process(ex.value, "encode"); }} className="text-[11px] text-primary/70 hover:text-primary border border-border/50 hover:border-primary/30 rounded-md px-2 py-0.5 transition-colors">
                {ex.label}
              </button>
            ))}
          </div>
        </div>

        {/* Two-panel */}
        <div className="grid md:grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">
              {mode === "encode" ? "Plain Text" : "Encoded URL"}
            </span>
            <textarea
              value={input}
              onChange={(e) => process(e.target.value, mode)}
              placeholder={mode === "encode" ? "Paste text to encode…" : "Paste encoded URL to decode…"}
              spellCheck={false}
              className="w-full min-h-[200px] resize-y rounded-xl border border-border/60 bg-background/60 px-4 py-3 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground/35"
            />
          </div>

          <div className="space-y-1.5">
            <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">
              {mode === "encode" ? "Encoded URL" : "Decoded Text"}
            </span>
            <div className={`relative w-full min-h-[200px] rounded-xl border bg-muted/20 overflow-auto ${error ? "border-destructive/30" : output ? "border-border/60" : "border-border/40 border-dashed"}`}>
              {error ? (
                <div className="p-4 text-sm text-destructive">{error}</div>
              ) : output ? (
                <pre className="px-4 py-3 font-mono text-sm text-foreground/90 whitespace-pre-wrap break-all">{output}</pre>
              ) : (
                <div className="absolute inset-0 flex items-center justify-center text-sm text-muted-foreground/40">
                  Output appears here
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={swap} variant="outline" disabled={!output} className="text-xs gap-1.5 border-border/60">
            <ArrowDownUp className="h-3.5 w-3.5" /> Swap
          </Button>
          <Button onClick={copy} variant="outline" disabled={!output} size="sm" className="text-xs gap-1.5 border-border/60">
            <Copy className="h-3.5 w-3.5" /> Copy Output
          </Button>
          <Button variant="ghost" size="sm" onClick={() => { setInput(""); setOutput(""); setError(""); }} disabled={!input && !output} className="text-xs gap-1.5 text-muted-foreground">
            <Trash2 className="h-3.5 w-3.5" /> Clear
          </Button>
          {output && (
            <div className="ml-auto text-xs text-muted-foreground">
              {output.length.toLocaleString()} chars
            </div>
          )}
        </div>
      </div>
    </MiniToolLayout>
  );
}
