import { useState, useCallback } from "react";
import { MiniToolLayout } from "@/components/layout/MiniToolLayout";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Fingerprint, Copy, Trash2, Download, RefreshCw } from "lucide-react";

const faqs = [
  { q: "What is a UUID?", a: "A UUID (Universally Unique Identifier) is a 128-bit label used to uniquely identify objects in software. The standard format is eight hexadecimal characters, followed by three groups of four, followed by twelve, separated by hyphens: xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx." },
  { q: "What is UUID v4?", a: "UUID v4 is randomly generated using cryptographically secure random numbers. It's the most commonly used UUID version and has an astronomically low probability of collision — you'd need to generate over a billion UUIDs per second for over a hundred years before getting a duplicate." },
  { q: "Is it safe to use UUIDs as database primary keys?", a: "Yes — UUIDs make excellent primary keys in distributed systems because they can be generated independently on any client or server without coordination. The trade-off is slightly larger storage size compared to auto-incrementing integers." },
  { q: "Are these UUIDs truly random?", a: "Yes — this tool uses the browser's crypto.randomUUID() API, which generates cryptographically secure pseudo-random UUIDs. These are suitable for security-sensitive contexts." },
  { q: "Can I use UUIDs in URLs?", a: "Yes, UUID v4s are URL-safe when used in path segments. However, they make URLs long and hard to remember. A common pattern is to use them internally and expose shorter IDs publicly." },
  { q: "What's the difference between UUID and GUID?", a: "GUID (Globally Unique Identifier) is Microsoft's term for the same concept. GUIDs and UUIDs follow the same specification and are interchangeable in practice." },
];

const relatedTools = [
  { title: "JSON Formatter", href: "/tools/json-formatter", description: "Format and validate JSON with real-time error detection." },
  { title: "Base64 Encoder / Decoder", href: "/tools/base64", description: "Encode and decode Base64 strings." },
  { title: "Regex Tester", href: "/tools/regex-tester", description: "Test regular expressions with live match highlighting." },
  { title: "JWT Decoder", href: "/tools/jwt-decoder", description: "Decode and inspect JWT tokens in your browser." },
];

function generateUUID(): string {
  if (typeof crypto !== "undefined" && crypto.randomUUID) {
    return crypto.randomUUID();
  }
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

type UUIDCase = "lower" | "upper";
type UUIDFormat = "standard" | "no-hyphens" | "braces";

function formatUUID(uuid: string, casing: UUIDCase, format: UUIDFormat): string {
  const base = casing === "upper" ? uuid.toUpperCase() : uuid.toLowerCase();
  if (format === "no-hyphens") return base.replace(/-/g, "");
  if (format === "braces") return `{${base}}`;
  return base;
}

export default function UUIDGenerator() {
  const [count, setCount] = useState(5);
  const [casing, setCasing] = useState<UUIDCase>("lower");
  const [format, setFormat] = useState<UUIDFormat>("standard");
  const [uuids, setUuids] = useState<string[]>(() => Array.from({ length: 5 }, () => generateUUID()));
  const { toast } = useToast();

  const generate = useCallback(() => {
    setUuids(Array.from({ length: Math.min(Math.max(1, count), 100) }, () => generateUUID()));
  }, [count]);

  const formattedUuids = uuids.map((u) => formatUUID(u, casing, format));

  const copyAll = () => {
    navigator.clipboard.writeText(formattedUuids.join("\n"));
    toast({ title: "Copied!", description: `${formattedUuids.length} UUIDs copied to clipboard.` });
  };

  const copySingle = (uuid: string) => {
    navigator.clipboard.writeText(uuid);
    toast({ title: "Copied!", description: "UUID copied to clipboard." });
  };

  const download = () => {
    const blob = new Blob([formattedUuids.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "uuids.txt";
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Downloaded!", description: "uuids.txt saved." });
  };

  return (
    <MiniToolLayout
      seoTitle="UUID Generator Online — Generate Secure UUID v4 Free"
      seoDescription="Generate cryptographically secure UUID v4 identifiers in bulk. Customizable format, casing, and count. 100% client-side — instant and free."
      icon={Fingerprint}
      badge="Developer Tool"
      title="UUID Generator"
      description="Generate cryptographically secure UUID v4 identifiers instantly. Customize count, casing, and format — copy individually or download all as a text file."
      faqs={faqs}
      relatedTools={relatedTools}
    >
      <div className="space-y-4">
        {/* Controls */}
        <div className="rounded-xl border border-border/60 bg-card/40 p-4 space-y-4">
          <div className="grid sm:grid-cols-3 gap-4">
            {/* Count */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">Count</label>
              <input
                type="number"
                min={1}
                max={100}
                value={count}
                onChange={(e) => setCount(Number(e.target.value))}
                className="w-full bg-background/60 border border-border/60 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
            </div>

            {/* Casing */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">Case</label>
              <div className="flex gap-2">
                {(["lower", "upper"] as UUIDCase[]).map((c) => (
                  <button
                    key={c}
                    onClick={() => setCasing(c)}
                    className={`flex-1 text-xs py-2 rounded-lg border transition-all ${casing === c ? "bg-primary/10 border-primary/30 text-primary" : "bg-muted/30 border-border/50 text-muted-foreground hover:border-border"}`}
                  >
                    {c === "lower" ? "lowercase" : "UPPERCASE"}
                  </button>
                ))}
              </div>
            </div>

            {/* Format */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">Format</label>
              <div className="flex gap-1.5 flex-wrap">
                {([["standard", "Standard"], ["no-hyphens", "No hyphens"], ["braces", "Braces"]] as [UUIDFormat, string][]).map(([f, label]) => (
                  <button
                    key={f}
                    onClick={() => setFormat(f)}
                    className={`flex-1 text-xs py-2 rounded-lg border transition-all whitespace-nowrap ${format === f ? "bg-primary/10 border-primary/30 text-primary" : "bg-muted/30 border-border/50 text-muted-foreground hover:border-border"}`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <Button onClick={generate} className="w-full gap-2 shadow-sm shadow-primary/20">
            <RefreshCw className="h-4 w-4" /> Generate {count} UUID{count !== 1 ? "s" : ""}
          </Button>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={copyAll} className="text-xs gap-1.5 border-border/60">
            <Copy className="h-3.5 w-3.5" /> Copy All
          </Button>
          <Button variant="outline" size="sm" onClick={download} className="text-xs gap-1.5 border-border/60">
            <Download className="h-3.5 w-3.5" /> Download .txt
          </Button>
          <Button variant="ghost" size="sm" onClick={() => setUuids([])} className="text-xs gap-1.5 text-muted-foreground">
            <Trash2 className="h-3.5 w-3.5" /> Clear
          </Button>
        </div>

        {/* UUID list */}
        <div className="space-y-1.5">
          {formattedUuids.map((uuid, i) => (
            <div key={i} className="flex items-center gap-3 rounded-lg border border-border/50 bg-muted/20 px-3 py-2 group hover:border-border/80 transition-colors">
              <span className="text-[10px] font-mono text-muted-foreground/50 w-5 shrink-0">{i + 1}</span>
              <code className="flex-1 text-xs font-mono text-foreground/80 break-all">{uuid}</code>
              <button
                onClick={() => copySingle(uuid)}
                className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-foreground"
              >
                <Copy className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
          {uuids.length === 0 && (
            <div className="text-center text-sm text-muted-foreground py-10">Click Generate to create UUIDs</div>
          )}
        </div>
      </div>
    </MiniToolLayout>
  );
}
