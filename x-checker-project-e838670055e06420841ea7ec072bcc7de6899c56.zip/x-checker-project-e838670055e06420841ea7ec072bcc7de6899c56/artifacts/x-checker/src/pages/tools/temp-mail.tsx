import { useState, useEffect, useCallback, useRef } from "react";
import { Layout } from "@/components/layout/Layout";
import { SeoHead } from "@/components/SeoHead";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import {
  Inbox, Copy, RefreshCw, Trash2, Mail, Paperclip,
  Clock, CheckCircle2, AlertCircle, Timer, Zap,
  ChevronDown, Shuffle, AtSign, Plus, Sparkles,
  ArrowRight, ExternalLink,
} from "lucide-react";
import { Link } from "wouter";

const GMAILNATOR_REFRESH = 20000;

const API_BASE = "/api/temp-mail";
const REFRESH_INTERVAL = 15000;
const STORAGE_KEY = "tempmail_account_v2";

interface MailMessage {
  id: string;
  from: { address: string; name: string };
  subject: string;
  intro: string;
  createdAt: string;
  seen: boolean;
  hasAttachments: boolean;
  html?: string[];
  text?: string;
}

interface MailAccount {
  id: string;
  address: string;
  token: string;
}

function saveAccount(acc: MailAccount) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(acc)); } catch {}
}

function loadAccount(): MailAccount | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as MailAccount) : null;
  } catch { return null; }
}

function clearAccount() {
  try { localStorage.removeItem(STORAGE_KEY); } catch {}
}

function formatTime(iso: string): string {
  const d = new Date(iso);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMin = Math.floor(diffMs / 60000);
  if (diffMin < 1) return "Just now";
  if (diffMin < 60) return `${diffMin}m ago`;
  return d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}

function generateDotVariants(username: string): string[] {
  const u = username.replace(/\./g, "").toLowerCase();
  if (u.length < 2) return [`${u}@gmail.com`];
  const results: string[] = [];
  const positions = u.length - 1;
  const total = Math.pow(2, positions);
  const limit = Math.min(total, 32);
  for (let i = 0; i < limit; i++) {
    let result = u[0];
    for (let j = 0; j < positions; j++) {
      if (i & (1 << j)) result += ".";
      result += u[j + 1];
    }
    results.push(`${result}@gmail.com`);
  }
  return results;
}

const PLUS_TAGS = [
  "newsletters", "shopping", "social", "spam", "work", "promo",
  "subscriptions", "alerts", "updates", "receipts", "travel",
  "finance", "health", "gaming", "news", "jobs", "events",
  "school", "personal", "test", "noreply", "signup", "deals",
  "banking", "govt", "apps", "temp", "dev", "backup", "bulk",
];

export default function TempMail() {
  const [activeTab, setActiveTab] = useState<"inbox" | "tempgmail" | "gmail">("inbox");

  const [account, setAccount] = useState<MailAccount | null>(null);
  const [messages, setMessages] = useState<MailMessage[]>([]);
  const [selectedMsg, setSelectedMsg] = useState<MailMessage | null>(null);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [copied, setCopied] = useState(false);
  const [countdown, setCountdown] = useState(REFRESH_INTERVAL / 1000);
  const [domains, setDomains] = useState<string[]>([]);
  const [selectedDomain, setSelectedDomain] = useState<string>("");
  const [customUsername, setCustomUsername] = useState("");
  const [showDomainPicker, setShowDomainPicker] = useState(false);
  const [showCustomUsername, setShowCustomUsername] = useState(false);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const domainPickerRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const [gmailInput, setGmailInput] = useState("");
  const [gmailBase, setGmailBase] = useState("");
  const [dotVariants, setDotVariants] = useState<string[]>([]);
  const [plusVariants, setPlusVariants] = useState<string[]>([]);
  const [copiedVariant, setCopiedVariant] = useState<string | null>(null);
  const [showAllDots, setShowAllDots] = useState(false);

  // ── Temp Gmail (Gmailnator) state ──
  interface GmailnatorMsg {
    id?: string;
    message_id?: string;
    from?: string;
    subject?: string;
    date?: string;
    body?: string;
    content?: string;
    text?: string;
    html?: string;
    [key: string]: unknown;
  }
  const [tgEmail, setTgEmail] = useState<string | null>(null);
  const [tgType, setTgType] = useState<string>("");
  const [tgMessages, setTgMessages] = useState<GmailnatorMsg[]>([]);
  const [tgSelected, setTgSelected] = useState<GmailnatorMsg | null>(null);
  const [tgGenerating, setTgGenerating] = useState(false);
  const [tgRefreshing, setTgRefreshing] = useState(false);
  const [tgCopied, setTgCopied] = useState(false);
  const [tgError, setTgError] = useState<string | null>(null);
  const [tgCountdown, setTgCountdown] = useState(GMAILNATOR_REFRESH / 1000);
  const [tgDomainPref, setTgDomainPref] = useState<string>("any");
  const tgIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const tgCountdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const tgFetchInbox = useCallback(async (email: string, silent = false) => {
    if (!silent) setTgRefreshing(true);
    try {
      const r = await fetch("/api/gmailnator/inbox", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (r.ok) {
        const data = await r.json() as { messages: GmailnatorMsg[]; message_count: number };
        setTgMessages(data.messages ?? []);
      }
    } catch { }
    finally { if (!silent) setTgRefreshing(false); }
  }, []);

  const tgGenerate = useCallback(async (domainPref?: string) => {
    setTgGenerating(true);
    setTgError(null);
    setTgMessages([]);
    setTgSelected(null);
    try {
      const pref = domainPref ?? "any";
      const body = pref !== "any" ? { type: pref } : {};
      const r = await fetch("/api/gmailnator/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await r.json() as { email?: string; type?: string; error?: string };
      if (!r.ok || !data.email) {
        setTgError(data.error ?? "Could not generate a Gmail address. Please try again.");
        return;
      }
      setTgEmail(data.email);
      setTgType(data.type ?? "");
      toast({ title: "Temp Gmail ready!", description: data.email });
    } catch {
      setTgError("Network error. Please try again.");
    } finally {
      setTgGenerating(false);
    }
  }, [toast]);

  useEffect(() => {
    if (activeTab !== "tempgmail" || !tgEmail) return;
    tgFetchInbox(tgEmail, true);
    setTgCountdown(GMAILNATOR_REFRESH / 1000);
    tgIntervalRef.current = setInterval(() => tgFetchInbox(tgEmail, true), GMAILNATOR_REFRESH);
    tgCountdownRef.current = setInterval(() => setTgCountdown((c) => c <= 1 ? GMAILNATOR_REFRESH / 1000 : c - 1), 1000);
    return () => {
      if (tgIntervalRef.current) clearInterval(tgIntervalRef.current);
      if (tgCountdownRef.current) clearInterval(tgCountdownRef.current);
    };
  }, [activeTab, tgEmail, tgFetchInbox]);

  useEffect(() => {
    if (activeTab === "tempgmail" && !tgEmail && !tgGenerating && !tgError) {
      tgGenerate(tgDomainPref);
    }
  }, [activeTab, tgEmail, tgGenerating, tgGenerate, tgDomainPref, tgError]);

  useEffect(() => {
    fetch(`${API_BASE}/domains`)
      .then((r) => r.json())
      .then((d: { domains: string[] }) => {
        const active = d.domains ?? [];
        if (active.length) {
          setDomains(active);
          setSelectedDomain(active[0]);
        }
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (domainPickerRef.current && !domainPickerRef.current.contains(e.target as Node)) {
        setShowDomainPicker(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const fetchMessages = useCallback(async (acc: MailAccount, silent = false) => {
    if (!acc) return;
    if (!silent) setRefreshing(true);
    try {
      const res = await fetch(`${API_BASE}/messages`, {
        headers: { Authorization: `Bearer ${acc.token}` },
      });
      if (res.ok) {
        const data = await res.json() as { messages: MailMessage[] };
        setMessages(data.messages ?? []);
      }
    } catch {
    } finally {
      if (!silent) setRefreshing(false);
    }
  }, []);

  const [inboxError, setInboxError] = useState<string | null>(null);

  const generateAddress = useCallback(async (opts?: { username?: string; domain?: string }) => {
    setGenerating(true);
    setInboxError(null);
    setMessages([]);
    setSelectedMsg(null);
    try {
      const body: Record<string, string> = {};
      if (opts?.username) body.username = opts.username;
      if (opts?.domain) body.domain = opts.domain;
      const res = await fetch(`${API_BASE}/create`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const text = await res.text();
      const json = text ? JSON.parse(text) as { id?: string; address?: string; token?: string; error?: string } : {};
      if (!res.ok || !json.token) {
        setInboxError(json.error ?? "Could not create inbox. Please try again.");
        return;
      }
      const data: MailAccount = { id: json.id!, address: json.address!, token: json.token! };
      setAccount(data);
      saveAccount(data);
      setInboxError(null);
      toast({ title: "Inbox ready!", description: data.address });
    } catch {
      setInboxError("Could not create inbox. Please try again.");
    } finally {
      setGenerating(false);
    }
  }, [toast]);

  const fetchMessageBody = useCallback(async (msg: MailMessage) => {
    if (!account) return;
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/messages/${msg.id}`, {
        headers: { Authorization: `Bearer ${account.token}` },
      });
      if (res.ok) {
        const full = await res.json() as MailMessage;
        setSelectedMsg(full);
        setMessages((prev) => prev.map((m) => m.id === msg.id ? { ...m, seen: true } : m));
      }
    } finally {
      setLoading(false);
    }
  }, [account]);

  const copyAddress = () => {
    if (!account) return;
    navigator.clipboard.writeText(account.address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({ title: "Copied!", description: "Email address copied to clipboard." });
  };

  const didInit = useRef(false);
  useEffect(() => {
    if (domains.length === 0) return;
    if (didInit.current) return;
    didInit.current = true;

    const saved = loadAccount();
    if (saved) {
      fetch(`${API_BASE}/messages`, {
        headers: { Authorization: `Bearer ${saved.token}` },
      }).then((res) => {
        if (res.ok) {
          setAccount(saved);
          setInboxError(null);
        } else {
          clearAccount();
          generateAddress();
        }
      }).catch(() => {
        // Network error — use saved account optimistically
        setAccount(saved);
        setInboxError(null);
      });
    } else {
      generateAddress();
    }
  }, [domains, generateAddress]);

  useEffect(() => {
    if (!account) return;
    fetchMessages(account, true);
    intervalRef.current = setInterval(() => fetchMessages(account, true), REFRESH_INTERVAL);
    setCountdown(REFRESH_INTERVAL / 1000);
    countdownRef.current = setInterval(() => {
      setCountdown((c) => (c <= 1 ? REFRESH_INTERVAL / 1000 : c - 1));
    }, 1000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, [account, fetchMessages]);

  const handleGmailGenerate = () => {
    const raw = gmailInput.trim().toLowerCase().replace(/\s+/g, "");
    if (!raw) return;
    let base = raw;
    if (raw.includes("@")) {
      base = raw.split("@")[0];
    }
    base = base.replace(/\./g, "");
    setGmailBase(base);
    setDotVariants(generateDotVariants(base));
    setPlusVariants(PLUS_TAGS.map((tag) => `${base}+${tag}@gmail.com`));
    setShowAllDots(false);
  };

  const copyVariant = (v: string) => {
    navigator.clipboard.writeText(v);
    setCopiedVariant(v);
    setTimeout(() => setCopiedVariant(null), 1500);
  };

  const unreadCount = messages.filter((m) => !m.seen).length;

  const addressUsername = account?.address.split("@")[0] ?? "";
  const addressDomain = account?.address.split("@")[1] ?? "";

  const visibleDots = showAllDots ? dotVariants : dotVariants.slice(0, 12);

  return (
    <Layout>
      <SeoHead
        title="Temp Mail — Disposable Email & Gmail Tricks"
        description="Free temporary email with domain switching, custom usernames, Gmail dot trick, and plus-tag generator. No signup required."
        path="/tools/temp-mail"
        faqs={[]}
        extraSchemas={[
          {
            "@context": "https://schema.org",
            "@type": "SoftwareApplication",
            name: "Temp Mail",
            applicationCategory: "WebApplication",
            operatingSystem: "Web",
            url: "https://xtoolkit.live/tools/temp-mail",
            description: "Free temporary email with domain switching, custom usernames, Gmail dot trick, and plus-tag generator. No signup required.",
            offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
            isAccessibleForFree: true,
            browserRequirements: "Requires JavaScript. Works in all modern browsers.",
            provider: { "@type": "Organization", name: "X Toolkit", url: "https://xtoolkit.live" },
          },
          {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            itemListElement: [
              { "@type": "ListItem", position: 1, name: "Home", item: "https://xtoolkit.live/" },
              { "@type": "ListItem", position: 2, name: "Tools", item: "https://xtoolkit.live/tools" },
              { "@type": "ListItem", position: 3, name: "Temp Mail", item: "https://xtoolkit.live/tools/temp-mail" },
            ],
          },
        ]}
      />

      <div className="max-w-6xl mx-auto px-4 md:px-8 py-8 md:py-12 space-y-6">

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-cyan-400/10 border border-cyan-400/20 flex items-center justify-center">
                <Inbox className="h-5 w-5 text-cyan-400" />
              </div>
              <span className="text-xs font-semibold uppercase tracking-wider text-cyan-400 bg-cyan-400/10 border border-cyan-400/20 rounded-full px-3 py-1">
                Email Tool
              </span>
            </div>
            <h1 className="text-2xl md:text-3xl font-bold tracking-tight">Temp Mail</h1>
            <p className="text-muted-foreground text-sm max-w-xl">
              Disposable inbox with domain switching and custom usernames. Plus Gmail dot &amp; plus-tag tricks — all free, no signup.
            </p>
          </div>
          <Link href="/tools">
            <Button variant="outline" size="sm" className="text-xs border-border/60 gap-1.5 shrink-0">
              Browse all tools <ArrowRight className="h-3 w-3" />
            </Button>
          </Link>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 bg-muted/40 border border-border/60 rounded-xl w-fit flex-wrap">
          {(["inbox", "tempgmail", "gmail"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 text-sm font-medium rounded-lg transition-all ${
                activeTab === tab
                  ? "bg-background border border-border/60 text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab === "inbox" ? (
                <span className="flex items-center gap-2">
                  <Inbox className="h-3.5 w-3.5" />
                  Disposable Inbox
                  {unreadCount > 0 && activeTab !== "inbox" && (
                    <span className="h-4 min-w-4 px-1 text-[10px] bg-primary text-primary-foreground rounded-full flex items-center justify-center font-bold">
                      {unreadCount}
                    </span>
                  )}
                </span>
              ) : tab === "tempgmail" ? (
                <span className="flex items-center gap-2">
                  <Mail className="h-3.5 w-3.5 text-red-400" />
                  Temp Gmail
                  {tgMessages.length > 0 && activeTab !== "tempgmail" && (
                    <span className="h-4 min-w-4 px-1 text-[10px] bg-red-500 text-white rounded-full flex items-center justify-center font-bold">
                      {tgMessages.length}
                    </span>
                  )}
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <Sparkles className="h-3.5 w-3.5" />
                  Gmail Tricks
                </span>
              )}
            </button>
          ))}
        </div>

        {/* ── INBOX TAB ── */}
        {activeTab === "inbox" && (
          <div className="space-y-4">

            {/* Address bar */}
            <div className="rounded-xl border border-border/60 bg-card/40 p-4 space-y-4">
              <div className="flex items-start gap-3">
                <div className="h-9 w-9 rounded-lg bg-cyan-400/10 border border-cyan-400/20 flex items-center justify-center shrink-0 mt-0.5">
                  <Mail className="h-4 w-4 text-cyan-400" />
                </div>
                <div className="flex-1 min-w-0 space-y-1">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide font-semibold">Your temporary email address</p>
                  {account ? (
                    <div className="flex flex-wrap items-center gap-1 font-mono text-base font-semibold">
                      <span className="text-foreground">{addressUsername}</span>
                      <span className="text-muted-foreground">@</span>
                      <span className="text-cyan-400">{addressDomain}</span>
                    </div>
                  ) : (
                    <div className="h-5 bg-muted/60 rounded animate-pulse w-56 mt-1" />
                  )}
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground shrink-0 mt-1">
                  <Timer className="h-3 w-3" />
                  {countdown}s
                </div>
              </div>

              {/* Actions row */}
              <div className="flex flex-wrap gap-2 items-center">
                <Button onClick={copyAddress} disabled={!account} size="sm" className="text-xs gap-1.5 bg-cyan-500 hover:bg-cyan-400 text-black font-semibold">
                  {copied ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                  {copied ? "Copied!" : "Copy Address"}
                </Button>
                <Button variant="outline" size="sm" onClick={() => account && fetchMessages(account)} disabled={!account || refreshing} className="text-xs gap-1.5 border-border/60">
                  <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? "animate-spin" : ""}`} />
                  Refresh
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    clearAccount();
                    generateAddress({
                      username: showCustomUsername && customUsername ? customUsername : undefined,
                      domain: selectedDomain || undefined,
                    });
                  }}
                  disabled={generating}
                  className="text-xs gap-1.5 border-border/60"
                >
                  <Shuffle className="h-3.5 w-3.5" />
                  {generating ? "Generating…" : "New Address"}
                </Button>

                <div className="h-4 w-px bg-border/50" />

                {/* Custom username toggle */}
                <Button
                  variant={showCustomUsername ? "secondary" : "ghost"}
                  size="sm"
                  onClick={() => setShowCustomUsername((v) => !v)}
                  className="text-xs gap-1.5 border border-border/60"
                >
                  <AtSign className="h-3.5 w-3.5" />
                  Custom Username
                </Button>

                {/* Domain picker */}
                {domains.length > 1 && (
                  <div className="relative" ref={domainPickerRef}>
                    <Button
                      variant={showDomainPicker ? "secondary" : "ghost"}
                      size="sm"
                      onClick={() => setShowDomainPicker((v) => !v)}
                      className="text-xs gap-1.5 border border-border/60"
                    >
                      <Zap className="h-3.5 w-3.5" />
                      {selectedDomain ? `@${selectedDomain}` : "Domain"}
                      <ChevronDown className={`h-3 w-3 transition-transform ${showDomainPicker ? "rotate-180" : ""}`} />
                    </Button>
                    {showDomainPicker && (
                      <div className="absolute top-full mt-1 left-0 z-50 min-w-[200px] bg-popover border border-border rounded-xl shadow-xl overflow-hidden">
                        <p className="text-[10px] text-muted-foreground uppercase tracking-wider px-3 pt-3 pb-1.5 font-semibold">Available domains</p>
                        {domains.map((d) => (
                          <button
                            key={d}
                            onClick={() => { setSelectedDomain(d); setShowDomainPicker(false); }}
                            className={`w-full text-left px-3 py-2 text-sm font-mono hover:bg-muted/60 transition-colors flex items-center gap-2 ${selectedDomain === d ? "text-cyan-400 bg-cyan-400/10" : "text-foreground"}`}
                          >
                            {selectedDomain === d && <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />}
                            <span className={selectedDomain === d ? "" : "ml-5"}>@{d}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Custom username row */}
              {showCustomUsername && (
                <div className="flex gap-2 items-center pt-1">
                  <div className="flex-1 flex items-center gap-2 bg-muted/30 border border-border/60 rounded-lg px-3 py-2">
                    <AtSign className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                    <input
                      type="text"
                      value={customUsername}
                      onChange={(e) => setCustomUsername(e.target.value.toLowerCase().replace(/[^a-z0-9._+-]/g, ""))}
                      placeholder="your-username (leave blank for random)"
                      className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground/50 font-mono"
                      maxLength={30}
                    />
                    <span className="text-xs text-muted-foreground font-mono shrink-0">@{selectedDomain || "..."}</span>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => generateAddress({ username: customUsername || undefined, domain: selectedDomain || undefined })}
                    disabled={generating}
                    className="text-xs gap-1.5 shrink-0"
                  >
                    <Shuffle className="h-3.5 w-3.5" />
                    {generating ? "…" : "Create"}
                  </Button>
                </div>
              )}
            </div>

            {/* Error banner */}
            {inboxError && !account && (
              <div className="rounded-xl border border-red-500/30 bg-red-500/10 p-4 flex items-center gap-3">
                <AlertCircle className="h-5 w-5 text-red-400 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-red-300">Could not create inbox</p>
                  <p className="text-xs text-red-400/80 mt-0.5">{inboxError}</p>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    clearAccount();
                    generateAddress({ domain: selectedDomain || undefined });
                  }}
                  disabled={generating}
                  className="text-xs gap-1.5 border-red-500/40 text-red-300 hover:bg-red-500/10 shrink-0"
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${generating ? "animate-spin" : ""}`} />
                  Try Again
                </Button>
              </div>
            )}

            {/* Inbox split */}
            <div className="grid md:grid-cols-5 gap-3 min-h-[460px]">
              {/* Message list */}
              <div className="md:col-span-2 rounded-xl border border-border/60 bg-card/30 overflow-hidden flex flex-col">
                <div className="px-4 py-3 border-b border-border/50 flex items-center justify-between">
                  <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">Inbox</span>
                  <div className="flex items-center gap-2">
                    {unreadCount > 0 && (
                      <span className="text-[10px] bg-primary/15 text-primary border border-primary/20 rounded-full px-2 py-0.5 font-semibold">
                        {unreadCount} new
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto">
                  {!account || generating ? (
                    <div className="p-4 space-y-3">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="rounded-lg border border-border/40 bg-muted/20 p-3 space-y-2 animate-pulse">
                          <div className="h-3 bg-muted/60 rounded w-2/3" />
                          <div className="h-2.5 bg-muted/40 rounded w-full" />
                        </div>
                      ))}
                    </div>
                  ) : messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full py-10 text-center px-4">
                      <Inbox className="h-8 w-8 text-muted-foreground/20 mb-3" />
                      <p className="text-sm text-muted-foreground/60 font-medium">No messages yet</p>
                      <p className="text-xs text-muted-foreground/40 mt-1">Send an email to your temp address and it appears here automatically</p>
                    </div>
                  ) : (
                    <div className="p-2 space-y-1.5">
                      {messages.map((msg) => (
                        <button
                          key={msg.id}
                          onClick={() => fetchMessageBody(msg)}
                          className={`w-full text-left rounded-lg border p-3 transition-all ${selectedMsg?.id === msg.id ? "bg-primary/10 border-primary/30" : "border-border/50 bg-muted/10 hover:bg-muted/30 hover:border-border/70"}`}
                        >
                          <div className="flex items-start gap-2">
                            {!msg.seen && <span className="h-1.5 w-1.5 rounded-full bg-primary mt-1.5 shrink-0" />}
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between gap-2 mb-0.5">
                                <p className="text-[11px] font-semibold text-foreground/80 truncate">{msg.from.name || msg.from.address}</p>
                                <span className="text-[10px] text-muted-foreground shrink-0">{formatTime(msg.createdAt)}</span>
                              </div>
                              <p className={`text-xs truncate ${msg.seen ? "text-muted-foreground" : "text-foreground font-medium"}`}>
                                {msg.subject || "(no subject)"}
                              </p>
                              <p className="text-[10px] text-muted-foreground/60 truncate mt-0.5">{msg.intro}</p>
                              {msg.hasAttachments && (
                                <div className="flex items-center gap-1 mt-1 text-[10px] text-muted-foreground">
                                  <Paperclip className="h-2.5 w-2.5" /> Attachment
                                </div>
                              )}
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Message view */}
              <div className="md:col-span-3 rounded-xl border border-border/60 bg-card/30 overflow-hidden flex flex-col">
                {loading ? (
                  <div className="flex-1 flex items-center justify-center">
                    <RefreshCw className="h-6 w-6 animate-spin text-muted-foreground/40" />
                  </div>
                ) : selectedMsg ? (
                  <>
                    <div className="px-5 py-4 border-b border-border/50 space-y-1.5">
                      <h2 className="text-sm font-semibold">{selectedMsg.subject || "(no subject)"}</h2>
                      <div className="text-[11px] text-muted-foreground">
                        <span>From: </span>
                        <span className="text-foreground/70">{selectedMsg.from.name ? `${selectedMsg.from.name} <${selectedMsg.from.address}>` : selectedMsg.from.address}</span>
                      </div>
                      <div className="text-[11px] text-muted-foreground">{formatTime(selectedMsg.createdAt)}</div>
                    </div>
                    <div className="flex-1 overflow-y-auto p-5">
                      {selectedMsg.html && selectedMsg.html.length > 0 ? (
                        <div className="prose prose-sm prose-invert max-w-none text-sm" dangerouslySetInnerHTML={{ __html: selectedMsg.html.join("") }} />
                      ) : selectedMsg.text ? (
                        <pre className="text-xs font-sans text-muted-foreground leading-relaxed whitespace-pre-wrap">{selectedMsg.text}</pre>
                      ) : (
                        <p className="text-sm text-muted-foreground">(Empty message)</p>
                      )}
                    </div>
                  </>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center py-10 text-center px-6 space-y-3">
                    <div className="h-12 w-12 rounded-xl bg-muted/40 border border-border/50 flex items-center justify-center">
                      <Mail className="h-6 w-6 text-muted-foreground/30" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-muted-foreground/60">Select a message to read it</p>
                      <p className="text-xs text-muted-foreground/40 mt-1">Messages appear automatically when received</p>
                    </div>
                    {account && (
                      <div className="flex items-center gap-2 text-xs bg-cyan-400/10 border border-cyan-400/20 text-cyan-400 rounded-lg px-3 py-2">
                        <AlertCircle className="h-3.5 w-3.5 shrink-0" />
                        <Clock className="h-3.5 w-3.5 shrink-0" />
                        Auto-refreshing every {REFRESH_INTERVAL / 1000}s
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Status pills */}
            <div className="flex flex-wrap gap-2">
              {[
                { icon: Inbox, label: "No signup required" },
                { icon: RefreshCw, label: "Auto-refresh every 15s" },
                { icon: Clock, label: "Session-based inbox" },
                { icon: CheckCircle2, label: "Spam-free" },
                { icon: Zap, label: "Multiple domains" },
              ].map(({ icon: Ic, label }) => (
                <div key={label} className="inline-flex items-center gap-1.5 text-[11px] text-muted-foreground bg-muted/40 border border-border/50 rounded-full px-3 py-1">
                  <Ic className="h-3 w-3" />
                  {label}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── TEMP GMAIL TAB ── */}
        {activeTab === "tempgmail" && (
          <div className="space-y-4">

            {/* Address bar */}
            <div className="rounded-xl border border-border/60 bg-card/40 p-4 space-y-4">
              <div className="flex items-start gap-3">
                <div className="h-9 w-9 rounded-lg bg-red-500/10 border border-red-500/20 flex items-center justify-center shrink-0 mt-0.5">
                  <Mail className="h-4 w-4 text-red-400" />
                </div>
                <div className="flex-1 min-w-0 space-y-1">
                  <p className="text-[10px] text-muted-foreground uppercase tracking-wide font-semibold">Your temporary Gmail address</p>
                  {tgEmail ? (
                    <div className="flex flex-wrap items-center gap-1 font-mono text-base font-semibold">
                      <span className="text-foreground">{tgEmail}</span>
                    </div>
                  ) : tgGenerating ? (
                    <div className="h-6 w-64 bg-muted/40 animate-pulse rounded" />
                  ) : (
                    <p className="text-sm text-muted-foreground">Generating address…</p>
                  )}
                  {tgType && (
                    <p className="text-[10px] text-muted-foreground/60 font-mono">{tgType.replace(/_/g, " ")}</p>
                  )}
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {tgEmail && (
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(tgEmail);
                        setTgCopied(true);
                        setTimeout(() => setTgCopied(false), 2000);
                        toast({ title: "Copied!", description: "Gmail address copied." });
                      }}
                      className="h-8 w-8 rounded-lg border border-border/60 bg-muted/30 hover:bg-muted/60 flex items-center justify-center transition-colors"
                      title="Copy address"
                    >
                      {tgCopied ? <CheckCircle2 className="h-3.5 w-3.5 text-green-400" /> : <Copy className="h-3.5 w-3.5 text-muted-foreground" />}
                    </button>
                  )}
                  <button
                    onClick={() => { setTgEmail(null); tgGenerate(tgDomainPref); }}
                    disabled={tgGenerating}
                    className="h-8 w-8 rounded-lg border border-border/60 bg-muted/30 hover:bg-muted/60 flex items-center justify-center transition-colors disabled:opacity-50"
                    title="New address"
                  >
                    <Shuffle className={`h-3.5 w-3.5 text-muted-foreground ${tgGenerating ? "animate-spin" : ""}`} />
                  </button>
                  {tgEmail && (
                    <button
                      onClick={() => tgFetchInbox(tgEmail)}
                      disabled={tgRefreshing}
                      className="h-8 w-8 rounded-lg border border-border/60 bg-muted/30 hover:bg-muted/60 flex items-center justify-center transition-colors disabled:opacity-50"
                      title="Refresh inbox"
                    >
                      <RefreshCw className={`h-3.5 w-3.5 text-muted-foreground ${tgRefreshing ? "animate-spin" : ""}`} />
                    </button>
                  )}
                </div>
              </div>

              {/* Domain / type picker */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <span className="text-[10px] text-muted-foreground uppercase tracking-wide font-semibold shrink-0">Domain:</span>
                {[
                  { value: "any",         label: "Any (random)" },
                  { value: "dot",         label: "@gmail.com · dot trick" },
                  { value: "plus",        label: "@gmail.com · plus trick" },
                  { value: "googlemail",  label: "@googlemail.com" },
                ].map((opt) => (
                  <button
                    key={opt.value}
                    onClick={() => {
                      setTgDomainPref(opt.value);
                      setTgEmail(null);
                      setTgError(null);
                    }}
                    className={`text-[11px] px-2.5 py-1 rounded-full border transition-all ${
                      tgDomainPref === opt.value
                        ? "bg-red-500/15 border-red-500/30 text-red-400 font-semibold"
                        : "border-border/50 text-muted-foreground hover:border-border/70 hover:text-foreground"
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>

              {/* Auto-refresh timer */}
              {tgEmail && (
                <div className="flex items-center gap-2 text-[11px] text-muted-foreground/50">
                  <Timer className="h-3 w-3" />
                  <span>Auto-refresh in {tgCountdown}s</span>
                  <span className="mx-1">·</span>
                  <Zap className="h-3 w-3 text-red-400/60" />
                  <span className="text-red-400/60">Real Gmail via Gmailnator</span>
                </div>
              )}
            </div>

            {tgError && (
              <div className="rounded-xl border border-destructive/30 bg-destructive/8 px-4 py-3 flex items-center gap-3">
                <AlertCircle className="h-4 w-4 text-destructive shrink-0" />
                <p className="text-sm text-destructive">{tgError}</p>
                <Button size="sm" variant="outline" onClick={() => tgGenerate(tgDomainPref)} className="ml-auto text-xs border-destructive/30">
                  Retry
                </Button>
              </div>
            )}

            {/* Inbox panel */}
            {tgEmail && (
              <div className="rounded-xl border border-border/60 bg-card/40 overflow-hidden">
                <div className="px-4 py-3 border-b border-border/50 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Inbox className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm font-medium">Inbox</span>
                    {tgMessages.length > 0 && (
                      <span className="text-[10px] bg-red-500/15 text-red-400 border border-red-500/20 rounded-full px-2 py-0.5 font-semibold">
                        {tgMessages.length} message{tgMessages.length !== 1 ? "s" : ""}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => tgFetchInbox(tgEmail)}
                    disabled={tgRefreshing}
                    className="text-[11px] text-muted-foreground/60 hover:text-muted-foreground flex items-center gap-1.5 transition-colors disabled:opacity-40"
                  >
                    <RefreshCw className={`h-3 w-3 ${tgRefreshing ? "animate-spin" : ""}`} />
                    Refresh
                  </button>
                </div>

                {tgMessages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-14 gap-3 text-center px-4">
                    <div className="h-10 w-10 rounded-full bg-muted/30 flex items-center justify-center">
                      <Inbox className="h-5 w-5 text-muted-foreground/30" />
                    </div>
                    <p className="text-sm text-muted-foreground/60 font-medium">Inbox is empty</p>
                    <p className="text-xs text-muted-foreground/40">Send an email to <span className="font-mono">{tgEmail}</span> and it appears here</p>
                  </div>
                ) : (
                  <div className="divide-y divide-border/40">
                    {tgMessages.map((msg, i) => {
                      const msgId = msg.id ?? msg.message_id ?? String(i);
                      const isSelected = tgSelected && (tgSelected.id ?? tgSelected.message_id) === msgId;
                      const from = msg.from ?? "Unknown";
                      const subject = msg.subject ?? "(no subject)";
                      const date = msg.date ? new Date(msg.date).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" }) : "";
                      const body = msg.body ?? msg.content ?? msg.text ?? msg.html ?? "";
                      return (
                        <div key={msgId}>
                          <button
                            onClick={() => setTgSelected(isSelected ? null : msg)}
                            className={`w-full text-left px-4 py-3 transition-colors hover:bg-muted/30 ${isSelected ? "bg-muted/20" : ""}`}
                          >
                            <div className="flex items-start justify-between gap-3">
                              <div className="flex-1 min-w-0">
                                <p className="text-xs font-semibold text-foreground/80 truncate">{from}</p>
                                <p className="text-sm font-medium truncate mt-0.5">{subject}</p>
                              </div>
                              {date && <span className="text-[10px] text-muted-foreground/50 shrink-0 mt-0.5">{date}</span>}
                            </div>
                          </button>
                          {isSelected && body && (
                            <div className="px-4 pb-4 border-t border-border/40 bg-muted/10">
                              <div
                                className="text-xs text-muted-foreground leading-relaxed mt-3 max-h-60 overflow-y-auto whitespace-pre-wrap break-words"
                                dangerouslySetInnerHTML={msg.html ? { __html: msg.html } : undefined}
                              >
                                {!msg.html ? body : undefined}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* Info callout */}
            <div className="rounded-xl border border-red-500/15 bg-red-500/5 px-4 py-3 flex items-start gap-3">
              <Zap className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />
              <div className="text-xs text-muted-foreground space-y-1">
                <p className="font-semibold text-foreground/70">About Temp Gmail</p>
                <p>Generates real Gmail addresses (dot trick or plus variations) via Gmailnator. Emails sent to these addresses will appear in your actual Gmail inbox. This tab shows messages received in the Gmailnator-monitored inbox.</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === "gmail" && (
          <div className="space-y-6">

            {/* Input */}
            <div className="rounded-xl border border-border/60 bg-card/40 p-5 space-y-4">
              <div>
                <h2 className="text-sm font-semibold mb-1">Enter your Gmail address</h2>
                <p className="text-xs text-muted-foreground">
                  We'll generate all the dot-trick variants and plus-tag aliases that all deliver to the same inbox — useful for tracking signups or bypassing duplicate checks.
                </p>
              </div>
              <div className="flex gap-2">
                <div className="flex-1 flex items-center gap-2 bg-muted/30 border border-border/60 rounded-lg px-3 py-2.5">
                  <Mail className="h-4 w-4 text-muted-foreground shrink-0" />
                  <input
                    type="text"
                    value={gmailInput}
                    onChange={(e) => setGmailInput(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleGmailGenerate()}
                    placeholder="yourname@gmail.com"
                    className="flex-1 bg-transparent text-sm outline-none placeholder:text-muted-foreground/50"
                  />
                </div>
                <Button onClick={handleGmailGenerate} disabled={!gmailInput.trim()} className="gap-1.5 shrink-0">
                  <Sparkles className="h-4 w-4" />
                  Generate
                </Button>
              </div>
            </div>

            {gmailBase && (
              <>
                {/* Dot Trick */}
                <div className="rounded-xl border border-border/60 bg-card/40 overflow-hidden">
                  <div className="px-5 py-4 border-b border-border/50 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <div className="h-7 w-7 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
                        <AtSign className="h-3.5 w-3.5 text-blue-400" />
                      </div>
                      <div>
                        <h3 className="text-sm font-semibold">Dot Trick</h3>
                        <p className="text-[11px] text-muted-foreground">Gmail ignores dots — all {dotVariants.length} variants deliver to <span className="font-mono text-foreground/70">{gmailBase}@gmail.com</span></p>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground bg-muted/60 border border-border/50 rounded-full px-2.5 py-0.5 font-semibold">
                      {dotVariants.length} variants
                    </span>
                  </div>
                  <div className="p-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    {visibleDots.map((v) => (
                      <button
                        key={v}
                        onClick={() => copyVariant(v)}
                        className="flex items-center justify-between gap-2 rounded-lg border border-border/50 bg-muted/10 hover:bg-muted/30 hover:border-border/70 px-3 py-2 text-left transition-all group"
                      >
                        <span className="font-mono text-xs truncate text-foreground/80">{v}</span>
                        {copiedVariant === v ? (
                          <CheckCircle2 className="h-3.5 w-3.5 text-green-400 shrink-0" />
                        ) : (
                          <Copy className="h-3.5 w-3.5 text-muted-foreground/40 group-hover:text-muted-foreground shrink-0 transition-colors" />
                        )}
                      </button>
                    ))}
                  </div>
                  {dotVariants.length > 12 && (
                    <div className="px-4 pb-4">
                      <button
                        onClick={() => setShowAllDots((v) => !v)}
                        className="text-xs text-primary hover:underline flex items-center gap-1"
                      >
                        {showAllDots ? "Show fewer" : `Show all ${dotVariants.length} variants`}
                        <ChevronDown className={`h-3 w-3 transition-transform ${showAllDots ? "rotate-180" : ""}`} />
                      </button>
                    </div>
                  )}
                </div>

                {/* Plus Trick */}
                <div className="rounded-xl border border-border/60 bg-card/40 overflow-hidden">
                  <div className="px-5 py-4 border-b border-border/50 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <div className="h-7 w-7 rounded-lg bg-purple-500/10 border border-purple-500/20 flex items-center justify-center">
                        <Plus className="h-3.5 w-3.5 text-purple-400" />
                      </div>
                      <div>
                        <h3 className="text-sm font-semibold">Plus Trick (Gmail Tags)</h3>
                        <p className="text-[11px] text-muted-foreground">
                          Use <span className="font-mono text-foreground/70">{gmailBase}+tag@gmail.com</span> to tag and filter incoming mail
                        </p>
                      </div>
                    </div>
                    <span className="text-xs text-muted-foreground bg-muted/60 border border-border/50 rounded-full px-2.5 py-0.5 font-semibold">
                      {plusVariants.length} tags
                    </span>
                  </div>
                  <div className="p-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
                    {plusVariants.map((v) => (
                      <button
                        key={v}
                        onClick={() => copyVariant(v)}
                        className="flex items-center justify-between gap-2 rounded-lg border border-border/50 bg-muted/10 hover:bg-muted/30 hover:border-border/70 px-3 py-2 text-left transition-all group"
                      >
                        <span className="font-mono text-xs truncate text-foreground/80">{v}</span>
                        {copiedVariant === v ? (
                          <CheckCircle2 className="h-3.5 w-3.5 text-green-400 shrink-0" />
                        ) : (
                          <Copy className="h-3.5 w-3.5 text-muted-foreground/40 group-hover:text-muted-foreground shrink-0 transition-colors" />
                        )}
                      </button>
                    ))}
                  </div>

                  {/* Custom tag */}
                  <div className="px-4 pb-4">
                    <p className="text-[11px] text-muted-foreground mb-2 font-semibold uppercase tracking-wide">Add a custom tag</p>
                    <div className="flex gap-2">
                      <div className="flex items-center gap-1.5 bg-muted/30 border border-border/60 rounded-lg px-3 py-2 flex-1">
                        <span className="font-mono text-xs text-muted-foreground shrink-0">{gmailBase}+</span>
                        <Input
                          id="custom-tag-input"
                          className="border-0 bg-transparent p-0 h-auto text-xs font-mono focus-visible:ring-0 focus-visible:ring-offset-0"
                          placeholder="yourtag"
                          onKeyDown={(e) => {
                            if (e.key === "Enter") {
                              const val = (e.target as HTMLInputElement).value.trim().toLowerCase().replace(/[^a-z0-9._-]/g, "");
                              if (val) copyVariant(`${gmailBase}+${val}@gmail.com`);
                            }
                          }}
                        />
                        <span className="font-mono text-xs text-muted-foreground shrink-0">@gmail.com</span>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        className="text-xs gap-1.5 border-border/60 shrink-0"
                        onClick={() => {
                          const input = document.getElementById("custom-tag-input") as HTMLInputElement;
                          const val = input?.value.trim().toLowerCase().replace(/[^a-z0-9._-]/g, "");
                          if (val) copyVariant(`${gmailBase}+${val}@gmail.com`);
                        }}
                      >
                        <Copy className="h-3.5 w-3.5" />
                        Copy
                      </Button>
                    </div>
                  </div>
                </div>

                {/* How it works */}
                <div className="rounded-xl border border-border/60 bg-muted/20 p-5 space-y-3">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <ExternalLink className="h-4 w-4 text-muted-foreground" />
                    How Gmail tricks work
                  </h3>
                  <div className="grid sm:grid-cols-2 gap-4 text-xs text-muted-foreground">
                    <div className="space-y-1.5">
                      <p className="font-semibold text-foreground/70 flex items-center gap-1.5">
                        <AtSign className="h-3.5 w-3.5 text-blue-400" /> Dot Trick
                      </p>
                      <p>Gmail completely ignores periods in usernames. <span className="font-mono text-foreground/60">j.o.h.n@gmail.com</span> and <span className="font-mono text-foreground/60">john@gmail.com</span> are the same inbox. Useful for registering on sites that reject duplicate addresses.</p>
                    </div>
                    <div className="space-y-1.5">
                      <p className="font-semibold text-foreground/70 flex items-center gap-1.5">
                        <Plus className="h-3.5 w-3.5 text-purple-400" /> Plus Trick
                      </p>
                      <p>Anything after a <span className="font-mono text-foreground/60">+</span> is ignored for delivery. <span className="font-mono text-foreground/60">john+spam@gmail.com</span> still lands in John's inbox. Use it to create Gmail filters and track who shares your address.</p>
                    </div>
                  </div>
                </div>
              </>
            )}

            {!gmailBase && (
              <div className="rounded-xl border border-dashed border-border/50 bg-card/20 p-12 flex flex-col items-center justify-center text-center space-y-3">
                <Sparkles className="h-8 w-8 text-muted-foreground/20" />
                <p className="text-sm text-muted-foreground/60 font-medium">Enter a Gmail address above to generate tricks</p>
                <p className="text-xs text-muted-foreground/40">Dot variants and plus tags will appear here</p>
              </div>
            )}
          </div>
        )}
      </div>
    </Layout>
  );
}
