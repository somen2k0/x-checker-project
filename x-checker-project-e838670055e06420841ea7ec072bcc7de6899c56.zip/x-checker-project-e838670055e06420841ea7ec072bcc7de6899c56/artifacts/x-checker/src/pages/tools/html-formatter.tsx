import { useState, useCallback } from "react";
import { MiniToolLayout } from "@/components/layout/MiniToolLayout";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Braces, Copy, Trash2, Download, Maximize2, Minimize2 } from "lucide-react";

const faqs = [
  { q: "What is HTML formatting?", a: "HTML formatting (or HTML beautification) adds proper indentation, line breaks, and structure to minified or poorly formatted HTML markup. It makes HTML code readable for developers without changing the rendered output in the browser." },
  { q: "Does formatting HTML change how it renders?", a: "No — HTML formatting only adds whitespace (indentation and newlines). Browsers ignore insignificant whitespace in HTML, so the visual output remains identical. The only exception is content inside <pre> or elements with white-space: pre set in CSS." },
  { q: "What is HTML minification?", a: "HTML minification removes unnecessary whitespace, comments, and redundant attributes to produce the smallest possible HTML file. This reduces page load time by decreasing the amount of data that needs to be transferred from server to browser." },
  { q: "Is this tool safe for sensitive HTML?", a: "Yes — all processing happens entirely in your browser using JavaScript. No HTML is ever uploaded or sent to a server. This means it's safe to use with private templates, internal tools, or authenticated page markup." },
  { q: "Can I use this to format HTML emails?", a: "Yes — this tool works for any HTML, including email templates. Formatted HTML makes it much easier to spot layout bugs, missing closing tags, and structural issues in complex email templates." },
  { q: "Why should I format my HTML?", a: "Well-formatted HTML is easier to read, debug, and collaborate on. It also makes it simpler to spot unclosed tags, incorrect nesting, or structural issues that might cause cross-browser rendering problems." },
];

const relatedTools = [
  { title: "CSS Minifier", href: "/tools/css-minifier", description: "Minify CSS files by removing whitespace and comments." },
  { title: "JSON Formatter", href: "/tools/json-formatter", description: "Format and validate JSON with real-time error detection." },
  { title: "SQL Formatter", href: "/tools/sql-formatter", description: "Format SQL queries with proper indentation." },
  { title: "Plain Text Email Formatter", href: "/tools/plain-text-formatter", description: "Convert HTML emails to clean plain text." },
];

const EXAMPLE_HTML = `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>My Page</title><style>body{margin:0;font-family:sans-serif}h1{color:#333}</style></head><body><header><h1>Hello World</h1><nav><ul><li><a href="/">Home</a></li><li><a href="/about">About</a></li></ul></nav></header><main><section class="hero"><h2>Welcome</h2><p>This is a sample paragraph with some <strong>bold text</strong> and <em>italic text</em>.</p></section></main><footer><p>&copy; 2025 My Site</p></footer></body></html>`;

const VOID_ELEMENTS = new Set(["area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"]);
const INLINE_ELEMENTS = new Set(["a","abbr","acronym","b","bdo","big","br","button","cite","code","dfn","em","i","img","input","kbd","label","map","object","output","q","samp","select","small","span","strong","sub","sup","textarea","time","tt","var"]);

function formatHTML(html: string): string {
  let formatted = "";
  let indent = 0;
  const tab = "  ";
  
  html = html.trim().replace(/>\s+</g, "><");
  
  let i = 0;
  while (i < html.length) {
    if (html[i] === "<") {
      const end = html.indexOf(">", i);
      if (end === -1) break;
      const tag = html.slice(i, end + 1);
      const tagContent = tag.slice(1, -1).trim();
      const isSelfClosing = tag.endsWith("/>") || VOID_ELEMENTS.has(tagContent.split(/[\s>]/)[0].toLowerCase().replace("/", ""));
      const isComment = tag.startsWith("<!--");
      const isDoctype = tag.toLowerCase().startsWith("<!doctype");
      const isClosing = tagContent.startsWith("/");
      const tagName = tagContent.split(/[\s/]/)[0].replace("/", "").toLowerCase();
      const isInline = INLINE_ELEMENTS.has(tagName);

      if (isClosing && !isInline) indent = Math.max(0, indent - 1);
      
      if (!isInline) {
        formatted += "\n" + tab.repeat(indent);
      }
      formatted += tag;
      
      if (!isClosing && !isSelfClosing && !isComment && !isDoctype && !isInline) {
        indent++;
      }
      i = end + 1;
    } else {
      const end = html.indexOf("<", i);
      const text = end === -1 ? html.slice(i) : html.slice(i, end);
      const trimmed = text.trim();
      if (trimmed) formatted += trimmed;
      i = end === -1 ? html.length : end;
    }
  }
  return formatted.trim();
}

function minifyHTML(html: string): string {
  return html
    .replace(/<!--[\s\S]*?-->/g, "")
    .replace(/\s+/g, " ")
    .replace(/>\s+</g, "><")
    .replace(/\s+>/g, ">")
    .replace(/<\s+/g, "<")
    .trim();
}

export default function HtmlFormatter() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [activeAction, setActiveAction] = useState<"format" | "minify" | null>(null);
  const { toast } = useToast();

  const handleFormat = useCallback(() => {
    if (!input.trim()) return;
    setOutput(formatHTML(input));
    setActiveAction("format");
  }, [input]);

  const handleMinify = useCallback(() => {
    if (!input.trim()) return;
    setOutput(minifyHTML(input));
    setActiveAction("minify");
  }, [input]);

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    toast({ title: "Copied!", description: "HTML copied to clipboard." });
  };

  const handleDownload = () => {
    if (!output) return;
    const blob = new Blob([output], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = activeAction === "minify" ? "minified.html" : "formatted.html";
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Downloaded!", description: "HTML file saved." });
  };

  return (
    <MiniToolLayout
      seoTitle="HTML Formatter & Beautifier Online Free — Format & Minify HTML"
      seoDescription="Format, beautify, and minify HTML online for free. Proper indentation, structure, and whitespace removal. 100% client-side — your code never leaves your browser."
      icon={Braces}
      badge="Developer Tool"
      title="HTML Formatter"
      description="Paste your HTML to instantly beautify it with proper indentation, or minify it to the smallest possible size. 100% client-side — nothing is sent to a server."
      faqs={faqs}
      relatedTools={relatedTools}
    >
      <div className="space-y-4">
        <div className="grid md:grid-cols-2 gap-3">
          {/* Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">Input HTML</span>
              <button onClick={() => { setInput(EXAMPLE_HTML); setOutput(""); setActiveAction(null); }} className="text-[11px] text-primary/70 hover:text-primary underline underline-offset-2 transition-colors">Load example</button>
            </div>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Paste your HTML here…"
              spellCheck={false}
              className="w-full min-h-[340px] md:min-h-[420px] resize-y rounded-xl border border-border/60 bg-background/60 px-4 py-3 font-mono text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground/35"
            />
          </div>

          {/* Output */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">
                Output {activeAction && <span className="font-normal text-muted-foreground/60 normal-case tracking-normal">({activeAction === "format" ? "formatted" : "minified"})</span>}
              </span>
              {output && <span className="text-[10px] font-mono text-muted-foreground/60 bg-muted/50 px-1.5 py-0.5 rounded">{output.length.toLocaleString()} chars</span>}
            </div>
            <div className={`relative w-full min-h-[340px] md:min-h-[420px] rounded-xl border bg-muted/20 overflow-auto ${output ? "border-border/60" : "border-border/40 border-dashed"}`}>
              {output ? (
                <pre className="px-4 py-3 font-mono text-xs leading-relaxed text-foreground/90 whitespace-pre-wrap break-all">{output}</pre>
              ) : (
                <div className="absolute inset-0 flex items-center justify-center text-sm text-muted-foreground/40">
                  Output appears here
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={handleFormat} disabled={!input.trim()} className="text-xs gap-1.5 shadow-sm shadow-primary/20">
            <Maximize2 className="h-3.5 w-3.5" /> Format / Beautify
          </Button>
          <Button variant="outline" onClick={handleMinify} disabled={!input.trim()} className="text-xs gap-1.5 border-border/60">
            <Minimize2 className="h-3.5 w-3.5" /> Minify
          </Button>
          <div className="flex-1" />
          <Button variant="outline" size="sm" onClick={handleCopy} disabled={!output} className="text-xs gap-1.5 border-border/60">
            <Copy className="h-3.5 w-3.5" /> Copy
          </Button>
          <Button variant="outline" size="sm" onClick={handleDownload} disabled={!output} className="text-xs gap-1.5 border-border/60">
            <Download className="h-3.5 w-3.5" /> Download
          </Button>
          <Button variant="ghost" size="sm" onClick={() => { setInput(""); setOutput(""); setActiveAction(null); }} disabled={!input && !output} className="text-xs gap-1.5 text-muted-foreground">
            <Trash2 className="h-3.5 w-3.5" /> Clear
          </Button>
        </div>
      </div>
    </MiniToolLayout>
  );
}
