import { useState, useMemo } from "react";
import { MiniToolLayout } from "@/components/layout/MiniToolLayout";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Regex, Copy, Trash2, CheckCircle2, XCircle, Info } from "lucide-react";

const FLAGS = ["g", "i", "m", "s", "u"];
const FLAG_LABELS: Record<string, string> = {
  g: "Global",
  i: "Case insensitive",
  m: "Multiline",
  s: "Dot all",
  u: "Unicode",
};

const faqs = [
  { q: "What is a regular expression?", a: "A regular expression (regex) is a sequence of characters that defines a search pattern. Used in programming for string matching, extraction, and replacement. Common in JavaScript, Python, SQL, and most programming languages." },
  { q: "What does the 'g' flag do?", a: "The global flag 'g' makes the regex find all matches in the string instead of stopping after the first one. Without it, only the first match is returned." },
  { q: "What does the 'i' flag do?", a: "The case-insensitive flag 'i' makes the pattern match regardless of uppercase or lowercase letters. For example, /hello/i matches 'Hello', 'HELLO', and 'hello'." },
  { q: "What are capture groups?", a: "Capture groups are parts of the regex enclosed in parentheses ( ). They allow you to extract specific parts of a match. For example, /(\\d{4})-(\\d{2})-(\\d{2})/ captures year, month, and day separately from a date string." },
  { q: "What is the difference between .* and .*?", a: "The .* is greedy and matches as many characters as possible. Adding a ? makes it lazy (.*?), matching as few characters as possible. Lazy matching is useful when you want to match between two specific delimiters." },
  { q: "Is this tool safe for sensitive data?", a: "Yes — all regex processing happens entirely in your browser using JavaScript's native RegExp engine. Nothing is sent to any server." },
];

const relatedTools = [
  { title: "JSON Formatter", href: "/tools/json-formatter", description: "Format and validate JSON with real-time error detection." },
  { title: "URL Encoder / Decoder", href: "/tools/url-encoder", description: "Encode and decode URLs and query strings." },
  { title: "Character Counter", href: "/tools/character-counter", description: "Count characters, words, and lines in real time." },
  { title: "JWT Decoder", href: "/tools/jwt-decoder", description: "Decode and inspect JWT tokens in your browser." },
];

const EXAMPLES = [
  { label: "Email address", pattern: "[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}", flags: "gi", test: "Contact us at hello@example.com or support@xtoolkit.live for help." },
  { label: "URL", pattern: "https?:\\/\\/[^\\s]+", flags: "gi", test: "Visit https://xtoolkit.live or http://example.com for more info." },
  { label: "Date (YYYY-MM-DD)", pattern: "\\d{4}-\\d{2}-\\d{2}", flags: "g", test: "Events on 2024-01-15, 2024-03-22, and 2025-07-04." },
  { label: "IPv4 address", pattern: "\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b", flags: "g", test: "Server IPs: 192.168.1.1 and 10.0.0.255 are internal." },
];

interface MatchResult {
  match: string;
  index: number;
  groups: string[];
}

function highlightMatches(text: string, regex: RegExp): React.ReactNode[] {
  const parts: React.ReactNode[] = [];
  let lastIndex = 0;
  let m: RegExpExecArray | null;
  const safeRegex = regex.flags.includes("g") ? regex : new RegExp(regex.source, regex.flags + "g");
  safeRegex.lastIndex = 0;
  while ((m = safeRegex.exec(text)) !== null) {
    if (m.index > lastIndex) parts.push(<span key={`t-${lastIndex}`}>{text.slice(lastIndex, m.index)}</span>);
    parts.push(<mark key={`m-${m.index}`} className="bg-primary/30 text-foreground rounded px-0.5">{m[0]}</mark>);
    lastIndex = m.index + m[0].length;
    if (m[0].length === 0) { safeRegex.lastIndex++; }
  }
  if (lastIndex < text.length) parts.push(<span key={`t-end`}>{text.slice(lastIndex)}</span>);
  return parts;
}

export default function RegexTester() {
  const [pattern, setPattern] = useState("");
  const [flags, setFlags] = useState<string[]>(["g", "i"]);
  const [testStr, setTestStr] = useState("");
  const { toast } = useToast();

  const toggleFlag = (f: string) => setFlags((prev) => prev.includes(f) ? prev.filter((x) => x !== f) : [...prev, f]);

  const result = useMemo(() => {
    if (!pattern || !testStr) return null;
    try {
      const regex = new RegExp(pattern, flags.join(""));
      const matches: MatchResult[] = [];
      const safeRegex = new RegExp(pattern, flags.includes("g") ? flags.join("") : flags.join("") + "g");
      safeRegex.lastIndex = 0;
      let m: RegExpExecArray | null;
      while ((m = safeRegex.exec(testStr)) !== null) {
        matches.push({ match: m[0], index: m.index, groups: m.slice(1) });
        if (m[0].length === 0) safeRegex.lastIndex++;
        if (matches.length > 500) break;
      }
      return { ok: true as const, regex, matches };
    } catch (e) {
      return { ok: false as const, error: e instanceof Error ? e.message : String(e) };
    }
  }, [pattern, flags, testStr]);

  const loadExample = (ex: typeof EXAMPLES[0]) => {
    setPattern(ex.pattern);
    setFlags(ex.flags.split(""));
    setTestStr(ex.test);
  };

  const copyPattern = () => {
    if (!pattern) return;
    navigator.clipboard.writeText(`/${pattern}/${flags.join("")}`);
    toast({ title: "Copied!", description: "Pattern copied to clipboard." });
  };

  return (
    <MiniToolLayout
      seoTitle="Regex Tester Online — Regular Expression Tester & Debugger Free"
      seoDescription="Test regular expressions online with live match highlighting, capture group inspection, and flag controls. JavaScript regex engine, 100% client-side."
      icon={Regex}
      badge="Developer Tool"
      title="Regex Tester"
      description="Test and debug regular expressions with live match highlighting. Inspect capture groups, toggle flags, and see results update as you type."
      faqs={faqs}
      relatedTools={relatedTools}
      educationalSections={[
        {
          heading: "What Are Regular Expressions?",
          body: "Regular expressions (regex) are patterns that match text. They're supported in virtually every programming language and countless tools. One well-crafted regex can replace dozens of lines of string manipulation code — validating emails, extracting data, finding and replacing patterns, or parsing log files.",
        },
        {
          heading: "Regex Flags Explained",
          items: [
            "g (global) — find all matches in the string, not just the first one",
            "i (case-insensitive) — match abc, ABC, Abc, etc. as equivalent",
            "m (multiline) — makes ^ and $ match the start/end of each line, not just the whole string",
            "s (dotAll) — makes . match newline characters too (normally it skips them)",
            "u (unicode) — enables full Unicode mode; needed for emoji and characters above U+FFFF",
          ],
        },
        {
          heading: "Quick-Start Patterns",
          code: `// Email (basic):     /^[\\w._%+\\-]+@[\\w.\\-]+\\.[a-z]{2,}$/i
// URL (http/https):   /https?:\\/\\/[^\\s]+/
// Digits only:        /^\\d+$/
// Slug:               /^[a-z0-9]+(?:-[a-z0-9]+)*$/
// Hex color:          /#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})\\b/
// Whitespace trim:    /^\\s+|\\s+$/g`,
          callout: { type: "tip", text: "Test patterns against edge cases and empty strings. A regex that works on your sample data can fail on inputs you didn't anticipate — especially when users control the input." },
        },
      ]}
      relatedArticles={[
        { title: "Regex Cheat Sheet: The Most Useful Patterns for Developers", href: "/blog/regex-cheat-sheet", readingTime: 8 },
        { title: "URL Encoding Explained: Percent-Encoding and When You Need It", href: "/blog/url-encoding-explained", readingTime: 6 },
      ]}
    >
      <div className="space-y-4">
        {/* Pattern input */}
        <div className="rounded-xl border border-border/60 bg-card/40 p-4 space-y-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">Pattern</span>
            <div className="flex-1" />
            {EXAMPLES.map((ex) => (
              <button key={ex.label} onClick={() => loadExample(ex)} className="text-[11px] text-primary/70 hover:text-primary border border-border/50 hover:border-primary/30 rounded-md px-2 py-0.5 transition-colors">
                {ex.label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-muted-foreground font-mono text-sm">/</span>
            <input
              value={pattern}
              onChange={(e) => setPattern(e.target.value)}
              placeholder="Enter regex pattern…"
              spellCheck={false}
              className="flex-1 bg-background/60 border border-border/60 rounded-lg px-3 py-2 font-mono text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground/40"
            />
            <span className="text-muted-foreground font-mono text-sm">/{flags.join("")}</span>
            <Button variant="ghost" size="sm" onClick={copyPattern} disabled={!pattern} className="text-xs gap-1">
              <Copy className="h-3.5 w-3.5" /> Copy
            </Button>
            <Button variant="ghost" size="sm" onClick={() => { setPattern(""); setTestStr(""); }} disabled={!pattern && !testStr} className="text-xs gap-1 text-muted-foreground">
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </div>

          {/* Flags */}
          <div className="flex flex-wrap gap-2">
            {FLAGS.map((f) => (
              <button
                key={f}
                onClick={() => toggleFlag(f)}
                className={`inline-flex items-center gap-1.5 text-xs px-2.5 py-1 rounded-lg border font-mono transition-all ${flags.includes(f) ? "bg-primary/10 border-primary/30 text-primary" : "bg-muted/30 border-border/50 text-muted-foreground hover:border-border"}`}
              >
                <span className="font-bold">{f}</span>
                <span className="font-sans font-normal hidden sm:inline">{FLAG_LABELS[f]}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Validation badge */}
        {pattern && (
          <div className={`flex items-center gap-2 text-sm rounded-lg px-3 py-2 border ${result?.ok === false ? "bg-destructive/10 border-destructive/30 text-destructive" : "bg-green-500/10 border-green-500/25 text-green-500"}`}>
            {result?.ok === false ? <><XCircle className="h-4 w-4 shrink-0" /> {result.error}</> : <><CheckCircle2 className="h-4 w-4 shrink-0" /> Valid pattern — {result?.matches.length ?? 0} match{result?.matches.length !== 1 ? "es" : ""}</>}
          </div>
        )}

        {/* Test string with highlights */}
        <div className="space-y-2">
          <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">Test String</span>
          <textarea
            value={testStr}
            onChange={(e) => setTestStr(e.target.value)}
            placeholder="Paste your test string here…"
            className="w-full min-h-[140px] resize-y rounded-xl border border-border/60 bg-background/60 px-4 py-3 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground/35"
          />
        </div>

        {/* Highlighted preview */}
        {testStr && result?.ok && result.matches.length > 0 && (
          <div className="space-y-2">
            <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">Highlighted Matches</span>
            <div className="rounded-xl border border-border/60 bg-muted/20 px-4 py-3 font-mono text-sm leading-relaxed whitespace-pre-wrap break-words">
              {highlightMatches(testStr, result.regex)}
            </div>
          </div>
        )}

        {/* Match details */}
        {result?.ok && result.matches.length > 0 && (
          <div className="space-y-2">
            <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">
              Matches ({result.matches.length})
            </span>
            <div className="space-y-1.5 max-h-64 overflow-y-auto">
              {result.matches.map((m, i) => (
                <div key={i} className="flex items-start gap-3 rounded-lg border border-border/50 bg-card/40 px-3 py-2">
                  <span className="text-[10px] font-mono text-muted-foreground/60 bg-muted/40 rounded px-1.5 py-0.5 shrink-0">#{i + 1}</span>
                  <div className="min-w-0">
                    <code className="text-xs font-mono text-foreground/90 break-all">{m.match || "<empty>"}</code>
                    <div className="text-[10px] text-muted-foreground mt-0.5">index {m.index}{m.groups.length > 0 && ` · groups: ${m.groups.map((g, gi) => `$${gi + 1}="${g ?? "undefined"}"`).join(", ")}`}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {testStr && result?.ok && result.matches.length === 0 && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground rounded-lg border border-border/50 bg-muted/20 px-4 py-3">
            <Info className="h-4 w-4 shrink-0" /> No matches found in the test string.
          </div>
        )}
      </div>
    </MiniToolLayout>
  );
}
