import { useState, useCallback } from "react";
import { MiniToolLayout } from "@/components/layout/MiniToolLayout";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Database, Copy, Trash2, Download, Maximize2 } from "lucide-react";

const faqs = [
  { q: "What is SQL formatting?", a: "SQL formatting adds consistent indentation, line breaks, and keyword capitalization to SQL queries, making them easier to read, review, and debug. Raw or generated SQL is often written on a single line with inconsistent capitalization — formatting fixes that instantly." },
  { q: "Does formatting change how the SQL query runs?", a: "No — SQL formatting only changes whitespace and capitalization. The query executes identically regardless of formatting. Databases ignore extra whitespace and are case-insensitive for keywords." },
  { q: "What SQL dialects does this tool support?", a: "This tool formats standard SQL and works with MySQL, PostgreSQL, SQLite, SQL Server (T-SQL), and Oracle SQL. It capitalizes standard SQL keywords and applies consistent indentation — dialect-specific syntax is preserved as-is." },
  { q: "Is my SQL data safe to paste here?", a: "Yes — all formatting runs entirely in your browser using JavaScript. No SQL queries are ever sent to a server, so it's safe to use with sensitive queries containing real table names or schema information." },
  { q: "Can I use this for stored procedures?", a: "Yes — this tool handles complex SQL including subqueries, CTEs (WITH clauses), JOINs, GROUP BY, HAVING, and multi-statement blocks. It's designed for real-world SQL, not just simple SELECT statements." },
  { q: "Why should I format SQL before code review?", a: "Formatted SQL is dramatically easier to review, especially for complex joins and subqueries. It reduces cognitive load, makes the query structure immediately apparent, and helps reviewers spot logic errors faster." },
];

const relatedTools = [
  { title: "JSON Formatter", href: "/tools/json-formatter", description: "Format and validate JSON with real-time error detection." },
  { title: "HTML Formatter", href: "/tools/html-formatter", description: "Format and beautify HTML markup with proper indentation." },
  { title: "CSS Minifier", href: "/tools/css-minifier", description: "Minify CSS files by removing whitespace and comments." },
  { title: "Regex Tester", href: "/tools/regex-tester", description: "Test regular expressions with live match highlighting." },
];

const EXAMPLE_SQL = `select u.id, u.name, u.email, count(o.id) as order_count, sum(o.total) as total_spent from users u left join orders o on u.id = o.user_id where u.created_at >= '2024-01-01' and u.status = 'active' group by u.id, u.name, u.email having count(o.id) > 0 order by total_spent desc limit 50;`;

const KEYWORDS = [
  "SELECT","FROM","WHERE","AND","OR","NOT","IN","IS","NULL","LIKE","BETWEEN",
  "JOIN","INNER JOIN","LEFT JOIN","RIGHT JOIN","FULL JOIN","FULL OUTER JOIN",
  "CROSS JOIN","ON","AS","GROUP BY","ORDER BY","HAVING","LIMIT","OFFSET",
  "INSERT INTO","VALUES","UPDATE","SET","DELETE FROM","CREATE TABLE",
  "ALTER TABLE","DROP TABLE","CREATE INDEX","DROP INDEX","TRUNCATE TABLE",
  "WITH","UNION","UNION ALL","INTERSECT","EXCEPT","CASE","WHEN","THEN","ELSE","END",
  "EXISTS","ALL","ANY","DISTINCT","COUNT","SUM","AVG","MIN","MAX","COALESCE",
  "NULLIF","CAST","CONVERT","DATE","NOW","CURRENT_TIMESTAMP","PRIMARY KEY",
  "FOREIGN KEY","REFERENCES","CONSTRAINT","DEFAULT","NOT NULL","UNIQUE","CHECK",
  "INDEX","VIEW","PROCEDURE","FUNCTION","TRIGGER","BEGIN","COMMIT","ROLLBACK",
  "INTO","RETURNING","EXPLAIN","ANALYZE",
];

function formatSQL(sql: string): string {
  let s = sql.replace(/\s+/g, " ").trim();

  const sortedKw = [...KEYWORDS].sort((a, b) => b.length - a.length);
  for (const kw of sortedKw) {
    const regex = new RegExp(`\\b${kw.replace(/ /g, "\\s+")}\\b`, "gi");
    s = s.replace(regex, kw);
  }

  const breakBefore = [
    "SELECT","FROM","WHERE","AND","OR","GROUP BY","ORDER BY","HAVING","LIMIT","OFFSET",
    "INNER JOIN","LEFT JOIN","RIGHT JOIN","FULL JOIN","FULL OUTER JOIN","CROSS JOIN","JOIN",
    "ON","UNION","UNION ALL","INTERSECT","EXCEPT","INSERT INTO","VALUES","UPDATE","SET",
    "DELETE FROM","WITH","CASE","END",
  ];

  for (const kw of breakBefore) {
    const regex = new RegExp(`\\s+${kw.replace(/ /g, "\\s+")}\\b`, "g");
    s = s.replace(regex, `\n${kw}`);
  }

  const lines = s.split("\n");
  const result: string[] = [];
  let indent = 0;

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;

    const firstWord = trimmed.split(/\s+/)[0].toUpperCase();

    if (["FROM","WHERE","JOIN","INNER","LEFT","RIGHT","FULL","CROSS","GROUP","ORDER","HAVING","LIMIT","OFFSET","ON","UNION","INTERSECT","EXCEPT","INTO","VALUES","SET"].includes(firstWord)) {
      result.push("  " + trimmed);
    } else if (firstWord === "AND" || firstWord === "OR") {
      result.push("    " + trimmed);
    } else if (firstWord === "SELECT" || firstWord === "UPDATE" || firstWord === "DELETE" || firstWord === "INSERT" || firstWord === "WITH" || firstWord === "CREATE" || firstWord === "ALTER" || firstWord === "DROP") {
      result.push(trimmed);
    } else {
      result.push("  ".repeat(indent) + trimmed);
    }
  }

  return result.join("\n").trim();
}

export default function SqlFormatter() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const { toast } = useToast();

  const handleFormat = useCallback(() => {
    if (!input.trim()) return;
    setOutput(formatSQL(input));
  }, [input]);

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    toast({ title: "Copied!", description: "SQL copied to clipboard." });
  };

  const handleDownload = () => {
    if (!output) return;
    const blob = new Blob([output], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "query.sql";
    a.click();
    URL.revokeObjectURL(url);
    toast({ title: "Downloaded!", description: "query.sql saved." });
  };

  return (
    <MiniToolLayout
      seoTitle="SQL Formatter Online Free — Format & Prettify SQL Queries"
      seoDescription="Format and prettify SQL queries online for free. Keyword capitalization, proper indentation, multi-dialect support. 100% client-side — your queries never leave your browser."
      icon={Database}
      badge="Developer Tool"
      title="SQL Formatter"
      description="Paste any SQL query to instantly format it with proper indentation, keyword capitalization, and readable line breaks. Supports MySQL, PostgreSQL, SQLite, and SQL Server."
      faqs={faqs}
      relatedTools={relatedTools}
    >
      <div className="space-y-4">
        <div className="grid md:grid-cols-2 gap-3">
          {/* Input */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">Input SQL</span>
              <button onClick={() => { setInput(EXAMPLE_SQL); setOutput(""); }} className="text-[11px] text-primary/70 hover:text-primary underline underline-offset-2 transition-colors">Load example</button>
            </div>
            <textarea
              value={input}
              onChange={(e) => { setInput(e.target.value); setOutput(""); }}
              placeholder={`Paste your SQL here…\n\nSELECT * FROM users WHERE id = 1;`}
              spellCheck={false}
              className="w-full min-h-[340px] md:min-h-[420px] resize-y rounded-xl border border-border/60 bg-background/60 px-4 py-3 font-mono text-xs leading-relaxed focus:outline-none focus:ring-2 focus:ring-primary/30 placeholder:text-muted-foreground/35"
            />
          </div>

          {/* Output */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground/70 uppercase tracking-wide">Formatted SQL</span>
              {output && <span className="text-[10px] font-mono text-muted-foreground/60 bg-muted/50 px-1.5 py-0.5 rounded">{output.split("\n").length} lines</span>}
            </div>
            <div className={`relative w-full min-h-[340px] md:min-h-[420px] rounded-xl border bg-muted/20 overflow-auto ${output ? "border-border/60" : "border-border/40 border-dashed"}`}>
              {output ? (
                <pre className="px-4 py-3 font-mono text-xs leading-relaxed text-foreground/90 whitespace-pre-wrap break-all">{output}</pre>
              ) : (
                <div className="absolute inset-0 flex items-center justify-center text-sm text-muted-foreground/40">
                  Formatted SQL appears here
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={handleFormat} disabled={!input.trim()} className="text-xs gap-1.5 shadow-sm shadow-primary/20">
            <Maximize2 className="h-3.5 w-3.5" /> Format SQL
          </Button>
          <div className="flex-1" />
          <Button variant="outline" size="sm" onClick={handleCopy} disabled={!output} className="text-xs gap-1.5 border-border/60">
            <Copy className="h-3.5 w-3.5" /> Copy
          </Button>
          <Button variant="outline" size="sm" onClick={handleDownload} disabled={!output} className="text-xs gap-1.5 border-border/60">
            <Download className="h-3.5 w-3.5" /> Download .sql
          </Button>
          <Button variant="ghost" size="sm" onClick={() => { setInput(""); setOutput(""); }} disabled={!input && !output} className="text-xs gap-1.5 text-muted-foreground">
            <Trash2 className="h-3.5 w-3.5" /> Clear
          </Button>
        </div>
      </div>
    </MiniToolLayout>
  );
}
