import {
  Code2, FileJson, Lock, Shield, Zap, Globe,
  Terminal, RefreshCw, Type, TrendingUp, Users,
  Regex, KeyRound, Fingerprint, Link2, Braces, Paintbrush, Database,
} from "lucide-react";
import { ALL_TOOLS } from "@/lib/tools-registry";
import { CategoryLandingPage, type CategoryPageConfig } from "./CategoryLandingPage";

const tools = ALL_TOOLS.filter((t) => t.category === "developer");

const config: CategoryPageConfig = {
  path: "/developer-tools",
  seoTitle: "Free Online Developer Tools — JSON, Regex, JWT, UUID, SQL, CSS | X Toolkit",
  seoDescription:
    "9 free browser-based developer utilities: JSON formatter, Regex tester, JWT decoder, UUID generator, URL encoder, HTML formatter, CSS minifier, SQL formatter. No install, no signup.",
  title: "Developer Tools",
  tagline: "Browser-based dev utilities — instant, private, zero-install",
  description:
    "Fast, privacy-first developer tools that run entirely in your browser. Format JSON, test regex, decode JWTs, generate UUIDs, encode URLs, format HTML, minify CSS, format SQL — no account, no install, no data leaving your device.",
  icon: Code2,
  color: "text-orange-400",
  bg: "bg-orange-400/10 border-orange-400/20",
  heroGradient: "bg-gradient-to-br from-orange-500/8 via-orange-500/3 to-transparent",
  tools,

  whatIs:
    "Developer tools are browser-based utilities that help engineers, designers, and technical users handle common formatting, encoding, and debugging tasks without installing anything. From JSON formatting and validation to regex testing with live match highlighting, JWT decoding, cryptographically secure UUID generation, URL percent-encoding, HTML beautification, CSS minification, and SQL formatting — every tool processes data locally in your browser. Nothing is ever sent to a server.",

  benefits: [
    {
      icon: Shield,
      title: "Fully private — data stays local",
      description:
        "All processing runs in your browser via JavaScript. No text, tokens, queries, or payloads are ever transmitted to our servers.",
    },
    {
      icon: Zap,
      title: "Instant results",
      description:
        "No upload step, no waiting for a server response. Paste your input and the output appears in real time.",
    },
    {
      icon: Globe,
      title: "No install or account needed",
      description:
        "Open a URL, use the tool, close the tab. No npm install, no browser extension, no OAuth flow.",
    },
    {
      icon: FileJson,
      title: "JSON error detection",
      description:
        "The formatter highlights exactly where a syntax error is and explains what's wrong — saving frustrating hunts through minified blobs.",
    },
    {
      icon: Regex,
      title: "Live regex match highlighting",
      description:
        "Test patterns with live highlighting, flag controls, and capture group inspection — all using JavaScript's native regex engine.",
    },
    {
      icon: Terminal,
      title: "Works on any device",
      description:
        "No local runtime required. Tools work the same on your phone, tablet, or work laptop without any setup.",
    },
  ],

  useCases: [
    {
      title: "Debugging API responses",
      description:
        "Paste a raw JSON response from an API endpoint into the formatter to instantly see the structure, find nested keys, and spot errors.",
    },
    {
      title: "Inspecting JWT tokens",
      description:
        "Decode JWT headers, payloads, and expiry timestamps without pulling up a terminal — see every claim at a glance.",
    },
    {
      title: "Generating unique IDs",
      description:
        "Generate cryptographically secure UUID v4s in bulk for database seeding, test data, or any context requiring unique identifiers.",
    },
    {
      title: "Building and testing regex patterns",
      description:
        "Write and test regular expressions with live match highlighting, flag toggles, and capture group inspection for any validation or parsing task.",
    },
    {
      title: "Encoding query parameters",
      description:
        "Percent-encode URL query string values before including them in API requests or redirect URLs — and decode incoming encoded strings.",
    },
    {
      title: "Minifying CSS for production",
      description:
        "Reduce stylesheet file size by removing whitespace, comments, and redundant characters before deployment — see the exact percentage saved.",
    },
    {
      title: "Formatting SQL for readability",
      description:
        "Paste a one-liner SQL query and instantly get properly indented, keyword-capitalized output for review, documentation, or team sharing.",
    },
    {
      title: "Beautifying HTML templates",
      description:
        "Format minified or auto-generated HTML with proper indentation to make email templates, components, and pages readable and debuggable.",
    },
  ],

  faqs: [
    {
      q: "Is my data sent to X Toolkit's servers when I use these tools?",
      a: "No. Every developer tool on this page runs entirely in your browser using JavaScript. Your JSON, JWTs, SQL queries, CSS, regex patterns, and other inputs never leave your device.",
    },
    {
      q: "What is the difference between the JSON formatter and the HTML formatter?",
      a: "The JSON formatter parses and reformats JSON data (objects, arrays, strings, numbers). The HTML formatter indents HTML markup and handles tag nesting. Both add readability, but they work on completely different formats.",
    },
    {
      q: "Can the JWT decoder verify token signatures?",
      a: "No — signature verification requires the secret key or public certificate, which cannot be done client-side without exposing the secret. This tool decodes and inspects the header and payload only. Use server-side libraries for verification.",
    },
    {
      q: "Are the generated UUIDs truly random and secure?",
      a: "Yes — the UUID generator uses the browser's crypto.randomUUID() API, which produces cryptographically secure pseudo-random UUIDs suitable for security-sensitive contexts.",
    },
    {
      q: "What regex flavor does the tester use?",
      a: "The regex tester uses JavaScript's native RegExp engine, which supports most PCRE-compatible syntax including lookaheads, character classes, named groups, and Unicode categories with the 'u' flag.",
    },
    {
      q: "Does the CSS minifier remove vendor prefixes?",
      a: "No — the minifier only removes whitespace, comments, and redundant semicolons. It does not modify your CSS rules, vendor prefixes, or property values. For more aggressive optimization, use a dedicated build tool like PostCSS.",
    },
    {
      q: "What SQL dialects does the SQL formatter support?",
      a: "The formatter handles standard SQL and is compatible with MySQL, PostgreSQL, SQLite, and SQL Server (T-SQL). It capitalizes SQL keywords and applies consistent indentation — dialect-specific syntax is preserved as-is.",
    },
    {
      q: "Are more developer tools planned?",
      a: "Yes — upcoming tools include a color format converter, diff checker, and cron expression parser. Check back or follow the blog for updates.",
    },
  ],

  relatedCategories: [
    {
      title: "Text & Formatting Tools",
      href: "/text-format-tools",
      description: "Format tweet threads, count characters, and preview Unicode fonts.",
      icon: Type,
      color: "text-green-400",
      bg: "bg-green-400/10 border-green-400/20",
    },
    {
      title: "SEO Tools",
      href: "/seo-tools",
      description: "Meta tag analysis, keyword density checking, and URL slug generation.",
      icon: TrendingUp,
      color: "text-pink-400",
      bg: "bg-pink-400/10 border-pink-400/20",
    },
    {
      title: "Social Media Tools",
      href: "/social-media-tools",
      description: "Bulk account checker, profile link generator, and @ formatter for X.",
      icon: Users,
      color: "text-blue-400",
      bg: "bg-blue-400/10 border-blue-400/20",
    },
  ],
};

export default function DeveloperToolsPage() {
  return <CategoryLandingPage config={config} />;
}
