import { Link } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { SeoHead } from "@/components/SeoHead";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import {
  Inbox, ArrowRight, Shield, Zap, Clock, RefreshCw,
  CheckCircle2, Lock, Mail, Ban, Eye, Wifi,
} from "lucide-react";

const SITE_URL = "https://xtoolkit.live";

const faqs = [
  { q: "Is this temp mail service completely free?", a: "Yes — 100% free, no account required, no credit card. Generate a working inbox instantly and use it as many times as you want." },
  { q: "How long does the temporary email address last?", a: "Your temp mail inbox is active for your current browser session. If you close the tab, refresh the page, or click 'New Address', you get a fresh inbox. The old address becomes inactive." },
  { q: "Can I receive all types of emails?", a: "Yes — HTML emails, plain text emails, and emails with attachments are all supported. Transactional emails (signup confirmations, password resets, verification codes) arrive typically within seconds." },
  { q: "Will websites know I'm using a temp email?", a: "Some services maintain blocklists of known temp mail domains. If a service rejects your address, you can generate a new one to get a different domain. The cat-and-mouse between temp mail providers and blocklists is ongoing." },
  { q: "Is my temporary inbox private?", a: "The address is randomly generated and not linked to your identity. However, anyone who knows the address could theoretically read the inbox. Don't use it for anything sensitive — it's designed for one-time verifications." },
  { q: "Can I use temp mail to sign up for services I plan to keep using?", a: "No — since the inbox expires with your session, you'd lose account recovery access for any service you sign up for. Use temp mail only for one-time verifications where you don't need the account long-term." },
  { q: "How quickly do emails arrive?", a: "Usually within a few seconds to a minute after being sent. The inbox auto-refreshes every 15 seconds, so new emails appear automatically without any action needed." },
  { q: "Is there a limit on how many emails I can receive?", a: "For practical purposes, no. Each inbox can receive multiple emails during its session lifetime. There's no per-session cap on message count." },
];

const BENEFITS = [
  { icon: Shield, title: "Protect your real inbox", description: "Never give your primary email to a service you don't fully trust. Temp mail absorbs the spam so you don't have to." },
  { icon: Zap, title: "Instant — no signup", description: "One click generates a fully working email address. No form, no verification, no waiting." },
  { icon: RefreshCw, title: "Auto-refreshing inbox", description: "New emails appear automatically every 15 seconds. No manual refresh needed during verification flows." },
  { icon: Lock, title: "No account, no tracking", description: "The address is randomly generated. It's not linked to your identity, browser, or any account." },
  { icon: Clock, title: "Session-based expiry", description: "The inbox expires automatically when you're done. No cleanup needed — it simply stops existing." },
  { icon: CheckCircle2, title: "Works with any service", description: "Use it for SaaS trials, content downloads, forums, Wi-Fi hotspots, and any signup that requires email verification." },
];

const USE_CASES = [
  { icon: Mail, title: "Free trial signups", description: "Try SaaS products without committing your real email to their marketing lists or sales pipelines." },
  { icon: Ban, title: "Blocking spam at source", description: "Use a disposable address for any signup you're unsure about. If spam comes, it goes nowhere near your real inbox." },
  { icon: Eye, title: "Developer testing", description: "Test signup flows, email deliverability, and transactional emails without using real inboxes or setting up test accounts." },
  { icon: Wifi, title: "Wi-Fi hotspot access", description: "Hotel, airport, and café Wi-Fi often requires email verification. Use a temp address to get connected without the follow-up marketing." },
];

export default function TempMailLanding() {
  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: SITE_URL },
      { "@type": "ListItem", position: 2, name: "Temp Mail", item: `${SITE_URL}/temp-mail` },
    ],
  };

  const webPageSchema = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: "Temp Mail — Free Disposable Email Address",
    description: "Generate a free disposable temporary email address instantly. Auto-refreshing inbox, no signup required.",
    url: `${SITE_URL}/temp-mail`,
    applicationCategory: "UtilitiesApplication",
    offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
    operatingSystem: "Web",
  };

  return (
    <Layout>
      <SeoHead
        title="Temp Mail — Free Disposable Temporary Email Address | X Toolkit"
        description="Generate a free temporary email address instantly. Auto-refreshing inbox, no signup required. Block spam, protect privacy, and verify accounts without exposing your real email."
        path="/temp-mail"
        faqs={faqs}
        extraSchemas={[breadcrumbSchema, webPageSchema]}
      />

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border/50 bg-gradient-to-br from-cyan-500/8 via-cyan-500/3 to-transparent">
        <div className="max-w-5xl mx-auto px-4 md:px-8 pt-14 pb-16 md:pt-20 md:pb-24 text-center">
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="h-14 w-14 rounded-2xl border border-cyan-400/20 bg-cyan-400/10 flex items-center justify-center">
              <Inbox className="h-7 w-7 text-cyan-400" />
            </div>
            <Badge variant="outline" className="border-cyan-400/30 text-cyan-400 bg-cyan-400/8 text-xs font-medium">
              Free · No signup
            </Badge>
          </div>

          <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
            Temp Mail — <span className="text-cyan-400">Disposable Email</span><br className="hidden md:block" /> Address Generator
          </h1>
          <p className="text-muted-foreground max-w-2xl mx-auto text-base md:text-lg mb-8 leading-relaxed">
            Generate a free temporary email address in one click. Receive verification emails instantly in an auto-refreshing inbox. No account, no password, no spam in your real inbox.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/tools/temp-mail">
              <Button size="lg" className="shadow-sm shadow-cyan-400/20 gap-2 text-sm">
                <Inbox className="h-4 w-4" /> Generate Free Temp Mail <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
            <Link href="/blog/how-temporary-email-works">
              <Button variant="outline" size="lg" className="border-border/60 gap-2 text-sm">
                How it works
              </Button>
            </Link>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-6 mt-8 text-xs text-muted-foreground">
            {["Auto-refreshes every 15s", "No signup required", "Session-based expiry", "Works anywhere"].map((f) => (
              <div key={f} className="flex items-center gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400" /> {f}
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="max-w-5xl mx-auto px-4 md:px-8">

        {/* Benefits */}
        <section className="py-14 border-b border-border/50">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight mb-3">Why use a temporary email address?</h2>
            <p className="text-muted-foreground max-w-xl mx-auto text-sm">Every signup with your real email is a permanent trade. Temp mail breaks that trade.</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {BENEFITS.map(({ icon: Icon, title, description }) => (
              <div key={title} className="rounded-xl border border-border/60 bg-card/40 p-5 space-y-2.5">
                <div className="h-9 w-9 rounded-lg border border-cyan-400/20 bg-cyan-400/10 flex items-center justify-center">
                  <Icon className="h-4.5 w-4.5 text-cyan-400" style={{ height: "1.125rem", width: "1.125rem" }} />
                </div>
                <h3 className="text-sm font-semibold">{title}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* How it works */}
        <section className="py-14 border-b border-border/50">
          <h2 className="text-2xl font-bold tracking-tight mb-8 text-center">How temp mail works</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { step: "1", title: "Generate address", desc: "Click once and a unique @domain email address is created instantly — no form, no personal info." },
              { step: "2", title: "Use it anywhere", desc: "Copy the address and use it for signups, downloads, trials, or any verification that requires email." },
              { step: "3", title: "Receive emails", desc: "The inbox auto-refreshes every 15 seconds. New messages appear instantly — click to read the full email." },
              { step: "4", title: "It expires cleanly", desc: "When you're done, close the tab. The inbox expires automatically. No cleanup, no lingering data." },
            ].map(({ step, title, desc }) => (
              <div key={step} className="rounded-xl border border-border/60 bg-card/40 p-5 space-y-3 relative">
                <span className="text-3xl font-black text-cyan-400/20">{step}</span>
                <h3 className="text-sm font-semibold">{title}</h3>
                <p className="text-xs text-muted-foreground leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Use cases */}
        <section className="py-14 border-b border-border/50">
          <h2 className="text-2xl font-bold tracking-tight mb-2">Common use cases</h2>
          <p className="text-sm text-muted-foreground mb-8">Real scenarios where disposable email addresses protect your privacy and productivity.</p>
          <div className="grid sm:grid-cols-2 gap-4">
            {USE_CASES.map(({ icon: Icon, title, description }) => (
              <div key={title} className="flex items-start gap-3 rounded-xl border border-border/60 bg-card/40 p-5">
                <div className="h-9 w-9 rounded-lg border border-cyan-400/20 bg-cyan-400/10 flex items-center justify-center shrink-0 mt-0.5">
                  <Icon className="h-4.5 w-4.5 text-cyan-400" style={{ height: "1.125rem", width: "1.125rem" }} />
                </div>
                <div>
                  <h3 className="text-sm font-semibold mb-1">{title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* FAQ */}
        <section className="py-14 border-b border-border/50">
          <h2 className="text-2xl font-bold tracking-tight mb-8">Frequently asked questions</h2>
          <Accordion type="single" collapsible className="space-y-2">
            {faqs.map(({ q, a }, i) => (
              <AccordionItem key={i} value={`faq-${i}`} className="rounded-xl border border-border/60 bg-card/40 px-5 data-[state=open]:bg-card/70 transition-colors">
                <AccordionTrigger className="text-sm font-medium text-left hover:no-underline py-4">{q}</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground pb-4 leading-relaxed">{a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>

        {/* Related tools */}
        <section className="py-14 border-b border-border/50">
          <h2 className="text-xl font-bold tracking-tight mb-2">Related email tools</h2>
          <p className="text-sm text-muted-foreground mb-6">More free tools in the email category.</p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              { title: "Email Validator", href: "/tools/email-validator", description: "Validate email address syntax and format instantly." },
              { title: "Email Signature Generator", href: "/tools/email-signature-generator", description: "Build a professional HTML email signature." },
              { title: "Subject Line Generator", href: "/tools/subject-line-generator", description: "Generate high-converting email subject lines." },
              { title: "Email Character Counter", href: "/tools/email-character-counter", description: "Count email characters with per-client limits." },
              { title: "Email Username Generator", href: "/tools/email-username-generator", description: "Generate professional email address formats." },
              { title: "Plain Text Formatter", href: "/tools/plain-text-formatter", description: "Convert HTML emails to clean plain text." },
            ].map(({ title, href, description }) => (
              <Link key={href} href={href}>
                <div className="group rounded-xl border border-border/60 bg-card/40 p-4 hover:border-cyan-400/30 hover:bg-card transition-all cursor-pointer">
                  <h3 className="text-sm font-semibold group-hover:text-cyan-400 transition-colors mb-1 flex items-center gap-1">
                    {title} <ArrowRight className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </h3>
                  <p className="text-xs text-muted-foreground">{description}</p>
                </div>
              </Link>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="py-14">
          <div className="rounded-2xl border border-cyan-400/20 bg-gradient-to-br from-cyan-500/8 via-cyan-500/4 to-transparent p-8 md:p-10 text-center">
            <h2 className="text-2xl font-bold tracking-tight mb-3">Ready to protect your inbox?</h2>
            <p className="text-muted-foreground text-sm max-w-md mx-auto mb-6">
              Generate a disposable email address in one click. Free forever, no account needed.
            </p>
            <Link href="/tools/temp-mail">
              <Button size="lg" className="shadow-sm shadow-cyan-400/20 gap-2">
                <Inbox className="h-4 w-4" /> Create Temp Mail Now <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </section>

      </div>
    </Layout>
  );
}
