import { Link } from "wouter";
import { motion } from "framer-motion";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ToolCard } from "@/components/ToolCard";
import { CATEGORIES, LIVE_TOOLS, TOTAL_LIVE, getPopularTools, getNewTools, getToolsByCategory } from "@/lib/tools-registry";
import { trackEvent } from "@/lib/analytics";
import {
  CheckCircle2, Zap, Shield, Star, ArrowRight, Users,
} from "lucide-react";

const CATEGORY_ORDER: import("@/lib/tools-registry").CategoryKey[] = [
  "social-media",
  "ai-writing",
  "text-formatting",
  "developer",
  "seo",
];

const TESTIMONIALS = [
  {
    quote: "Saved me hours of manual checking. I manage 5 brand accounts and needed to bulk-verify a list of 80+ influencers. Done in 10 seconds.",
    name: "Sarah K.",
    role: "Social Media Manager",
    stars: 5,
  },
  {
    quote: "The JSON formatter is exactly what I needed — real-time validation with proper error messages. Way cleaner than pasting into browser devtools.",
    name: "DevMike",
    role: "Web Developer",
    stars: 5,
  },
  {
    quote: "Clean, fast, no signup. I use the bio generator and @ formatter constantly. The Base64 tool saved me when debugging an API last week.",
    name: "XGrowthPro",
    role: "Growth Marketer",
    stars: 5,
  },
];

const FAQS = [
  { q: "Is everything here completely free?", a: "Yes — 100% free, forever. No signup, no credit card, no hidden fees. Every tool works without an account." },
  { q: "How many X accounts can I check at once?", a: "Up to 100 usernames in a single batch, all checked in parallel. Results come back in seconds." },
  { q: "Do the developer tools send my data to a server?", a: "No. The JSON Formatter, Base64 Encoder, and all other developer tools run entirely in your browser. Nothing is sent to a server." },
  { q: "How does the AI bio generator work?", a: "It uses Groq's fast LLM API. Enter your niche and tone and get 3 ready-to-use bios instantly. Provide your own free Groq API key for unlimited generations." },
  { q: "Is my data stored or tracked?", a: "No. We don't store usernames, results, bios, or any personal data. Everything is processed in real-time and immediately discarded." },
  { q: "What new tools are coming?", a: "We're building SEO tools (meta checker, keyword density), more developer utilities (URL encoder, CSS minifier), and creator tools. Subscribe to get notified." },
  { q: "Does this work on mobile?", a: "Yes — every tool is fully responsive and optimized for mobile, tablet, and desktop." },
];

const fadeUp = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 },
};

const stagger = {
  show: { transition: { staggerChildren: 0.08 } },
};

function StarRating({ count }: { count: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: count }).map((_, i) => (
        <Star key={i} className="h-3.5 w-3.5 fill-warning text-warning" />
      ))}
    </div>
  );
}

export default function Home() {
  const popularTools = getPopularTools();
  const newTools = getNewTools();
  const socialTools = getToolsByCategory("social-media");
  const devTools = getToolsByCategory("developer");

  return (
    <Layout>
      {/* ── Hero ── */}
      <section className="relative overflow-hidden">
        {/* Subtle radial highlight behind hero text */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] rounded-full"
            style={{ background: "radial-gradient(ellipse at 50% 0%, hsl(237 72% 65% / 0.08), transparent 70%)" }}
          />
        </div>

        <div className="max-w-6xl mx-auto px-4 md:px-8 pt-16 pb-14 md:pt-24 md:pb-20 text-center relative">
          <motion.div
            initial="hidden"
            animate="show"
            variants={stagger}
            className="flex flex-col items-center"
          >
            {/* Badge */}
            <motion.div variants={fadeUp} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}>
              <Badge variant="outline" className="inline-flex mb-5 border-primary/25 text-primary bg-primary/6 px-3 py-1 text-xs font-medium">
                <Zap className="h-3 w-3 mr-1.5" /> {TOTAL_LIVE}+ free tools · no signup required
              </Badge>
            </motion.div>

            {/* Heading */}
            <motion.h1
              variants={fadeUp}
              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight leading-[1.1] mb-5"
            >
              Free online tools for<br />
              <span className="bg-gradient-to-r from-primary via-violet-400 to-primary bg-clip-text text-transparent bg-[length:200%_auto] animate-[shimmer_4s_linear_infinite]">
                SEO, creators &amp; developers
              </span>
            </motion.h1>

            {/* Subtext */}
            <motion.p
              variants={fadeUp}
              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
              className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed mb-8"
            >
              X account checker, AI bio generators, JSON formatter, Base64 encoder,
              text formatters — all free, all instant, all in one place.
            </motion.p>

            {/* CTAs */}
            <motion.div
              variants={fadeUp}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-8"
            >
              <Link href="/tools">
                <Button size="lg" className="w-full sm:w-auto text-sm font-semibold shadow-lg shadow-primary/20 px-8 hover:shadow-primary/30 hover:scale-[1.02] transition-all duration-200">
                  Browse All Tools <ArrowRight className="h-4 w-4 ml-2" />
                </Button>
              </Link>
              <a href="#categories">
                <Button variant="outline" size="lg" className="w-full sm:w-auto text-sm border-border/50 hover:bg-muted/40 hover:border-border/70 transition-all duration-200">
                  See All Categories
                </Button>
              </a>
            </motion.div>

            {/* Trust badges */}
            <motion.div
              variants={fadeUp}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-muted-foreground"
            >
              {[
                { icon: Shield, text: "No data stored" },
                { icon: CheckCircle2, text: "No login required" },
                { icon: Zap, text: "Instant results" },
                { icon: Users, text: "Free forever" },
              ].map(({ icon: Icon, text }) => (
                <span key={text} className="flex items-center gap-1.5">
                  <Icon className="h-3.5 w-3.5 text-success" /> {text}
                </span>
              ))}
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ── Stats bar ── */}
      <section className="border-y border-border/40 bg-card/20 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-5">
          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-60px" }}
            variants={stagger}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center"
          >
            {[
              { value: `${TOTAL_LIVE}+`, label: "Free tools" },
              { value: "5", label: "Tool categories" },
              { value: "0", label: "Signups required" },
              { value: "~2s", label: "Average result time" },
            ].map(({ value, label }) => (
              <motion.div
                key={label}
                variants={fadeUp}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                className="space-y-1"
              >
                <div className="text-2xl font-bold tracking-tight">{value}</div>
                <div className="text-xs text-muted-foreground">{label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Categories Overview ── */}
      <section id="categories" className="max-w-6xl mx-auto px-4 md:px-8 py-14 md:py-20">
        <motion.div
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-80px" }}
          variants={stagger}
          className="text-center mb-10"
        >
          <motion.h2 variants={fadeUp} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="text-2xl md:text-3xl font-bold tracking-tight mb-3">
            Tool Categories
          </motion.h2>
          <motion.p variants={fadeUp} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="text-muted-foreground max-w-xl mx-auto text-sm">
            Five categories and growing. Every tool is free — no paywall, no account.
          </motion.p>
        </motion.div>

        <motion.div
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-60px" }}
          variants={stagger}
          className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4"
        >
          {CATEGORY_ORDER.map((key) => {
            const cat = CATEGORIES[key];
            const Icon = cat.icon;
            const count = LIVE_TOOLS.filter((t) => t.category === key).length;
            const isNew = key === "seo";
            return (
              <motion.div
                key={key}
                variants={fadeUp}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
              >
                <Link
                  href={`/tools#${key}`}
                  onClick={() => trackEvent("category_click", { label: cat.label })}
                >
                  <div className="group relative rounded-xl border border-border/50 bg-card/40 p-5 hover:border-primary/30 hover:bg-card/70 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-primary/6 transition-all duration-300 cursor-pointer overflow-hidden">
                    <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                      style={{ background: "radial-gradient(ellipse 80% 60% at 50% 0%, hsl(237 72% 65% / 0.05), transparent 70%)" }}
                    />
                    <div className={`h-10 w-10 rounded-xl border flex items-center justify-center mb-3 transition-transform duration-300 group-hover:scale-105 ${cat.bg}`}>
                      <Icon className={`h-5 w-5 ${cat.color}`} />
                    </div>
                    <div className="flex items-center gap-2 mb-1.5">
                      <h3 className="text-sm font-semibold group-hover:text-primary transition-colors duration-200">{cat.label}</h3>
                      {isNew && (
                        <span className="text-[9px] font-semibold px-1.5 py-0.5 rounded-full bg-emerald-400/12 text-emerald-400 border border-emerald-400/25">
                          Coming Soon
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed mb-3">{cat.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-muted-foreground/50">{count} {count === 1 ? "tool" : "tools"}</span>
                      <ArrowRight className="h-3.5 w-3.5 text-muted-foreground/30 group-hover:text-primary group-hover:translate-x-1 transition-all duration-200" />
                    </div>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </motion.div>
      </section>

      {/* ── Popular Tools ── */}
      <section className="border-t border-border/40 bg-muted/8">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-14 md:py-20">
          <div className="flex items-center justify-between mb-8">
            <motion.div
              initial={{ opacity: 0, x: -12 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            >
              <h2 className="text-2xl font-bold tracking-tight mb-1">Popular Tools</h2>
              <p className="text-sm text-muted-foreground">Most-used tools across the platform.</p>
            </motion.div>
            <Link href="/tools">
              <Button variant="outline" size="sm" className="text-xs border-border/50 hidden sm:flex hover:border-border/70 transition-all duration-200">
                All Tools <ArrowRight className="h-3.5 w-3.5 ml-1.5" />
              </Button>
            </Link>
          </div>
          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-60px" }}
            variants={stagger}
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            {popularTools.map((tool) => (
              <motion.div
                key={tool.id}
                variants={fadeUp}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                onClick={() => trackEvent("popular_tool_click", { tool: tool.id })}
              >
                <ToolCard tool={tool} />
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Social Media Spotlight ── */}
      <section className="max-w-6xl mx-auto px-4 md:px-8 py-14 md:py-20">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <motion.div
            initial={{ opacity: 0, x: -16 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
          >
            <Badge variant="outline" className="border-blue-400/25 text-blue-300 bg-blue-400/6 text-xs mb-4">
              Social Media Tools
            </Badge>
            <h2 className="text-2xl md:text-3xl font-bold tracking-tight mb-4">
              Manage X accounts at scale
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6 text-sm">
              Bulk-check up to 100 X accounts in seconds, convert usernames to profile links, format @ lists, and generate AI-powered bios — all without logging in.
            </p>
            <ul className="space-y-3 mb-6">
              {[
                "Check 100 accounts in ~2 seconds",
                "Active, suspended, and deleted detection",
                "AI bio generation with Groq",
                "Bulk @ prefix add / remove",
              ].map((item) => (
                <li key={item} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                  <CheckCircle2 className="h-4 w-4 text-success shrink-0 mt-0.5" />
                  {item}
                </li>
              ))}
            </ul>
            <Link href="/tools?tab=checker">
              <Button size="sm" className="shadow-sm shadow-primary/15 hover:shadow-primary/25 hover:scale-[1.02] transition-all duration-200">
                Try Account Checker <ArrowRight className="h-3.5 w-3.5 ml-2" />
              </Button>
            </Link>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 16 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
            className="grid grid-cols-2 gap-3"
          >
            {socialTools.map((tool) => (
              <ToolCard key={tool.id} tool={tool} compact />
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── Developer Tools Spotlight ── */}
      <section className="border-t border-border/40 bg-muted/8">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-14 md:py-20">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <motion.div
              initial={{ opacity: 0, x: -16 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
              className="grid grid-cols-1 gap-3 order-2 md:order-1"
            >
              {devTools.map((tool) => (
                <ToolCard key={tool.id} tool={tool} />
              ))}
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 16 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
              className="order-1 md:order-2"
            >
              <Badge variant="outline" className="border-orange-400/25 text-orange-300 bg-orange-400/6 text-xs mb-4">
                Developer Tools
              </Badge>
              <h2 className="text-2xl md:text-3xl font-bold tracking-tight mb-4">
                Developer utilities that just work
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-6 text-sm">
                Format and validate JSON with real-time error highlighting. Encode and decode Base64 strings including emojis and Unicode. All processing happens in your browser — nothing is sent to a server.
              </p>
              <ul className="space-y-3 mb-6">
                {[
                  "Real-time JSON validation with line numbers",
                  "Format or minify with one click",
                  "Base64 with full Unicode support",
                  "JWT payload decoding built in",
                ].map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                    <CheckCircle2 className="h-4 w-4 text-success shrink-0 mt-0.5" />
                    {item}
                  </li>
                ))}
              </ul>
              <Link href="/tools/json-formatter">
                <Button variant="outline" size="sm" className="border-border/50 hover:border-border/70 hover:scale-[1.02] transition-all duration-200">
                  Try JSON Formatter <ArrowRight className="h-3.5 w-3.5 ml-2" />
                </Button>
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── Newly Added ── */}
      {newTools.length > 0 && (
        <section className="max-w-6xl mx-auto px-4 md:px-8 py-14 md:py-20">
          <div className="flex items-center justify-between mb-8">
            <motion.div
              initial={{ opacity: 0, x: -12 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
            >
              <h2 className="text-2xl font-bold tracking-tight mb-1">Recently Added</h2>
              <p className="text-sm text-muted-foreground">Fresh tools, just launched.</p>
            </motion.div>
          </div>
          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-60px" }}
            variants={stagger}
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            {newTools.map((tool) => (
              <motion.div
                key={tool.id}
                variants={fadeUp}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                onClick={() => trackEvent("new_tool_click", { tool: tool.id })}
              >
                <ToolCard tool={tool} />
              </motion.div>
            ))}
          </motion.div>
        </section>
      )}

      {/* ── Testimonials ── */}
      <section className="border-t border-border/40 bg-muted/8">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-14 md:py-20">
          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-60px" }}
            variants={stagger}
            className="text-center mb-10"
          >
            <motion.h2 variants={fadeUp} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="text-2xl md:text-3xl font-bold tracking-tight mb-3">
              Loved by creators &amp; developers
            </motion.h2>
            <motion.p variants={fadeUp} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              className="text-muted-foreground text-sm">
              What people are saying.
            </motion.p>
          </motion.div>
          <motion.div
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, margin: "-60px" }}
            variants={stagger}
            className="grid md:grid-cols-3 gap-5"
          >
            {TESTIMONIALS.map(({ quote, name, role, stars }) => (
              <motion.div
                key={name}
                variants={fadeUp}
                transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                className="rounded-xl border border-border/50 bg-card/40 p-6 space-y-4 hover:border-border/70 hover:bg-card/60 transition-all duration-300"
              >
                <StarRating count={stars} />
                <p className="text-sm text-muted-foreground leading-relaxed">"{quote}"</p>
                <div className="flex items-center gap-2.5">
                  <div className="h-8 w-8 rounded-full bg-primary/12 border border-primary/20 flex items-center justify-center">
                    <span className="text-xs font-bold text-primary">{name[0]}</span>
                  </div>
                  <div>
                    <div className="text-sm font-medium">{name}</div>
                    <div className="text-xs text-muted-foreground">{role}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ── FAQ ── */}
      <section className="max-w-3xl mx-auto px-4 md:px-8 py-14 md:py-20">
        <motion.div
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-60px" }}
          variants={stagger}
          className="text-center mb-10"
        >
          <motion.h2 variants={fadeUp} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="text-2xl md:text-3xl font-bold tracking-tight mb-3">
            Frequently Asked Questions
          </motion.h2>
          <motion.p variants={fadeUp} transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            className="text-muted-foreground text-sm">
            Everything you need to know.
          </motion.p>
        </motion.div>
        <Accordion type="single" collapsible className="space-y-2">
          {FAQS.map(({ q, a }, i) => (
            <AccordionItem
              key={i}
              value={`faq-${i}`}
              className="rounded-xl border border-border/50 bg-card/30 px-5 data-[state=open]:bg-card/60 transition-all duration-200"
            >
              <AccordionTrigger className="text-sm font-medium text-left hover:no-underline py-4 hover:text-primary transition-colors duration-200">{q}</AccordionTrigger>
              <AccordionContent className="text-sm text-muted-foreground pb-4 leading-relaxed">{a}</AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </section>

      {/* ── CTA ── */}
      <section className="max-w-6xl mx-auto px-4 md:px-8 pb-16 md:pb-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
          className="relative rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/8 via-primary/4 to-transparent p-8 md:p-12 text-center overflow-hidden"
        >
          {/* Background glow */}
          <div className="absolute inset-0 rounded-2xl pointer-events-none"
            style={{ background: "radial-gradient(ellipse 80% 70% at 50% 0%, hsl(237 72% 65% / 0.07), transparent 65%)" }}
          />
          <h2 className="text-2xl md:text-3xl font-bold tracking-tight mb-3 relative">Ready to get started?</h2>
          <p className="text-muted-foreground max-w-md mx-auto mb-6 text-sm md:text-base relative">
            {TOTAL_LIVE}+ free tools. No account, no signup, no payment. Ever.
          </p>
          <Link href="/tools">
            <Button size="lg" className="shadow-lg shadow-primary/20 px-8 hover:shadow-primary/35 hover:scale-[1.02] transition-all duration-200 relative">
              Browse All Tools <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>
        </motion.div>
      </section>
    </Layout>
  );
}
