import { Link } from "wouter";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import {
  Shield, Zap, Heart, Users, Code2, TrendingUp, Mail,
  Search, Sparkles, Link2, AtSign, FileJson, Lock,
  Globe, Pencil, Inbox, ArrowRight,
} from "lucide-react";
import { TOTAL_LIVE } from "@/lib/tools-registry";

const VALUES = [
  {
    icon: Zap,
    title: "Fast & Free",
    description: "Every tool is instant and completely free — no paywalls, no rate-limit warnings, no upsells. Always.",
  },
  {
    icon: Shield,
    title: "Privacy First",
    description: "We don't store inputs, results, or personal data. Requests are processed in real-time and immediately discarded.",
  },
  {
    icon: Heart,
    title: "Built for Everyone",
    description: "Designed for social media managers, developers, SEO professionals, marketers, and content creators.",
  },
];

const CATEGORIES = [
  {
    icon: Users,
    color: "text-blue-400",
    bg: "bg-blue-400/10 border-blue-400/20",
    name: "X / Social Media Tools",
    tools: ["Account Checker", "AI Bio Generator", "Profile Link Generator", "Formatter", "Bio Ideas", "Username Generator", "Tweet Formatter", "Character Counter"],
    desc: "Manage X accounts at scale — bulk-check status, generate bios, format usernames, and more.",
  },
  {
    icon: Sparkles,
    color: "text-violet-400",
    bg: "bg-violet-400/10 border-violet-400/20",
    name: "AI Writing Tools",
    tools: ["AI Bio Generator", "Funny Bios", "Professional Bios", "Aesthetic Bios", "Subject Line Generator"],
    desc: "AI-powered content for profiles, emails, and social copy — no prompt engineering needed.",
  },
  {
    icon: Code2,
    color: "text-orange-400",
    bg: "bg-orange-400/10 border-orange-400/20",
    name: "Developer Tools",
    tools: ["JSON Formatter", "Base64 Encoder", "Regex Tester", "JWT Decoder", "UUID Generator", "URL Encoder", "HTML Formatter", "CSS Minifier", "SQL Formatter"],
    desc: "Essential utilities that run entirely in your browser — no data ever leaves your device.",
  },
  {
    icon: TrendingUp,
    color: "text-pink-400",
    bg: "bg-pink-400/10 border-pink-400/20",
    name: "SEO Tools",
    tools: ["Meta Tag Generator", "URL Slug Generator", "Keyword Density", "Robots.txt Generator", "Sitemap Validator"],
    desc: "Build, audit, and optimize your SEO presence with free, no-login tools.",
  },
  {
    icon: Mail,
    color: "text-cyan-400",
    bg: "bg-cyan-400/10 border-cyan-400/20",
    name: "Email Tools",
    tools: ["Temp Mail", "Subject Line Generator", "Email Signature Generator", "Email Validator", "Plain Text Formatter"],
    desc: "Write better emails, validate addresses, and get a disposable inbox in seconds.",
  },
];

const TECH = [
  "React 19", "TypeScript", "Vite 7", "Node.js", "Express 5",
  "TanStack Query", "shadcn/ui", "Tailwind CSS v4", "Framer Motion",
  "Zod", "Wouter", "Groq API", "Guerrilla Mail API",
];

export default function About() {
  return (
    <Layout>
      <div className="max-w-4xl mx-auto px-4 md:px-8 py-12 md:py-16">

        {/* Header */}
        <div className="mb-12 space-y-4">
          <div className="inline-flex items-center gap-2 text-xs font-medium text-primary bg-primary/8 border border-primary/20 rounded-full px-3 py-1">
            About X Toolkit
          </div>
          <h1 className="text-3xl md:text-4xl font-bold tracking-tight">
            Free tools for creators, developers &amp; SEO pros
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl">
            X Toolkit is a free collection of {TOTAL_LIVE}+ productivity tools spanning social media management,
            developer utilities, SEO, and email — built because powerful online tools shouldn't require
            a subscription, a login, or a privacy trade-off.
          </p>
        </div>

        {/* Mission */}
        <section className="mb-12 rounded-2xl border border-border/60 bg-card/50 p-6 md:p-8">
          <h2 className="text-xl font-semibold mb-3">Our Mission</h2>
          <p className="text-muted-foreground leading-relaxed">
            Give everyone access to fast, reliable tools — for free. Whether you're managing X accounts at scale,
            debugging a JWT token, writing a bio for a new profile, generating SEO meta tags, or spinning up a
            throwaway email inbox — X Toolkit handles it instantly, in your browser, without asking for anything in return.
          </p>
        </section>

        {/* Values */}
        <section className="mb-12">
          <h2 className="text-xl font-semibold mb-6">What we stand for</h2>
          <div className="grid md:grid-cols-3 gap-5">
            {VALUES.map(({ icon: Icon, title, description }) => (
              <div key={title} className="rounded-xl border border-border/60 bg-card/50 p-5 space-y-3">
                <div className="h-9 w-9 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
                  <Icon className="h-4.5 w-4.5 text-primary" style={{ height: "1.125rem", width: "1.125rem" }} />
                </div>
                <h3 className="font-semibold text-sm">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Categories */}
        <section className="mb-12">
          <h2 className="text-xl font-semibold mb-2">The tool categories</h2>
          <p className="text-sm text-muted-foreground mb-6">{TOTAL_LIVE}+ tools across 5 categories and growing.</p>
          <div className="space-y-3">
            {CATEGORIES.map(({ icon: Icon, color, bg, name, tools, desc }) => (
              <div key={name} className="rounded-xl border border-border/60 bg-card/40 px-5 py-4">
                <div className="flex items-start gap-4">
                  <div className={`h-9 w-9 rounded-lg border flex items-center justify-center shrink-0 mt-0.5 ${bg}`}>
                    <Icon className={`h-4 w-4 ${color}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm mb-0.5">{name}</div>
                    <div className="text-xs text-muted-foreground mb-2">{desc}</div>
                    <div className="flex flex-wrap gap-1.5">
                      {tools.map((t) => (
                        <span key={t} className="text-[10px] font-medium bg-muted/50 border border-border/50 rounded-full px-2 py-0.5 text-muted-foreground">
                          {t}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Privacy commitment */}
        <section className="mb-12 rounded-2xl border border-success/20 bg-success/5 p-6 md:p-8">
          <div className="flex items-start gap-3">
            <Shield className="h-5 w-5 text-success shrink-0 mt-0.5" />
            <div>
              <h2 className="text-base font-semibold mb-2 text-success">Privacy commitment</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                We don't collect, store, or sell any personal data. Inputs you enter — usernames, bios, code,
                emails — are processed in real-time or entirely in your browser, and never written to a database.
                Developer tools (JSON Formatter, Base64, Regex Tester, etc.) run 100% client-side.
                Read our full{" "}
                <Link href="/privacy">
                  <span className="text-primary hover:underline cursor-pointer">Privacy Policy</span>
                </Link>{" "}
                for details.
              </p>
            </div>
          </div>
        </section>

        {/* Technology */}
        <section className="mb-12">
          <h2 className="text-xl font-semibold mb-4">How it's built</h2>
          <p className="text-muted-foreground text-sm leading-relaxed mb-4">
            X Toolkit is a TypeScript monorepo with a React + Vite frontend and a lightweight Node.js / Express
            API backend. The X Account Checker uses X's public internal API — no user auth required. Developer tools
            process data entirely in the browser. The AI Bio Generator uses Groq's fast LLM API with your own key
            so we never see it. Temp Mail uses the Guerrilla Mail API to create disposable inboxes server-side.
          </p>
          <div className="flex flex-wrap gap-2">
            {TECH.map((tech) => (
              <span key={tech} className="text-xs font-mono bg-muted/50 border border-border/60 rounded-full px-3 py-1 text-muted-foreground">
                {tech}
              </span>
            ))}
          </div>
        </section>

        {/* CTA */}
        <div className="rounded-2xl border border-primary/20 bg-primary/5 p-6 md:p-8 text-center">
          <h2 className="text-xl font-semibold mb-2">Try X Toolkit now</h2>
          <p className="text-muted-foreground text-sm mb-5">
            {TOTAL_LIVE}+ tools. No account, no signup, no payment. Ever.
          </p>
          <Link href="/tools">
            <Button className="shadow-sm shadow-primary/20 hover:shadow-primary/30 hover:scale-[1.02] transition-all duration-200">
              Browse All Tools <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>
        </div>

      </div>
    </Layout>
  );
}
