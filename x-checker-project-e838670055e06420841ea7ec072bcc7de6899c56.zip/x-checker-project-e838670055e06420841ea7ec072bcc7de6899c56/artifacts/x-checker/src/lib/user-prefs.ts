const RECENT_KEY = "xt_recent_tools";
const FAVORITES_KEY = "xt_favorite_tools";
const MAX_RECENT = 10;

export interface ToolRef {
  id: string;
  label: string;
  href: string;
  category: string;
}

function readJson<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJson<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // localStorage may be unavailable (private browsing, storage quota)
  }
}

// ── Recent tools ────────────────────────────────────────────────
export function getRecentTools(): ToolRef[] {
  return readJson<ToolRef[]>(RECENT_KEY, []);
}

export function addRecentTool(tool: ToolRef): void {
  const recent = getRecentTools().filter((t) => t.id !== tool.id);
  recent.unshift(tool);
  writeJson(RECENT_KEY, recent.slice(0, MAX_RECENT));
}

// ── Favorite tools ──────────────────────────────────────────────
export function getFavoriteTools(): ToolRef[] {
  return readJson<ToolRef[]>(FAVORITES_KEY, []);
}

export function isFavorite(toolId: string): boolean {
  return getFavoriteTools().some((t) => t.id === toolId);
}

export function toggleFavorite(tool: ToolRef): boolean {
  const favs = getFavoriteTools();
  const exists = favs.some((t) => t.id === tool.id);
  if (exists) {
    writeJson(FAVORITES_KEY, favs.filter((t) => t.id !== tool.id));
    return false;
  } else {
    writeJson(FAVORITES_KEY, [tool, ...favs]);
    return true;
  }
}

export function clearFavorites(): void {
  writeJson(FAVORITES_KEY, []);
}

export function clearRecent(): void {
  writeJson(RECENT_KEY, []);
}
