import { type LucideIcon, ArrowRight, Wrench, BookOpen, Lightbulb, Info, AlertTriangle } from "lucide-react";
import { Link } from "wouter";
import { Layout } from "./Layout";
import { SeoHead } from "@/components/SeoHead";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { EmailCapture } from "@/components/monetization/EmailCapture";
import { AffiliateSection } from "@/components/monetization/AffiliateSection";
import { StickyUpgradeCTA } from "@/components/monetization/StickyUpgradeCTA";

interface RelatedTool {
  title: string;
  href: string;
  description: string;
  icon?: LucideIcon;
}

interface RelatedArticle {
  title: string;
  href: string;
  readingTime?: number;
}

interface Faq {
  q: string;
  a: string;
}

export interface EducationalSection {
  heading: string;
  body?: string;
  items?: string[];
  code?: string;
  callout?: { type: "tip" | "info" | "warning"; text: string };
}

interface MiniToolLayoutProps {
  seoTitle: string;
  seoDescription: string;
  icon: LucideIcon;
  badge?: string;
  title: string;
  description: string;
  faqs: Faq[];
  relatedTools: RelatedTool[];
  children: React.ReactNode;
  affiliateCategory?: "scheduling" | "design" | "monetize" | "growth" | "analytics" | "all";
  educationalSections?: EducationalSection[];
  relatedArticles?: RelatedArticle[];
}

const CALLOUT_STYLES = {
  tip:     { icon: Lightbulb,     cls: "bg-emerald-500/8 border-emerald-500/20 text-emerald-400" },
  info:    { icon: Info,          cls: "bg-blue-500/8 border-blue-500/20 text-blue-400" },
  warning: { icon: AlertTriangle, cls: "bg-amber-500/8 border-amber-500/20 text-amber-400" },
};

function EducationalBlock({ sections }: { sections: EducationalSection[] }) {
  return (
    <section className="space-y-6">
      <div className="flex items-center gap-2 pb-1 border-b border-border/40">
        <BookOpen className="h-4 w-4 text-primary" />
        <h2 className="text-base font-semibold">Learn More</h2>
      </div>
      {sections.map((s, i) => (
        <div key={i} className="space-y-3">
          <h3 className="text-sm font-semibold text-foreground/90">{s.heading}</h3>
          {s.body && (
            <p className="text-sm text-muted-foreground leading-relaxed">{s.body}</p>
          )}
          {s.items && s.items.length > 0 && (
            <ul className="space-y-1.5">
              {s.items.map((item, j) => (
                <li key={j} className="flex items-start gap-2.5 text-sm text-muted-foreground">
                  <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-primary/50 shrink-0" />
                  <span className="leading-relaxed">{item}</span>
                </li>
              ))}
            </ul>
          )}
          {s.code && (
            <pre className="rounded-xl border border-border/60 bg-muted/30 px-4 py-3 text-xs font-mono text-foreground/80 overflow-x-auto whitespace-pre-wrap leading-relaxed">
              <code>{s.code}</code>
            </pre>
          )}
          {s.callout && (() => {
            const style = CALLOUT_STYLES[s.callout.type];
            const Icon = style.icon;
            return (
              <div className={`flex gap-3 rounded-xl border px-4 py-3.5 ${style.cls}`}>
                <Icon className="h-4 w-4 shrink-0 mt-0.5" />
                <p className="text-sm leading-relaxed">{s.callout.text}</p>
              </div>
            );
          })()}
        </div>
      ))}
    </section>
  );
}

const SITE_URL = "https://xtoolkit.live";

function buildToolSchemas(seoTitle: string, seoDescription: string, path: string) {
  const toolName = seoTitle.split("—")[0].split("|")[0].trim();
  const url = `${SITE_URL}${path}`;
  const webApp = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: toolName,
    applicationCategory: "WebApplication",
    operatingSystem: "Web",
    url,
    description: seoDescription,
    offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
    isAccessibleForFree: true,
    browserRequirements: "Requires JavaScript. Works in all modern browsers.",
    provider: { "@type": "Organization", name: "X Toolkit", url: SITE_URL },
  };
  const breadcrumb = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Home", item: `${SITE_URL}/` },
      { "@type": "ListItem", position: 2, name: "Tools", item: `${SITE_URL}/tools` },
      { "@type": "ListItem", position: 3, name: toolName, item: url },
    ],
  };
  return [webApp, breadcrumb];
}

export function MiniToolLayout({
  seoTitle,
  seoDescription,
  icon: Icon,
  badge = "Free Tool",
  title,
  description,
  faqs,
  relatedTools,
  children,
  affiliateCategory = "all",
  educationalSections,
  relatedArticles,
}: MiniToolLayoutProps) {
  const path = typeof window !== "undefined" ? window.location.pathname : "";
  const toolSchemas = buildToolSchemas(seoTitle, seoDescription, path);

  return (
    <Layout>
      <SeoHead title={seoTitle} description={seoDescription} path={path} faqs={faqs} extraSchemas={toolSchemas} />

      <div className="max-w-4xl mx-auto px-4 md:px-8 py-10 md:py-14 space-y-12">

        {/* Page header */}
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Icon className="h-5 w-5 text-primary" />
            </div>
            <Badge variant="outline" className="border-primary/30 text-primary bg-primary/8 text-xs">
              {badge}
            </Badge>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tight">{title}</h1>
          <p className="text-muted-foreground leading-relaxed max-w-2xl">{description}</p>
        </div>

        {/* Tool content */}
        <div>{children}</div>

        {/* Educational sections — SEO depth content */}
        {educationalSections && educationalSections.length > 0 && (
          <EducationalBlock sections={educationalSections} />
        )}

        {/* Email capture — pro waitlist */}
        <EmailCapture
          variant="banner"
          headline="Pro features are coming — join the waitlist"
          subline="Bulk checking, CSV export, AI bios, no ads. Get 40% off launch pricing."
          source={seoTitle.split("—")[0].trim().toLowerCase().replace(/\s+/g, "_")}
        />

        {/* FAQ */}
        <section>
          <h2 className="text-xl font-semibold mb-5">Frequently Asked Questions</h2>
          <Accordion type="single" collapsible className="space-y-2">
            {faqs.map(({ q, a }, i) => (
              <AccordionItem
                key={i}
                value={`faq-${i}`}
                className="rounded-xl border border-border/60 bg-card/40 px-5 data-[state=open]:bg-card/70 transition-colors"
              >
                <AccordionTrigger className="text-sm font-medium text-left hover:no-underline py-4 hover:text-primary transition-colors">
                  {q}
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground pb-4 leading-relaxed">
                  {a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>

        {/* Affiliate section */}
        <AffiliateSection category={affiliateCategory} limit={4} />

        {/* Related tools */}
        {relatedTools.length > 0 && (
          <section>
            <h2 className="text-xl font-semibold mb-5">Related Tools</h2>
            <div className="grid sm:grid-cols-2 gap-3">
              {relatedTools.map(({ title: t, href, description: d, icon: TIcon }) => (
                <Link key={href} href={href}>
                  <div className="flex items-start gap-3 rounded-xl border border-border/60 bg-card/40 p-4 hover:border-primary/30 hover:bg-card transition-all cursor-pointer group">
                    <div className="h-8 w-8 rounded-lg bg-muted/60 border border-border/50 flex items-center justify-center shrink-0 mt-0.5">
                      {TIcon ? <TIcon className="h-4 w-4 text-muted-foreground" /> : <Wrench className="h-4 w-4 text-muted-foreground" />}
                    </div>
                    <div>
                      <div className="text-sm font-medium group-hover:text-primary transition-colors flex items-center gap-1">
                        {t} <ArrowRight className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">{d}</div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* Related articles — tool-to-blog linking */}
        {relatedArticles && relatedArticles.length > 0 && (
          <section>
            <h2 className="text-xl font-semibold mb-5">Related Guides</h2>
            <div className="space-y-2">
              {relatedArticles.map(({ title: t, href, readingTime }) => (
                <Link key={href} href={href}>
                  <div className="flex items-center gap-3 rounded-xl border border-border/60 bg-card/40 px-4 py-3 hover:border-primary/30 hover:bg-card transition-all cursor-pointer group">
                    <div className="h-7 w-7 rounded-lg bg-primary/8 border border-primary/15 flex items-center justify-center shrink-0">
                      <BookOpen className="h-3.5 w-3.5 text-primary" />
                    </div>
                    <span className="text-sm font-medium group-hover:text-primary transition-colors flex-1">{t}</span>
                    {readingTime && (
                      <span className="text-xs text-muted-foreground shrink-0">{readingTime} min read</span>
                    )}
                    <ArrowRight className="h-3.5 w-3.5 text-muted-foreground/30 group-hover:text-primary transition-all group-hover:translate-x-0.5" />
                  </div>
                </Link>
              ))}
            </div>
          </section>
        )}

        {/* CTA */}
        <div className="rounded-2xl border border-primary/20 bg-primary/5 p-6 md:p-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <h3 className="font-semibold mb-1">Explore all tools</h3>
            <p className="text-sm text-muted-foreground">35+ free tools — X tools, AI writing, developer utilities, SEO, email. No signup required.</p>
          </div>
          <Link href="/tools">
            <Button className="shrink-0 shadow-sm shadow-primary/20 whitespace-nowrap hover:shadow-primary/30 hover:scale-[1.02] transition-all duration-200">
              Browse All Tools <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>
        </div>

      </div>

      {/* Sticky upgrade bar — appears after 20s */}
      <StickyUpgradeCTA delay={20000} />
    </Layout>
  );
}
