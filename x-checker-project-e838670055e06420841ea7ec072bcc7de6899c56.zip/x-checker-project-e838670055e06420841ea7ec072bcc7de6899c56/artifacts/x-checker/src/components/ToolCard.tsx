import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { CATEGORIES, type Tool } from "@/lib/tools-registry";

interface ToolCardProps {
  tool: Tool;
  compact?: boolean;
}

const BADGE_STYLES: Record<string, string> = {
  Popular: "bg-amber-400/12 text-amber-300 border-amber-400/25",
  New: "bg-emerald-400/12 text-emerald-300 border-emerald-400/25",
  AI: "bg-violet-400/12 text-violet-300 border-violet-400/25",
};

export function ToolCard({ tool, compact = false }: ToolCardProps) {
  const cat = CATEGORIES[tool.category];
  const { icon: Icon } = tool;

  const card = (
    <div
      className={`group relative flex flex-col rounded-xl border transition-all duration-300 ease-out ${
        tool.isComingSoon
          ? "opacity-50 cursor-default border-border/40 bg-card/30"
          : "border-border/50 bg-card/40 hover:border-primary/30 hover:bg-card/70 hover:-translate-y-0.5 hover:shadow-lg hover:shadow-primary/6 cursor-pointer"
      } ${compact ? "p-4" : "p-5"}`}
    >
      {/* Subtle glow on hover — only for active tools */}
      {!tool.isComingSoon && (
        <div className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
          style={{ background: "radial-gradient(ellipse 80% 60% at 50% 0%, hsl(237 72% 65% / 0.05), transparent 70%)" }}
        />
      )}

      {/* Top row: icon + badges */}
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className={`h-9 w-9 rounded-lg border flex items-center justify-center shrink-0 transition-all duration-300 ${cat.bg} group-hover:scale-105 group-hover:brightness-110`}>
          <Icon className={`h-4.5 w-4.5 ${cat.color}`} style={{ height: "1.125rem", width: "1.125rem" }} />
        </div>
        <div className="flex items-center gap-1.5 flex-wrap justify-end">
          {tool.badge && !tool.isComingSoon && (
            <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-full border ${BADGE_STYLES[tool.badge]}`}>
              {tool.badge}
            </span>
          )}
          {tool.isComingSoon && (
            <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-full border border-border/40 text-muted-foreground/50 bg-muted/20">
              Soon
            </span>
          )}
        </div>
      </div>

      {/* Title */}
      <h3 className={`font-semibold leading-snug mb-1.5 transition-colors duration-200 group-hover:text-primary ${compact ? "text-sm" : "text-sm"}`}>
        {tool.label}
      </h3>

      {/* Description */}
      <p className="text-xs text-muted-foreground leading-relaxed flex-1">
        {tool.description}
      </p>

      {/* Category tag + arrow */}
      {!compact && (
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-border/30">
          <span className={`text-[10px] font-medium ${cat.color} opacity-60`}>
            {cat.shortLabel}
          </span>
          {!tool.isComingSoon && (
            <ArrowRight className="h-3.5 w-3.5 text-muted-foreground/30 group-hover:text-primary group-hover:translate-x-1 transition-all duration-200" />
          )}
        </div>
      )}
    </div>
  );

  if (tool.isComingSoon) return card;
  return <Link href={tool.href}>{card}</Link>;
}
