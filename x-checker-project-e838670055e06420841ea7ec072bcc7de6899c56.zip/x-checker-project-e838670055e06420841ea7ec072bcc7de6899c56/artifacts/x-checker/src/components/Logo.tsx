export function LogoIcon({ size = 28 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 180 180"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <rect width="180" height="180" rx="40" fill="url(#logo-grad)" />
      <defs>
        <linearGradient id="logo-grad" x1="0" y1="0" x2="180" y2="180" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#6366f1" />
          <stop offset="100%" stopColor="#8b5cf6" />
        </linearGradient>
      </defs>
      <line x1="54" y1="54" x2="126" y2="126" stroke="white" strokeWidth="18" strokeLinecap="round" />
      <line x1="126" y1="54" x2="54" y2="126" stroke="white" strokeWidth="18" strokeLinecap="round" />
      <circle cx="137" cy="137" r="10" fill="white" fillOpacity="0.35" />
    </svg>
  );
}
