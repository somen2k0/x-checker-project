import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Star, X, ArrowRight } from "lucide-react";
import { getFavoriteTools, clearFavorites, type ToolRef } from "@/lib/user-prefs";

export function FavoriteTools() {
  const [tools, setTools] = useState<ToolRef[]>([]);

  useEffect(() => {
    setTools(getFavoriteTools());
  }, []);

  if (tools.length === 0) return null;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Star className="h-4 w-4 text-warning fill-warning" />
          <h3 className="text-sm font-semibold">Favorites</h3>
        </div>
        <button
          onClick={() => { clearFavorites(); setTools([]); }}
          className="text-[10px] text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
        >
          <X className="h-3 w-3" /> Clear
        </button>
      </div>
      <div className="flex flex-wrap gap-2">
        {tools.map((tool) => (
          <Link key={tool.id} href={tool.href}>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-warning/20 bg-warning/5 hover:border-warning/40 hover:bg-warning/10 transition-all cursor-pointer group text-xs">
              <Star className="h-3 w-3 text-warning/60 fill-warning/30" />
              <span className="text-foreground/80 group-hover:text-warning transition-colors">{tool.label}</span>
              <ArrowRight className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity text-warning" />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
