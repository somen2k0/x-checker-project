import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Clock, X, ArrowRight } from "lucide-react";
import { getRecentTools, clearRecent, type ToolRef } from "@/lib/user-prefs";

export function RecentTools() {
  const [tools, setTools] = useState<ToolRef[]>([]);

  useEffect(() => {
    setTools(getRecentTools());
  }, []);

  if (tools.length === 0) return null;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="h-4 w-4 text-muted-foreground" />
          <h3 className="text-sm font-semibold">Recently Used</h3>
        </div>
        <button
          onClick={() => { clearRecent(); setTools([]); }}
          className="text-[10px] text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1"
        >
          <X className="h-3 w-3" /> Clear
        </button>
      </div>
      <div className="flex flex-wrap gap-2">
        {tools.slice(0, 6).map((tool) => (
          <Link key={tool.id} href={tool.href}>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border/60 bg-card/40 hover:border-primary/30 hover:bg-card transition-all cursor-pointer group text-xs">
              <span className="text-foreground/80 group-hover:text-primary transition-colors">{tool.label}</span>
              <ArrowRight className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity text-primary" />
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
