import { lazy, Suspense } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { CookieBanner } from "@/components/CookieBanner";
import { MobileNav } from "@/components/layout/MobileNav";
import { usePageTracking } from "@/hooks/use-track";

// ── Page-level code splitting ─────────────────────────────────────────────────
const NotFound             = lazy(() => import("@/pages/not-found"));
const Home                 = lazy(() => import("@/pages/home"));
const Tools                = lazy(() => import("@/pages/tools"));
const About                = lazy(() => import("@/pages/about"));
const Privacy              = lazy(() => import("@/pages/privacy"));
const Terms                = lazy(() => import("@/pages/terms"));
const Pricing              = lazy(() => import("@/pages/pricing"));

// Social Media Tools
const BioIdeas             = lazy(() => import("@/pages/tools/bio-ideas"));
const FunnyBios            = lazy(() => import("@/pages/tools/funny-bios"));
const ProfessionalBios     = lazy(() => import("@/pages/tools/professional-bios"));
const AestheticBios        = lazy(() => import("@/pages/tools/aesthetic-bios"));
const UsernameGenerator    = lazy(() => import("@/pages/tools/username-generator"));
const NameIdeas            = lazy(() => import("@/pages/tools/name-ideas"));
const HashtagFormatter     = lazy(() => import("@/pages/tools/hashtag-formatter"));
const TweetFormatter       = lazy(() => import("@/pages/tools/tweet-formatter"));
const FontPreview          = lazy(() => import("@/pages/tools/font-preview"));
const CharacterCounter     = lazy(() => import("@/pages/tools/character-counter"));

// Developer Tools
const JsonFormatter        = lazy(() => import("@/pages/tools/json-formatter"));
const Base64Tool           = lazy(() => import("@/pages/tools/base64"));
const RegexTester          = lazy(() => import("@/pages/tools/regex-tester"));
const JwtDecoder           = lazy(() => import("@/pages/tools/jwt-decoder"));
const UuidGenerator        = lazy(() => import("@/pages/tools/uuid-generator"));
const UrlEncoder           = lazy(() => import("@/pages/tools/url-encoder"));
const HtmlFormatter        = lazy(() => import("@/pages/tools/html-formatter"));
const CssMinifier          = lazy(() => import("@/pages/tools/css-minifier"));
const SqlFormatter         = lazy(() => import("@/pages/tools/sql-formatter"));

// SEO Tools
const MetaTagGenerator     = lazy(() => import("@/pages/tools/meta-tag-generator"));
const UrlSlugGenerator     = lazy(() => import("@/pages/tools/url-slug-generator"));
const KeywordDensity       = lazy(() => import("@/pages/tools/keyword-density"));
const RobotsTxtGenerator   = lazy(() => import("@/pages/tools/robots-txt-generator"));
const SitemapValidator     = lazy(() => import("@/pages/tools/sitemap-validator"));

// Email Tools
const SubjectLineGenerator    = lazy(() => import("@/pages/tools/subject-line-generator"));
const EmailUsernameGenerator  = lazy(() => import("@/pages/tools/email-username-generator"));
const PlainTextFormatter      = lazy(() => import("@/pages/tools/plain-text-formatter"));
const EmailCharacterCounter   = lazy(() => import("@/pages/tools/email-character-counter"));
const EmailSignatureGenerator = lazy(() => import("@/pages/tools/email-signature-generator"));
const EmailValidator          = lazy(() => import("@/pages/tools/email-validator"));
const TempMail                = lazy(() => import("@/pages/tools/temp-mail"));

// Category landing pages
const AiWritingTools    = lazy(() => import("@/pages/categories/ai-writing-tools"));
const SocialMediaTools  = lazy(() => import("@/pages/categories/social-media-tools"));
const TextFormatTools   = lazy(() => import("@/pages/categories/text-format-tools"));
const DeveloperTools    = lazy(() => import("@/pages/categories/developer-tools"));
const SeoTools          = lazy(() => import("@/pages/categories/seo-tools"));
const EmailTools        = lazy(() => import("@/pages/categories/email-tools"));

// Blog
const BlogIndex   = lazy(() => import("@/pages/blog/index"));
const BlogArticle = lazy(() => import("@/pages/blog/article"));

// Landing pages
const TempMailLanding = lazy(() => import("@/pages/temp-mail-landing"));

const queryClient = new QueryClient();

function BlogArticleRoute() {
  const slug = window.location.pathname.replace("/blog/", "");
  return <BlogArticle slug={slug} />;
}

function PageFallback() {
  return (
    <div className="flex-1 flex items-center justify-center min-h-[60vh]">
      <div className="h-8 w-8 rounded-full border-2 border-primary/30 border-t-primary animate-spin" />
    </div>
  );
}

function TrackedRouter() {
  usePageTracking();
  return (
    <Suspense fallback={<PageFallback />}>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/tools" component={Tools} />
        <Route path="/about" component={About} />
        <Route path="/privacy" component={Privacy} />
        <Route path="/terms" component={Terms} />
        <Route path="/pricing" component={Pricing} />

        {/* Social Media Tools */}
        <Route path="/tools/bio-ideas" component={BioIdeas} />
        <Route path="/tools/funny-bios" component={FunnyBios} />
        <Route path="/tools/professional-bios" component={ProfessionalBios} />
        <Route path="/tools/aesthetic-bios" component={AestheticBios} />
        <Route path="/tools/username-generator" component={UsernameGenerator} />
        <Route path="/tools/name-ideas" component={NameIdeas} />
        <Route path="/tools/hashtag-formatter" component={HashtagFormatter} />
        <Route path="/tools/tweet-formatter" component={TweetFormatter} />
        <Route path="/tools/font-preview" component={FontPreview} />
        <Route path="/tools/character-counter" component={CharacterCounter} />

        {/* Developer Tools */}
        <Route path="/tools/json-formatter" component={JsonFormatter} />
        <Route path="/tools/base64" component={Base64Tool} />
        <Route path="/tools/regex-tester" component={RegexTester} />
        <Route path="/tools/jwt-decoder" component={JwtDecoder} />
        <Route path="/tools/uuid-generator" component={UuidGenerator} />
        <Route path="/tools/url-encoder" component={UrlEncoder} />
        <Route path="/tools/html-formatter" component={HtmlFormatter} />
        <Route path="/tools/css-minifier" component={CssMinifier} />
        <Route path="/tools/sql-formatter" component={SqlFormatter} />

        {/* SEO Tools */}
        <Route path="/tools/meta-tag-generator" component={MetaTagGenerator} />
        <Route path="/tools/url-slug-generator" component={UrlSlugGenerator} />
        <Route path="/tools/keyword-density" component={KeywordDensity} />
        <Route path="/tools/robots-txt-generator" component={RobotsTxtGenerator} />
        <Route path="/tools/sitemap-validator" component={SitemapValidator} />

        {/* Email Tools */}
        <Route path="/tools/subject-line-generator" component={SubjectLineGenerator} />
        <Route path="/tools/email-username-generator" component={EmailUsernameGenerator} />
        <Route path="/tools/plain-text-formatter" component={PlainTextFormatter} />
        <Route path="/tools/email-character-counter" component={EmailCharacterCounter} />
        <Route path="/tools/email-signature-generator" component={EmailSignatureGenerator} />
        <Route path="/tools/email-validator" component={EmailValidator} />
        <Route path="/tools/temp-mail" component={TempMail} />

        {/* Category landing pages */}
        <Route path="/ai-writing-tools" component={AiWritingTools} />
        <Route path="/social-media-tools" component={SocialMediaTools} />
        <Route path="/text-format-tools" component={TextFormatTools} />
        <Route path="/developer-tools" component={DeveloperTools} />
        <Route path="/seo-tools" component={SeoTools} />
        <Route path="/email-tools" component={EmailTools} />

        {/* Blog */}
        <Route path="/blog" component={BlogIndex} />
        <Route path="/blog/:slug" component={BlogArticleRoute} />

        {/* Landing pages */}
        <Route path="/temp-mail" component={TempMailLanding} />

        <Route component={NotFound} />
      </Switch>
    </Suspense>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <TrackedRouter />
          <CookieBanner />
          <MobileNav />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
