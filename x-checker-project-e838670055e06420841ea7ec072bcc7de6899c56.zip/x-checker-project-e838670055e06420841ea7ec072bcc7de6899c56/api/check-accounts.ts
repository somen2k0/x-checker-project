import type { VercelRequest, VercelResponse } from "@vercel/node";

// ─── Constants ────────────────────────────────────────────────────────────────
const UA =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

const BEARER =
  process.env.TWITTER_BEARER_TOKEN ??
  "AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA";

const GRAPHQL_FEATURES = JSON.stringify({
  hidden_profile_subscriptions_enabled: true,
  responsive_web_graphql_exclude_directive_enabled: true,
  verified_phone_label_enabled: false,
  creator_subscriptions_tweet_preview_api_enabled: true,
  responsive_web_graphql_timeline_navigation_enabled: true,
  responsive_web_graphql_skip_user_profile_image_extensions_enabled: false,
});

// ─── Guest token cache (persists across warm invocations) ────────────────────
let cachedGuestToken: string | null = null;
let cachedGuestTokenAt = 0;
const GUEST_TOKEN_TTL_MS = 10 * 60 * 1000;

// ─── Types ────────────────────────────────────────────────────────────────────
interface AccountCheckResult {
  username: string;
  status: "active" | "suspended" | "not_found" | "unknown";
  displayName: string | null;
  profileImageUrl: string | null;
  followerCount: number | null;
  followingCount: number | null;
  isVerified: boolean | null;
  createdAt: string | null;
  error: string | null;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
async function getGuestToken(): Promise<string> {
  const now = Date.now();
  if (cachedGuestToken && now - cachedGuestTokenAt < GUEST_TOKEN_TTL_MS) {
    return cachedGuestToken;
  }

  const res = await fetch("https://api.twitter.com/1.1/guest/activate.json", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${BEARER}`,
      "User-Agent": UA,
    },
    signal: AbortSignal.timeout(8000),
  });

  if (!res.ok) {
    throw new Error(`Failed to activate guest token: HTTP ${res.status}`);
  }

  const data = (await res.json()) as { guest_token?: string };
  if (!data.guest_token) throw new Error("No guest token in response");

  cachedGuestToken = data.guest_token;
  cachedGuestTokenAt = now;
  return cachedGuestToken;
}

async function checkXAccount(
  username: string,
  guestToken: string
): Promise<AccountCheckResult> {
  const base: AccountCheckResult = {
    username,
    status: "unknown",
    displayName: null,
    profileImageUrl: null,
    followerCount: null,
    followingCount: null,
    isVerified: null,
    createdAt: null,
    error: null,
  };

  try {
    const variables = encodeURIComponent(
      JSON.stringify({ screen_name: username, withSafetyModeUserFields: true })
    );
    const features = encodeURIComponent(GRAPHQL_FEATURES);
    const url = `https://twitter.com/i/api/graphql/G3KGOASz96M-Qu0nwmGXNg/UserByScreenName?variables=${variables}&features=${features}`;

    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${BEARER}`,
        "x-guest-token": guestToken,
        "User-Agent": UA,
        "x-twitter-active-user": "yes",
        "x-twitter-client-language": "en",
      },
      signal: AbortSignal.timeout(10000),
    });

    if (!res.ok) {
      if (res.status === 429) {
        cachedGuestToken = null;
        return { ...base, status: "unknown", error: "Rate limited — try again shortly" };
      }
      return { ...base, status: "unknown", error: `API HTTP ${res.status}` };
    }

    const body = (await res.json()) as {
      data?: {
        user?: {
          result?: {
            __typename?: string;
            reason?: string;
            is_blue_verified?: boolean;
            legacy?: {
              name?: string;
              profile_image_url_https?: string;
              followers_count?: number;
              friends_count?: number;
              verified?: boolean;
              created_at?: string;
              suspended?: boolean;
              withheld_in_countries?: string[];
            };
          };
        };
      };
      errors?: Array<{ message: string; code?: number }>;
    };

    const result = body?.data?.user?.result;
    const errors = body?.errors;

    if (result?.__typename === "UserUnavailable") {
      return { ...base, status: "suspended" };
    }

    if (result?.__typename === "User") {
      const legacy = result.legacy;

      // X sometimes returns __typename "User" for suspended accounts but
      // sets legacy.suspended = true or result.reason = "Suspended"
      const isSuspended =
        legacy?.suspended === true ||
        (typeof result.reason === "string" &&
          result.reason.toLowerCase().includes("suspend"));
      if (isSuspended) {
        return { ...base, status: "suspended" };
      }

      const createdAt = legacy?.created_at
        ? new Date(legacy.created_at).toISOString()
        : null;
      return {
        ...base,
        status: "active",
        displayName: legacy?.name ?? null,
        profileImageUrl: legacy?.profile_image_url_https ?? null,
        followerCount: legacy?.followers_count ?? null,
        followingCount: legacy?.friends_count ?? null,
        isVerified: result.is_blue_verified ?? legacy?.verified ?? null,
        createdAt,
      };
    }

    if (errors && errors.length > 0) {
      const msg = errors[0].message?.toLowerCase() ?? "";
      const code = errors[0].code;
      if (msg.includes("not found") || code === 50) return { ...base, status: "not_found" };
      if (msg.includes("suspend") || code === 63) return { ...base, status: "suspended" };
      return { ...base, status: "unknown", error: errors[0].message };
    }

    if (!result) return { ...base, status: "not_found" };
    return { ...base, status: "unknown", error: "Unexpected response shape" };
  } catch (err) {
    return {
      ...base,
      status: "unknown",
      error: err instanceof Error ? err.message : "Unknown error",
    };
  }
}

// ─── Handler ──────────────────────────────────────────────────────────────────
export default async function handler(
  req: VercelRequest,
  res: VercelResponse
): Promise<void> {
  // CORS for local dev / custom domains
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }

  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  const body = req.body as { usernames?: unknown };
  if (!Array.isArray(body?.usernames)) {
    res.status(400).json({ error: "Request body must include a `usernames` array." });
    return;
  }

  const usernames: string[] = (body.usernames as unknown[])
    .filter((u): u is string => typeof u === "string")
    .map((u) => u.trim().replace(/^@/, ""))
    .filter((u) => u.length > 0)
    .slice(0, 100);

  if (usernames.length === 0) {
    res.status(400).json({ error: "No valid usernames provided." });
    return;
  }

  let guestToken: string;
  try {
    guestToken = await getGuestToken();
  } catch (err) {
    res.status(502).json({
      error: "Could not reach X API. Please try again in a moment.",
    });
    return;
  }

  const results = await Promise.all(
    usernames.map((username) => checkXAccount(username, guestToken))
  );

  res.status(200).json({ results });
}
