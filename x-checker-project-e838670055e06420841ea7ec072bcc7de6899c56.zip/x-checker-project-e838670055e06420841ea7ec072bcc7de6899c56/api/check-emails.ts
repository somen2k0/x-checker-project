import type { VercelRequest, VercelResponse } from "@vercel/node";

const GMAIL_DOMAINS = new Set(["gmail.com", "googlemail.com"]);

interface EmailCheckResult {
  email: string;
  status: "valid" | "invalid_format" | "invalid_domain" | "disposable" | "unknown";
  reason: string | null;
  isGmail: boolean;
  normalizedEmail: string | null;
}

function parseEmailParts(raw: string): { local: string; domain: string } | null {
  const at = raw.lastIndexOf("@");
  if (at < 1 || at >= raw.length - 1) return null;
  return { local: raw.slice(0, at), domain: raw.slice(at + 1).toLowerCase() };
}

function isValidEmailFormat(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) && email.length <= 320;
}

function checkGmailUsernameRules(local: string): string | null {
  if (local.startsWith(".") || local.endsWith(".")) {
    return "Username cannot start or end with a dot";
  }
  if (local.includes("..")) {
    return "Username cannot contain consecutive dots";
  }
  if (!/^[a-zA-Z0-9.]+$/.test(local)) {
    return "Username contains invalid characters — only letters, numbers, and dots are allowed";
  }
  const stripped = local.replace(/\./g, "");
  if (stripped.length < 6) {
    return `Username too short — Gmail requires at least 6 characters (got ${stripped.length})`;
  }
  if (stripped.length > 30) {
    return `Username too long — Gmail allows up to 30 characters (got ${stripped.length})`;
  }
  return null;
}

function checkEmail(raw: string): EmailCheckResult {
  const email = raw.trim();

  if (!isValidEmailFormat(email)) {
    return {
      email,
      status: "invalid_format",
      reason: "Invalid email format",
      isGmail: false,
      normalizedEmail: null,
    };
  }

  const parts = parseEmailParts(email);
  if (!parts) {
    return {
      email,
      status: "invalid_format",
      reason: "Could not parse email address",
      isGmail: false,
      normalizedEmail: null,
    };
  }

  const { local, domain } = parts;
  const isGmail = GMAIL_DOMAINS.has(domain);

  if (!isGmail) {
    return {
      email,
      status: "invalid_domain",
      reason: `Not a Gmail address — domain must be @gmail.com (got @${domain})`,
      isGmail: false,
      normalizedEmail: null,
    };
  }

  const usernameError = checkGmailUsernameRules(local);
  if (usernameError) {
    return {
      email,
      status: "invalid_format",
      reason: usernameError,
      isGmail: true,
      normalizedEmail: null,
    };
  }

  const normalizedLocal = local.replace(/\./g, "").toLowerCase();
  const normalizedEmail = `${normalizedLocal}@gmail.com`;

  return {
    email,
    status: "valid",
    reason: null,
    isGmail: true,
    normalizedEmail,
  };
}

export default async function handler(
  req: VercelRequest,
  res: VercelResponse
): Promise<void> {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }

  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  const body = req.body as { emails?: unknown };
  if (!Array.isArray(body?.emails)) {
    res.status(400).json({ error: "Request body must include an `emails` array." });
    return;
  }

  const emails: string[] = (body.emails as unknown[])
    .filter((e): e is string => typeof e === "string")
    .map((e) => e.trim())
    .filter((e) => e.length > 0)
    .slice(0, 500);

  if (emails.length === 0) {
    res.status(400).json({ error: "No valid emails provided." });
    return;
  }

  const results = emails.map(checkEmail);
  res.status(200).json({ results });
}
