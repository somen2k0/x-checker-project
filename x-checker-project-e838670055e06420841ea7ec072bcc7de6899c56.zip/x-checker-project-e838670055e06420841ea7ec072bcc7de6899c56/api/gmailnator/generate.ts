import type { VercelRequest, VercelResponse } from "@vercel/node";

const RAPID_HOST = "gmailnator.p.rapidapi.com";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const key = process.env.RAPIDAPI_KEY;
  if (!key) return res.status(503).json({ error: "Gmailnator API not configured." });

  try {
    const r = await fetch(`https://${RAPID_HOST}/api/emails/generate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-RapidAPI-Key": key,
        "X-RapidAPI-Host": RAPID_HOST,
      },
      body: JSON.stringify({}),
    });
    const data = await r.json() as { status: string; email: string; type: string };
    if (data.status !== "success" || !data.email) {
      return res.status(502).json({ error: "Failed to generate Gmail address." });
    }
    return res.status(200).json({ email: data.email, type: data.type });
  } catch {
    return res.status(502).json({ error: "Could not generate Gmail address." });
  }
}
