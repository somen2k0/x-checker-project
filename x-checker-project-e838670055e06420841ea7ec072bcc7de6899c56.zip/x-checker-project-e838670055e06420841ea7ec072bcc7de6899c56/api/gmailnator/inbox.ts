import type { VercelRequest, VercelResponse } from "@vercel/node";

const RAPID_HOST = "gmailnator.p.rapidapi.com";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });
  const key = process.env.RAPIDAPI_KEY;
  if (!key) return res.status(503).json({ error: "Gmailnator API not configured." });

  const { email } = req.body as { email?: string };
  if (!email) return res.status(400).json({ error: "email is required." });

  try {
    const r = await fetch(`https://${RAPID_HOST}/api/inbox`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-RapidAPI-Key": key,
        "X-RapidAPI-Host": RAPID_HOST,
      },
      body: JSON.stringify({ email }),
    });
    const data = await r.json() as { status: string; messages: unknown[]; message_count: number };
    return res.status(200).json({ messages: data.messages ?? [], message_count: data.message_count ?? 0 });
  } catch {
    return res.status(502).json({ error: "Could not fetch inbox." });
  }
}
