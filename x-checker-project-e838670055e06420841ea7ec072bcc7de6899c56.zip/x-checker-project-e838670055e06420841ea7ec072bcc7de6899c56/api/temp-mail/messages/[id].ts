import type { VercelRequest, VercelResponse } from "@vercel/node";

const GUERRILLA_API = "https://api.guerrillamail.com/ajax.php";

interface GuerrillaFetchResponse {
  mail_id: string;
  mail_from: string;
  mail_subject: string;
  mail_body: string;
  mail_excerpt: string;
  mail_timestamp: string;
  mail_date: string;
  mail_read: string;
  att_count: string;
  ref_mid: string;
}

export default async function handler(req: VercelRequest, res: VercelResponse): Promise<void> {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }

  if (req.method !== "GET") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Missing token" });
    return;
  }
  const sidToken = auth.slice(7);

  const id = req.query.id as string;
  if (!id || !/^[a-zA-Z0-9_-]+$/.test(id)) {
    res.status(400).json({ error: "Invalid message ID" });
    return;
  }

  try {
    const r = await fetch(
      `${GUERRILLA_API}?f=fetch_email&email_id=${encodeURIComponent(id)}&sid_token=${encodeURIComponent(sidToken)}`,
      { signal: AbortSignal.timeout(10000) },
    );
    if (!r.ok) {
      res.status(r.status).json({ error: "Message not found" });
      return;
    }
    const data = (await r.json()) as GuerrillaFetchResponse;
    res.status(200).json({
      id: data.mail_id,
      from: { address: data.mail_from, name: data.mail_from },
      subject: data.mail_subject || "(no subject)",
      intro: data.mail_excerpt || "",
      createdAt: new Date(parseInt(data.mail_timestamp, 10) * 1000).toISOString(),
      seen: true,
      hasAttachments: data.att_count !== "0",
      html: data.mail_body ? [data.mail_body] : undefined,
      text: data.mail_excerpt,
    });
  } catch {
    res.status(502).json({ error: "Failed to fetch message" });
  }
}
