import type { VercelRequest, VercelResponse } from "@vercel/node";

const GUERRILLA_API = "https://api.guerrillamail.com/ajax.php";

const FIRST_NAMES = [
  "adam","alex","alice","amber","amy","anna","ben","blake","brad","brian",
  "chloe","chris","claire","cole","dana","david","diana","drew","dylan","elena",
  "eli","emily","emma","eric","evan","fiona","frank","grace","grant","hannah",
  "henry","holly","ian","jack","jake","james","jane","jason","jessica","joel",
  "john","julia","karen","kate","kevin","kyle","laura","leo","lily","lisa",
  "luke","mark","mary","matt","maya","megan","michael","mike","molly","morgan",
  "nate","nick","nina","noah","olivia","owen","paul","peter","rachel","ryan",
  "sara","sarah","scott","sean","seth","sophie","steve","taylor","thomas","tim",
  "tom","tyler","victor","will","zoe",
];

const LAST_NAMES = [
  "adams","allen","anderson","baker","bell","bennett","brooks","brown","campbell",
  "carter","clark","cole","collins","cook","cooper","cox","davis","edwards","evans",
  "fisher","flores","ford","foster","garcia","gray","green","hall","harris","hayes",
  "hill","howard","hughes","jackson","james","johnson","jones","kelly","king","lane",
  "lee","lewis","long","lopez","martin","martinez","miller","mitchell","moore",
  "morgan","morris","murphy","nelson","parker","perry","peterson","phillips","price",
  "reed","reynolds","richardson","roberts","robinson","rogers","ross","russell","ryan",
  "sanchez","scott","shaw","smith","stewart","stone","taylor","thomas","thompson",
  "turner","walker","ward","watson","white","williams","wilson","wood","wright","young",
];

function generateUsername(): string {
  const first = FIRST_NAMES[Math.floor(Math.random() * FIRST_NAMES.length)];
  const last  = LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)];
  const num   = Math.floor(Math.random() * 90) + 10;
  return `${first}.${last}${num}`;
}

interface GuerrillaAddressResponse {
  email_addr: string;
  sid_token: string;
  email_timestamp: number;
  alias: string;
  site_id: string;
  site: string;
}

async function safeJson<T>(r: Response): Promise<T | null> {
  try {
    const text = await r.text();
    if (!text.trim()) return null;
    return JSON.parse(text) as T;
  } catch {
    return null;
  }
}

export default async function handler(req: VercelRequest, res: VercelResponse): Promise<void> {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }

  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  try {
    const { username: rawUsername } = (req.body ?? {}) as { username?: string };

    const initRes = await fetch(
      `${GUERRILLA_API}?f=get_email_address&lang=en&site=guerrillamail.com`,
      { signal: AbortSignal.timeout(10000) },
    );
    const initData = await safeJson<GuerrillaAddressResponse>(initRes);
    if (!initData?.sid_token) {
      res.status(502).json({ error: "Temp mail service unavailable — please try again" });
      return;
    }
    const sidToken = initData.sid_token;

    const isCustom = !!(rawUsername && /^[a-z0-9._-]{3,30}$/.test(rawUsername.toLowerCase().trim()));
    const desiredUser = isCustom ? rawUsername!.toLowerCase().trim() : generateUsername();

    const setRes = await fetch(
      `${GUERRILLA_API}?f=set_email_user&email_user=${encodeURIComponent(desiredUser)}&lang=en&sid_token=${encodeURIComponent(sidToken)}`,
      { signal: AbortSignal.timeout(10000) },
    );
    const setData = await safeJson<Partial<GuerrillaAddressResponse>>(setRes);

    const finalAddress = setData?.email_addr ?? initData.email_addr;
    if (!finalAddress) {
      res.status(502).json({ error: "Could not assign email address — please try again" });
      return;
    }

    res.status(200).json({ id: sidToken, address: finalAddress, token: sidToken });
  } catch {
    res.status(502).json({ error: "Temp mail service unavailable. Please try again." });
  }
}
