import type { VercelRequest, VercelResponse } from "@vercel/node";

const GUERRILLA_API = "https://api.guerrillamail.com/ajax.php";

interface GuerrillaMessage {
  mail_id: string;
  mail_from: string;
  mail_subject: string;
  mail_excerpt: string;
  mail_timestamp: string;
  mail_date: string;
  mail_read: string;
  att: string;
}

interface GuerrillaCheckResponse {
  list: GuerrillaMessage[];
  count: string;
  email: string;
  alias: string;
  sid_token: string;
}

function normalizeMessage(m: GuerrillaMessage) {
  return {
    id: m.mail_id,
    from: { address: m.mail_from, name: m.mail_from },
    subject: m.mail_subject || "(no subject)",
    intro: m.mail_excerpt || "",
    createdAt: new Date(parseInt(m.mail_timestamp, 10) * 1000).toISOString(),
    seen: m.mail_read === "1",
    hasAttachments: m.att !== "0",
  };
}

export default async function handler(req: VercelRequest, res: VercelResponse): Promise<void> {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }

  if (req.method !== "GET") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  const auth = req.headers.authorization;
  if (!auth?.startsWith("Bearer ")) {
    res.status(401).json({ error: "Missing token" });
    return;
  }
  const sidToken = auth.slice(7);
  const seq = typeof req.query.seq === "string" ? req.query.seq : "0";

  try {
    const r = await fetch(
      `${GUERRILLA_API}?f=check_email&seq=${encodeURIComponent(seq)}&sid_token=${encodeURIComponent(sidToken)}`,
      { signal: AbortSignal.timeout(10000) },
    );
    if (!r.ok) {
      res.status(r.status).json({ error: "Failed to fetch messages" });
      return;
    }
    const data = (await r.json()) as GuerrillaCheckResponse;
    const messages = (data.list ?? []).map(normalizeMessage);
    res.status(200).json({ messages });
  } catch {
    res.status(502).json({ error: "Failed to fetch messages" });
  }
}
