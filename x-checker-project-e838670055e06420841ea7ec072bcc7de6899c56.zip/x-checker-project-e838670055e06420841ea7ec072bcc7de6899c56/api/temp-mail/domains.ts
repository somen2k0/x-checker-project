import type { VercelRequest, VercelResponse } from "@vercel/node";

const GUERRILLA_DOMAINS = [
  "guerrillamail.com",
  "guerrillamail.net",
  "guerrillamail.org",
  "guerrillamail.biz",
  "guerrillamail.de",
  "grr.la",
  "spam4.me",
];

export default function handler(_req: VercelRequest, res: VercelResponse): void {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");

  if (_req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }

  res.status(200).json({ domains: GUERRILLA_DOMAINS });
}
